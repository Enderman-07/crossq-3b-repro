"""Prepare and control the paired CrossQ/Cross3B-DTEMA pilot."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import shutil

from run_cross3b_wn_pilot import now, run, status, write_json


ROOT = Path(__file__).resolve().parent
CONDITIONS = [
    {"name": "crossq", "algo": "crossq"},
    {
        "name": "dt2-ema",
        "algo": "cross3b_dual_target_ema",
        "target_action_samples": 2,
        "target_action_start_steps": 0,
        "ema_start_steps": 100_000,
        "ema_half_life_steps": 25_000.0,
    },
    {
        "name": "delayed-dt2-ema",
        "algo": "cross3b_dual_target_ema",
        "target_action_samples": 2,
        "target_action_start_steps": 100_000,
        "ema_start_steps": 100_000,
        "ema_half_life_steps": 25_000.0,
    },
    {
        "name": "midstart-dt2-ema",
        "algo": "cross3b_dual_target_ema",
        "target_action_samples": 2,
        "target_action_start_steps": 50_000,
        "ema_start_steps": 100_000,
        "ema_half_life_steps": 25_000.0,
    },
]


def prepare(args):
    condition_by_name = {
        condition["name"]: condition for condition in CONDITIONS
    }
    unknown = set(args.condition_names) - condition_by_name.keys()
    if unknown:
        raise ValueError(f"unknown conditions: {sorted(unknown)}")
    if "crossq" not in args.condition_names:
        raise ValueError("selected conditions must include crossq")
    conditions = [condition_by_name[name] for name in args.condition_names]
    group = args.group_dir.resolve()
    group.mkdir(parents=True, exist_ok=False)
    snapshot = group / "source"
    snapshot.mkdir()
    shutil.copytree(
        ROOT / "cross3b",
        snapshot / "cross3b",
        ignore=shutil.ignore_patterns("__pycache__"),
    )
    shutil.copytree(
        ROOT / "third_party" / "CrossQ",
        snapshot / "third_party" / "CrossQ",
        ignore=shutil.ignore_patterns("__pycache__"),
    )
    source_files = [
        ROOT / "run_experiment.py",
        ROOT / "run_cross3b_wn_pilot.py",
        ROOT / "run_cross3b_dual_target_ema_pilot.py",
        ROOT / "summarize_dual_target_ema_pilot.py",
        ROOT / "EXPERIMENT_CROSS3B_DUAL_TARGET_EMA_20261102.md",
    ]
    for source in source_files:
        shutil.copy2(source, snapshot / source.name)
    hash_paths = [
        *source_files,
        *sorted((ROOT / "cross3b").glob("*.py")),
        ROOT / "third_party" / "CrossQ" / "sbx" / "sac" / "sac.py",
        ROOT / "third_party" / "CrossQ" / "sbx" / "sac" / "policies.py",
    ]
    hashes = {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in hash_paths
    }

    jobs = []
    for env_id in args.envs:
        for condition in conditions:
            for seed in args.seeds:
                run_name = f"{condition['name']}_{env_id}_seed{seed}"
                output_root = group / condition["name"]
                run_dir = output_root / run_name
                command = [
                    str(ROOT / ".venv" / "bin" / "python"),
                    "-u",
                    str(snapshot / "run_experiment.py"),
                    "--algo",
                    condition["algo"],
                    "--env",
                    env_id,
                    "--seed",
                    str(seed),
                    "--timesteps",
                    str(args.timesteps),
                    "--eval-freq",
                    str(args.eval_freq),
                    "--eval-episodes",
                    str(args.eval_episodes),
                    "--eval-seed-mode",
                    "fixed",
                    "--batch-size",
                    "256",
                    "--n-neurons",
                    "2048",
                    "--policy-delay",
                    "3",
                    "--learning-rate",
                    "0.001",
                    "--checkpoint-freq",
                    str(args.checkpoint_freq),
                    "--final-eval-episodes",
                    str(args.final_eval_episodes),
                    "--output-root",
                    str(output_root),
                    "--run-name",
                    run_name,
                ]
                if condition["algo"] == "cross3b_dual_target_ema":
                    command.extend(
                        [
                            "--target-action-samples",
                            str(condition["target_action_samples"]),
                            "--target-action-start-steps",
                            str(condition["target_action_start_steps"]),
                            "--ema-start-steps",
                            str(condition["ema_start_steps"]),
                            "--ema-half-life-steps",
                            str(condition["ema_half_life_steps"]),
                        ]
                    )
                jobs.append(
                    {
                        "id": f"{condition['name']}/{run_name}",
                        "condition": condition["name"],
                        "env": env_id,
                        "seed": seed,
                        "run_dir": str(run_dir),
                        "command": command,
                    }
                )

    plan = {
        "name": group.name,
        "created_at": now(),
        "total_runs": len(jobs),
        "timesteps": args.timesteps,
        "eval_freq": args.eval_freq,
        "eval_episodes": args.eval_episodes,
        "checkpoint_freq": args.checkpoint_freq,
        "final_eval_episodes": args.final_eval_episodes,
        "envs": args.envs,
        "seeds": args.seeds,
        "conditions": conditions,
        "source_sha256": hashes,
        "source_snapshot": str(snapshot),
        "jobs": jobs,
        "evaluation": {
            "seed_mode": "fixed",
            "periodic_seed_offset": 100_000,
            "periodic_frequency": args.eval_freq,
            "periodic_episodes": args.eval_episodes,
            "heldout_seed_offset": 200_000,
            "heldout_episodes": args.final_eval_episodes,
        },
        "decision": (
            "A candidate passes only if it beats paired CrossQ in mean AUC "
            "and held-out return on all three environments."
        ),
    }
    write_json(group / "screen_plan.json", plan)
    for condition in conditions:
        condition_dir = group / condition["name"]
        condition_dir.mkdir()
        write_json(
            condition_dir / "matrix_plan.json",
            {
                "matrix_name": condition["name"],
                "total_runs": len(args.seeds) * len(args.envs),
                "timesteps": args.timesteps,
                "eval_freq": args.eval_freq,
                "eval_episodes": args.eval_episodes,
                "checkpoint_freq": args.checkpoint_freq,
                "final_eval_episodes": args.final_eval_episodes,
                "condition": condition,
                "planned_runs": [
                    Path(job["run_dir"]).name
                    for job in jobs
                    if job["condition"] == condition["name"]
                ],
            },
        )
    print(f"Prepared {len(jobs)} runs: {group}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["prepare", "run", "status"])
    parser.add_argument("--group-dir", type=Path, required=True)
    parser.add_argument("--gpus", type=int, nargs="+", default=[0, 1])
    parser.add_argument("--workers-per-gpu", type=int, default=2)
    parser.add_argument(
        "--envs",
        nargs="+",
        default=["Walker2d-v4", "Hopper-v4", "Ant-v4"],
    )
    parser.add_argument("--seeds", type=int, nargs="+", default=[18, 19])
    parser.add_argument(
        "--condition-names",
        nargs="+",
        default=[condition["name"] for condition in CONDITIONS],
    )
    parser.add_argument("--timesteps", type=int, default=300_000)
    parser.add_argument("--eval-freq", type=int, default=25_000)
    parser.add_argument("--eval-episodes", type=int, default=5)
    parser.add_argument("--checkpoint-freq", type=int, default=100_000)
    parser.add_argument("--final-eval-episodes", type=int, default=20)
    args = parser.parse_args()
    if (
        args.workers_per_gpu < 1
        or args.timesteps < 1
        or args.eval_freq < 1
        or args.eval_episodes < 1
        or args.checkpoint_freq < 0
        or args.final_eval_episodes < 1
    ):
        parser.error("workers, steps, and evaluation settings must be valid")
    if len(set(args.gpus)) != len(args.gpus):
        parser.error("GPU IDs must be unique")
    {"prepare": prepare, "run": run, "status": status}[args.action](args)


if __name__ == "__main__":
    main()

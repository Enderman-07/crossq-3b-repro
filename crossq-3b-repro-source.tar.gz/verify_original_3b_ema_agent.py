"""Verify original actor-step 3B scheduling and evaluation-only EMA."""

import os
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "third_party" / "CrossQ"))
os.environ.setdefault("JAX_PLATFORMS", "cpu")
os.environ.setdefault("MPLCONFIGDIR", "/tmp/cross3b-mpl")

import gymnasium as gym
import jax
import numpy as np
import optax
import torch
from stable_baselines3.common.logger import configure

from cross3b import Cross3BOriginalEMA
from sbx import SAC
from sbx.sac.utils import ReLU


def make_model(model_class, **extra):
    return model_class(
        "MlpPolicy",
        gym.make("Hopper-v4"),
        policy_kwargs=dict(
            activation_fn=ReLU,
            net_arch={"pi": [32, 32], "qf": [64, 64]},
            batch_norm=True,
            batch_norm_momentum=0.99,
            batch_norm_mode="brn_actor",
            n_critics=2,
            optimizer_class=optax.adam,
            optimizer_kwargs={"b1": 0.5, "b2": 0.999},
        ),
        gradient_steps=1,
        policy_delay=1,
        crossq_style=True,
        tau=1.0,
        learning_starts=16,
        learning_rate=1e-3,
        qf_learning_rate=1e-3,
        buffer_size=100,
        batch_size=16,
        seed=91,
        **extra,
    )


def tree_exact(left, right):
    left_leaves = jax.tree_util.tree_leaves(left)
    right_leaves = jax.tree_util.tree_leaves(right)
    return len(left_leaves) == len(right_leaves) and all(
        np.array_equal(np.asarray(a), np.asarray(b), equal_nan=True)
        for a, b in zip(left_leaves, right_leaves)
    )


def tree_finite(tree):
    return all(
        np.isfinite(np.asarray(leaf)).all()
        for leaf in jax.tree_util.tree_leaves(tree)
    )


def add_replay(models):
    generator = np.random.default_rng(93)
    for _ in range(32):
        observation = generator.normal(
            size=models[0].observation_space.shape
        ).astype(np.float32)
        next_observation = (
            observation
            + generator.normal(scale=0.05, size=observation.shape)
        ).astype(np.float32)
        action = generator.uniform(
            -0.8, 0.8, size=models[0].action_space.shape
        ).astype(np.float32)
        reward = np.asarray([generator.normal()], dtype=np.float32)
        done = np.asarray([0.0], dtype=np.float32)
        for model in models:
            model.replay_buffer.add(
                observation[None, :],
                next_observation[None, :],
                action[None, :],
                reward,
                done,
                [{}],
            )


def paired_train(models):
    numpy_state = np.random.get_state()
    torch_state = torch.random.get_rng_state()
    for model in models:
        np.random.set_state(numpy_state)
        torch.random.set_rng_state(torch_state)
        model.train(batch_size=16, gradient_steps=1)


def online_state(model):
    return (
        model.policy.actor_state,
        model.policy.qf_state,
        model.ent_coef_state,
        model.key,
    )


def main():
    baseline = make_model(SAC)
    immediate = make_model(
        Cross3BOriginalEMA,
        policy_batch_start_steps=0,
        ema_start_steps=100,
        ema_half_life_steps=2.0,
    )
    staged = make_model(
        Cross3BOriginalEMA,
        policy_batch_start_steps=1,
        ema_start_steps=2,
        ema_half_life_steps=2.0,
    )
    staged_late_ema = make_model(
        Cross3BOriginalEMA,
        policy_batch_start_steps=1,
        ema_start_steps=100,
        ema_half_life_steps=2.0,
    )
    models = (baseline, immediate, staged, staged_late_ema)
    for model in models:
        model.set_logger(configure(folder=None, format_strings=[]))
    add_replay(models)

    checks = {
        "initial_states_exact": all(
            tree_exact(online_state(baseline), online_state(model))
            for model in models[1:]
        )
    }

    paired_train(models)
    checks.update(
        staged_prefix_crossq_exact=tree_exact(
            online_state(baseline), online_state(staged)
        ),
        staged_prefix_policy_batch_inactive=(
            staged.last_train_metrics["policy_batch_active"] == 0.0
        ),
        immediate_policy_batch_active=(
            immediate.last_train_metrics["policy_batch_active"] == 1.0
        ),
        immediate_changes_online_state=not tree_exact(
            online_state(baseline), online_state(immediate)
        ),
        prefix_ema_tracks_online=tree_exact(
            staged.policy.actor_state, staged.ema_actor_state
        ),
    )

    paired_train(models)
    checks.update(
        staged_policy_batch_active=(
            staged.last_train_metrics["policy_batch_active"] == 1.0
        ),
        staged_policy_batch_used=(
            staged.last_train_metrics["policy_batch_updates"] == 1.0
        ),
        staged_changes_from_crossq=not tree_exact(
            online_state(baseline), online_state(staged)
        ),
        ema_does_not_change_online_path=tree_exact(
            online_state(staged), online_state(staged_late_ema)
        ),
        ema_still_inactive=(staged.last_train_metrics["ema_active"] == 0.0),
    )

    paired_train(models)
    checks.update(
        ema_online_path_still_exact=tree_exact(
            online_state(staged), online_state(staged_late_ema)
        ),
        ema_active=(staged.last_train_metrics["ema_active"] == 1.0),
        ema_actor_changes=not tree_exact(
            staged.policy.actor_state.params,
            staged.ema_actor_state.params,
        ),
        online_states_finite=tree_finite(
            (online_state(staged), staged.ema_actor_state)
        ),
    )

    observation = np.zeros(
        (1, *staged.observation_space.shape), dtype=np.float32
    )
    online_action, _ = staged.predict(observation, deterministic=True)
    ema_action, _ = staged.predict_evaluation(
        observation, deterministic=True
    )
    checks.update(
        evaluation_action_finite=np.isfinite(ema_action).all(),
        evaluation_action_changes=not np.array_equal(
            online_action, ema_action
        ),
    )

    print(checks)
    for model in models:
        model.env.close()
    if not all(checks.values()):
        raise SystemExit("original 3B EMA verification failed")
    print("ORIGINAL_3B_EMA_AGENT_OK")


if __name__ == "__main__":
    main()

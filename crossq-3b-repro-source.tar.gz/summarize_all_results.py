"""Build a complete CrossQ/Cross3B result inventory and comparison report."""

from __future__ import annotations

import argparse
import csv
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable


FORMAL_EXPERIMENTS = {
    "main-1m-gpu",
    "matrix-20261023-004150",
    "strict-r050-hopper-20261023-103928",
    "strict-r050-walker-20261023-103928",
    "actor-only-r050-hopper-20261023-143212",
    "actor-only-r050-walker-20261023-143212",
    "frequency-screen-20261024-r1",
    "conflict-screen-20261024-r1",
    "soft-projection-screen-20261024-r1",
    "layerwise-projection-screen-20261026-r1",
    "adaptive-projection-screen-20261026-r1",
    "global-projection-1m-20261027-r1",
    "ant-1m-baseline-20261028-r1",
}

RUN_FIELDS = [
    "category",
    "status",
    "experiment",
    "comparison_family",
    "condition",
    "method",
    "algo",
    "env",
    "seed",
    "timesteps",
    "last_eval_timestep",
    "completion_ratio",
    "eval_freq",
    "eval_episodes",
    "eval_seed_mode",
    "batch_size",
    "n_neurons",
    "policy_batch_ratio",
    "bootstrap_batch_weight",
    "policy_stat_gate",
    "policy_stat_mean_budget",
    "policy_stat_log_var_budget",
    "policy_stat_gate_recovery",
    "policy_risk_threshold",
    "policy_risk_min_scale",
    "policy_risk_gate_mode",
    "policy_batch_mode",
    "detach_policy_moments",
    "conflict_aware_policy_moments",
    "policy_moment_max_grad_ratio",
    "policy_moment_projection_strength",
    "policy_moment_projection_scope",
    "policy_moment_conflict_energy_threshold",
    "cross3b_variant",
    "evaluation_records",
    "final_return",
    "final_checkpoint_return",
    "best_checkpoint_return",
    "heldout_final_return",
    "heldout_final_return_std",
    "heldout_final_episodes",
    "policy_stat_gate_scale_mean",
    "policy_stat_gate_active_fraction",
    "policy_stat_gate_cap_mean_shift",
    "policy_stat_gate_cap_log_var_shift",
    "policy_risk_ratio_mean",
    "policy_risk_ratio_p90",
    "policy_risk_scale_mean",
    "policy_risk_active_fraction",
    "auc",
    "train_wall_seconds",
    "total_wall_seconds",
    "diverged",
    "path",
]

AGGREGATE_FIELDS = [
    "comparison_family",
    "method",
    "algo",
    "env",
    "timesteps",
    "eval_freq",
    "eval_episodes",
    "eval_seed_mode",
    "seeds",
    "runs",
    "final_return_mean",
    "final_return_std",
    "final_vs_crossq_pct",
    "final_checkpoint_return_mean",
    "final_checkpoint_return_std",
    "best_checkpoint_return_mean",
    "best_checkpoint_return_std",
    "heldout_final_episodes",
    "heldout_final_return_mean",
    "heldout_final_return_std",
    "heldout_final_vs_crossq_pct",
    "policy_stat_gate_scale_mean",
    "policy_stat_gate_active_fraction",
    "policy_stat_gate_cap_mean_shift",
    "policy_stat_gate_cap_log_var_shift",
    "policy_risk_ratio_mean",
    "policy_risk_ratio_p90",
    "policy_risk_scale_mean",
    "policy_risk_active_fraction",
    "auc_mean",
    "auc_std",
    "auc_vs_crossq_pct",
    "train_wall_seconds_mean",
    "train_wall_seconds_std",
    "wall_vs_crossq_pct",
    "diverged_runs",
    "experiments",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--runs-root",
        type=Path,
        default=Path(__file__).resolve().parent / "runs",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parent,
    )
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_evaluations(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    records = []
    lines = path.read_text(encoding="utf-8").splitlines()
    for index, line in enumerate(lines):
        if line.strip():
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                # A live process may still be writing its last evaluation.
                if index != len(lines) - 1:
                    raise
    return records


def condition_name(
    experiment: str, run_dir: Path, runs_root: Path, config: dict[str, Any]
) -> str:
    output_root = config.get("output_root")
    if output_root:
        return Path(output_root).name

    parts = run_dir.relative_to(runs_root).parts
    run_name = config.get("run_name")
    condition_parts = parts[1:-1] if run_name == parts[-1] else parts[1:]
    return "/".join(condition_parts) or experiment


def method_name(
    experiment: str, condition: str, algo: str, config: dict[str, Any]
) -> str:
    if algo == "crossq":
        return "CrossQ"
    if config.get("cross3b_variant") == "policy_risk_probe":
        return (
            "CrossQ policy-risk probe "
            f"{config.get('policy_risk_gate_mode', 'full_loss')} "
            f"t{config.get('policy_risk_threshold', 1.5):g}"
        )
    if condition.startswith("balanced-l"):
        return f"Cross3B balanced lambda={config['policy_batch_ratio']:g}"
    if condition == "reweighted2n-b150":
        return "Cross3B 2N bootstrap weight=1.5"
    if condition.startswith("global-r050-cap"):
        return f"Cross3B global r0.5 cap={config['policy_moment_max_grad_ratio']:g}"
    if condition.startswith("stat-gate-"):
        return (
            "Cross3B stat gate "
            f"m{config['policy_stat_mean_budget']:g} "
            f"v{config['policy_stat_log_var_budget']:g}"
        )
    if experiment == "main-1m-gpu":
        return "Cross3B r1.0"
    if experiment == "matrix-20261023-004150":
        return "Cross3B subset r0.5"
    if experiment.startswith("strict-r050-"):
        return "Cross3B strict r0.5"
    if experiment.startswith("actor-only-r050-"):
        return "Cross3B strict r0.5 actor-only"
    if condition == "weighted2n":
        return "Cross3B 2N control (r0)"
    if condition == "frequency-weighted":
        return "Cross3B frequency r1/3"
    if condition == "frequency-weighted-detached":
        return "Cross3B frequency r1/3 detached"
    if condition == "attached-r050":
        return "Cross3B attached r0.5"
    if condition == "conflict-aware-r050":
        return "Cross3B conflict-aware r0.5"
    if condition == "soft-projection-r050-a050":
        return "Cross3B soft projection r0.5 a0.5"
    if condition == "layerwise-projection-r050":
        return "Cross3B layerwise projection r0.5"
    if condition == "adaptive-projection-r050-e095":
        return "Cross3B adaptive projection r0.5 e0.95"
    if condition == "global-projection-r050-1m":
        return "Cross3B global projection r0.5 e0.95"
    if condition == "ant-1m-baseline-cross3b":
        return "Cross3B strict r0.5"

    variant = config.get("cross3b_variant", "cross3b")
    ratio = config.get("policy_batch_ratio")
    ratio_suffix = f" r{ratio:g}" if isinstance(ratio, (int, float)) else ""
    return f"Cross3B {variant}{ratio_suffix} [{condition}]"


def classify_status(relative_parts: tuple[str, ...], has_summary: bool, has_eval: bool) -> str:
    if "_failed" in relative_parts:
        return "archived_failed"
    if "_interrupted" in relative_parts:
        return "interrupted"
    if has_summary:
        return "completed"
    if has_eval:
        return "incomplete"
    return "config_only"


def collect_runs(runs_root: Path) -> list[dict[str, Any]]:
    config_dirs = {path.parent for path in runs_root.rglob("config.json")}
    summary_dirs = {path.parent for path in runs_root.rglob("summary.json")}
    rows = []

    for run_dir in sorted(config_dirs | summary_dirs):
        config_path = run_dir / "config.json"
        summary_path = run_dir / "summary.json"
        config = read_json(config_path) if config_path.exists() else {}
        summary = read_json(summary_path) if summary_path.exists() else {}
        # A summary is only written after training completes, so its counters are
        # enough for the inventory. Read the full curve only for unfinished runs.
        relative_parts = run_dir.relative_to(runs_root).parts
        experiment = relative_parts[0]
        is_new_screen = experiment.startswith(
            (
                "stable-3b-screen-",
                "policy-stat-gate-screen-",
                "policy-risk-probe-screen-",
            )
        )
        needs_metric_records = is_new_screen or experiment.startswith(
            "policy-risk-probe-pilot-"
        )
        records = (
            read_evaluations(run_dir / "evaluations.jsonl")
            if not summary_path.exists() or needs_metric_records
            else []
        )
        condition = condition_name(experiment, run_dir, runs_root, config)
        algo = summary.get("algo", config.get("algo", "unknown"))
        timesteps = summary.get("timesteps", config.get("timesteps"))
        last_eval_timestep = (
            summary.get("timesteps")
            if summary_path.exists()
            else (records[-1].get("timesteps") if records else None)
        )
        completion_ratio = None
        if timesteps and last_eval_timestep is not None:
            completion_ratio = min(float(last_eval_timestep) / float(timesteps), 1.0)
        status = classify_status(
            relative_parts, summary_path.exists(), bool(records)
        )
        new_screen = is_new_screen
        category = "formal" if experiment in FORMAL_EXPERIMENTS or new_screen else "diagnostic"
        if status in {"archived_failed", "interrupted"}:
            category = "archive"

        row = {
            "category": category,
            "status": status,
            "experiment": experiment,
            "comparison_family": experiment if new_screen else "legacy",
            "condition": condition,
            "method": method_name(experiment, condition, algo, config),
            "algo": algo,
            "env": summary.get("env", config.get("env")),
            "seed": summary.get("seed", config.get("seed")),
            "timesteps": timesteps,
            "last_eval_timestep": last_eval_timestep,
            "completion_ratio": completion_ratio,
            "eval_freq": config.get("eval_freq"),
            "eval_episodes": config.get("eval_episodes", 1),
            "eval_seed_mode": config.get("eval_seed_mode", "legacy"),
            "batch_size": config.get("batch_size"),
            "n_neurons": config.get("n_neurons"),
            "policy_batch_ratio": config.get("policy_batch_ratio"),
            "bootstrap_batch_weight": config.get("bootstrap_batch_weight", 1.0),
            "policy_stat_gate": config.get("policy_stat_gate", False),
            "policy_stat_mean_budget": config.get("policy_stat_mean_budget"),
            "policy_stat_log_var_budget": config.get(
                "policy_stat_log_var_budget"
            ),
            "policy_stat_gate_recovery": config.get(
                "policy_stat_gate_recovery"
            ),
            "policy_risk_threshold": config.get("policy_risk_threshold"),
            "policy_risk_min_scale": config.get("policy_risk_min_scale"),
            "policy_risk_gate_mode": config.get(
                "policy_risk_gate_mode", "full_loss"
            ),
            "policy_batch_mode": config.get("policy_batch_mode", "always"),
            "detach_policy_moments": config.get("detach_policy_moments"),
            "conflict_aware_policy_moments": config.get(
                "conflict_aware_policy_moments"
            ),
            "policy_moment_max_grad_ratio": config.get("policy_moment_max_grad_ratio", 1.0),
            "policy_moment_projection_strength": config.get(
                "policy_moment_projection_strength"
            ),
            "policy_moment_projection_scope": config.get(
                "policy_moment_projection_scope"
            ),
            "policy_moment_conflict_energy_threshold": config.get(
                "policy_moment_conflict_energy_threshold"
            ),
            "cross3b_variant": config.get("cross3b_variant"),
            "evaluation_records": summary.get("evaluations", len(records)),
            "final_return": summary.get("final_return"),
            "final_checkpoint_return": summary.get("final_checkpoint_return"),
            "best_checkpoint_return": summary.get("best_checkpoint_return"),
            "heldout_final_return": summary.get("heldout_final_return"),
            "heldout_final_return_std": summary.get("heldout_final_return_std"),
            "heldout_final_episodes": summary.get("heldout_final_episodes", config.get("final_eval_episodes", 0)),
            "policy_stat_gate_scale_mean": record_metric_mean(
                records, "policy_stat_gate_scale_mean"
            ),
            "policy_stat_gate_active_fraction": record_metric_mean(
                records, "policy_stat_gate_active_fraction"
            ),
            "policy_stat_gate_cap_mean_shift": record_metric_mean(
                records, "policy_stat_gate_cap_mean_shift"
            ),
            "policy_stat_gate_cap_log_var_shift": record_metric_mean(
                records, "policy_stat_gate_cap_log_var_shift"
            ),
            "policy_risk_ratio_mean": record_metric_mean(
                records, "policy_risk_ratio_mean"
            ),
            "policy_risk_ratio_p90": record_metric_mean(
                records, "policy_risk_ratio_p90"
            ),
            "policy_risk_scale_mean": record_metric_mean(
                records, "policy_risk_scale_mean"
            ),
            "policy_risk_active_fraction": record_metric_mean(
                records, "policy_risk_active_fraction"
            ),
            "auc": summary.get("auc"),
            "train_wall_seconds": summary.get("train_wall_seconds"),
            "total_wall_seconds": summary.get("total_wall_seconds"),
            "diverged": summary.get("diverged"),
            "path": str(run_dir.relative_to(runs_root.parent)),
        }
        rows.append(row)

    return rows


def mean_std(rows: list[dict[str, Any]], field: str) -> tuple[float | None, float | None]:
    values = [float(row[field]) for row in rows if row.get(field) is not None]
    if not values:
        return None, None
    std = statistics.stdev(values) if len(values) > 1 else 0.0
    return statistics.mean(values), std


def record_metric_mean(
    records: list[dict[str, Any]], field: str
) -> float | None:
    values = [
        record.get("train_metric_means", {}).get(field)
        for record in records
    ]
    values = [float(value) for value in values if value is not None]
    return statistics.mean(values) if values else None


def aggregate_runs(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: defaultdict[tuple[Any, ...], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        if row["category"] != "formal" or row["status"] != "completed":
            continue
        key = (
            row["comparison_family"],
            row["method"],
            row["algo"],
            row["env"],
            row["timesteps"],
            row["eval_freq"],
            row["eval_episodes"],
            row["eval_seed_mode"],
            row["heldout_final_episodes"],
        )
        groups[key].append(row)

    aggregates = []
    for key, group_rows in groups.items():
        final_mean, final_std = mean_std(group_rows, "final_return")
        final_ckpt_mean, final_ckpt_std = mean_std(
            group_rows, "final_checkpoint_return"
        )
        best_ckpt_mean, best_ckpt_std = mean_std(
            group_rows, "best_checkpoint_return"
        )
        auc_mean, auc_std = mean_std(group_rows, "auc")
        wall_mean, wall_std = mean_std(group_rows, "train_wall_seconds")
        heldout_mean, heldout_std = mean_std(group_rows, "heldout_final_return")
        gate_scale_mean, _ = mean_std(
            group_rows, "policy_stat_gate_scale_mean"
        )
        gate_active_mean, _ = mean_std(
            group_rows, "policy_stat_gate_active_fraction"
        )
        gate_cap_mean_shift, _ = mean_std(
            group_rows, "policy_stat_gate_cap_mean_shift"
        )
        gate_cap_log_var_shift, _ = mean_std(
            group_rows, "policy_stat_gate_cap_log_var_shift"
        )
        risk_ratio_mean, _ = mean_std(group_rows, "policy_risk_ratio_mean")
        risk_ratio_p90, _ = mean_std(group_rows, "policy_risk_ratio_p90")
        risk_scale_mean, _ = mean_std(group_rows, "policy_risk_scale_mean")
        risk_active_mean, _ = mean_std(
            group_rows, "policy_risk_active_fraction"
        )
        family, method, algo, env, timesteps, eval_freq, eval_episodes, eval_seed_mode, heldout_episodes = key
        aggregates.append(
            {
                "comparison_family": family,
                "method": method,
                "algo": algo,
                "env": env,
                "timesteps": timesteps,
                "eval_freq": eval_freq,
                "eval_episodes": eval_episodes,
                "eval_seed_mode": eval_seed_mode,
                "seeds": ";".join(
                    str(seed)
                    for seed in sorted(
                        row["seed"] for row in group_rows if row["seed"] is not None
                    )
                ),
                "runs": len(group_rows),
                "final_return_mean": final_mean,
                "final_return_std": final_std,
                "final_vs_crossq_pct": None,
                "final_checkpoint_return_mean": final_ckpt_mean,
                "final_checkpoint_return_std": final_ckpt_std,
                "best_checkpoint_return_mean": best_ckpt_mean,
                "best_checkpoint_return_std": best_ckpt_std,
                "heldout_final_episodes": heldout_episodes,
                "heldout_final_return_mean": heldout_mean,
                "heldout_final_return_std": heldout_std,
                "heldout_final_vs_crossq_pct": None,
                "policy_stat_gate_scale_mean": gate_scale_mean,
                "policy_stat_gate_active_fraction": gate_active_mean,
                "policy_stat_gate_cap_mean_shift": gate_cap_mean_shift,
                "policy_stat_gate_cap_log_var_shift": gate_cap_log_var_shift,
                "policy_risk_ratio_mean": risk_ratio_mean,
                "policy_risk_ratio_p90": risk_ratio_p90,
                "policy_risk_scale_mean": risk_scale_mean,
                "policy_risk_active_fraction": risk_active_mean,
                "auc_mean": auc_mean,
                "auc_std": auc_std,
                "auc_vs_crossq_pct": None,
                "train_wall_seconds_mean": wall_mean,
                "train_wall_seconds_std": wall_std,
                "wall_vs_crossq_pct": None,
                "diverged_runs": sum(bool(row["diverged"]) for row in group_rows),
                "experiments": ";".join(
                    sorted({row["experiment"] for row in group_rows})
                ),
            }
        )

    baselines = {}
    for aggregate in aggregates:
        if aggregate["algo"] == "crossq":
            baselines[protocol_key(aggregate)] = aggregate
    for aggregate in aggregates:
        baseline = baselines.get(protocol_key(aggregate))
        if not baseline:
            continue
        aggregate["final_vs_crossq_pct"] = percent_change(
            aggregate["final_return_mean"], baseline["final_return_mean"]
        )
        aggregate["auc_vs_crossq_pct"] = percent_change(
            aggregate["auc_mean"], baseline["auc_mean"]
        )
        aggregate["wall_vs_crossq_pct"] = percent_change(
            aggregate["train_wall_seconds_mean"],
            baseline["train_wall_seconds_mean"],
        )
        aggregate["heldout_final_vs_crossq_pct"] = percent_change(
            aggregate["heldout_final_return_mean"], baseline["heldout_final_return_mean"]
        )

    return sorted(
        aggregates,
        key=lambda row: (
            row["timesteps"] or 0,
            row["eval_freq"] or 0,
            row["env"] or "",
            row["method"],
        ),
    )


def protocol_key(row: dict[str, Any]) -> tuple[Any, ...]:
    return (
        row["comparison_family"],
        row["env"],
        row["timesteps"],
        row["eval_freq"],
        row["eval_episodes"],
        row["eval_seed_mode"],
        row["seeds"],
        row["heldout_final_episodes"],
    )


def percent_change(value: float | None, baseline: float | None) -> float | None:
    if value is None or baseline in {None, 0}:
        return None
    return 100.0 * (value - baseline) / abs(baseline)


def csv_value(value: Any) -> Any:
    if isinstance(value, float):
        return f"{value:.6f}"
    return value


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({field: csv_value(row.get(field)) for field in fields})


def metric(mean: float | None, std: float | None) -> str:
    if mean is None:
        return "-"
    if std is None:
        return f"{mean:.1f}"
    return f"{mean:.1f} +/- {std:.1f}"


def delta(value: float | None) -> str:
    return "-" if value is None else f"{value:+.1f}%"


def comparison_table(rows: list[dict[str, Any]]) -> list[str]:
    lines = [
        "| 环境 | 方法 | Seeds | Final return | AUC | Final vs CrossQ | AUC vs CrossQ | 训练时间 |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in sorted(
        rows,
        key=lambda item: (
            item["env"],
            0 if item["algo"] == "crossq" else 1,
            item["method"],
        ),
    ):
        lines.append(
            "| {env} | {method} | {seeds} | {final} | {auc} | {final_delta} | "
            "{auc_delta} | {wall} |".format(
                env=row["env"],
                method=row["method"],
                seeds=row["seeds"],
                final=metric(row["final_return_mean"], row["final_return_std"]),
                auc=metric(row["auc_mean"], row["auc_std"]),
                final_delta=delta(row["final_vs_crossq_pct"]),
                auc_delta=delta(row["auc_vs_crossq_pct"]),
                wall=metric(
                    row["train_wall_seconds_mean"],
                    row["train_wall_seconds_std"],
                ),
            )
        )
    return lines


def best_summary(rows: list[dict[str, Any]], label: str) -> list[str]:
    lines = []
    by_env: defaultdict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_env[row["env"]].append(row)
    for env, env_rows in sorted(by_env.items()):
        if len(env_rows) == 1:
            only = env_rows[0]
            lines.append(
                f"- {label} {env}: 仅有 `{only['method']}`，Final "
                f"{only['final_return_mean']:.1f}，AUC {only['auc_mean']:.1f}；"
                "无同协议方法可用于排名。"
            )
            continue
        final_best = max(env_rows, key=lambda row: row["final_return_mean"])
        auc_best = max(env_rows, key=lambda row: row["auc_mean"])
        lines.append(
            f"- {label} {env}: Final 最优 `{final_best['method']}` "
            f"({final_best['final_return_mean']:.1f})；AUC 最优 "
            f"`{auc_best['method']}` ({auc_best['auc_mean']:.1f})。"
        )
    return lines


def render_report(
    run_rows: list[dict[str, Any]], aggregates: list[dict[str, Any]]
) -> str:
    statuses = Counter(row["status"] for row in run_rows)
    formal_completed = [
        row
        for row in run_rows
        if row["category"] == "formal" and row["status"] == "completed"
    ]
    diagnostic_completed = [
        row
        for row in run_rows
        if row["category"] == "diagnostic" and row["status"] == "completed"
    ]
    legacy_1m = [
        row
        for row in aggregates
        if row["timesteps"] == 1_000_000
        and row["eval_freq"] == 10_000
        and row["eval_episodes"] == 1
        and row["env"] in {"Hopper-v4", "Walker2d-v4"}
    ]
    fixed_1m = [
        row
        for row in aggregates
        if row["timesteps"] == 1_000_000
        and row["eval_freq"] == 25_000
        and row["eval_episodes"] == 5
    ]
    screens_300k = [
        row
        for row in aggregates
        if row["timesteps"] == 300_000
        and row["comparison_family"] == "legacy"
        and row["eval_freq"] == 25_000
        and row["eval_episodes"] == 5
    ]

    lines = [
        "# CrossQ / Cross3B 全部训练结果对比",
        "",
        "本报告直接扫描 `runs/**/config.json`、`summary.json` 和 "
        "`evaluations.jsonl` 生成。正式实验按相同环境、步数和评估协议聚合；"
        "smoke、pilot、诊断、失败和中断 run 不参与正式均值。",
        "",
        "## 数据盘点",
        "",
        f"- 正式完成：{len(formal_completed)} runs，{len(aggregates)} 个聚合项。",
        f"- 诊断/短跑完成：{len(diagnostic_completed)} runs（保留在逐 run CSV）。",
        f"- 未完成：{statuses['incomplete'] + statuses['config_only']} runs。",
        f"- 归档失败/中断：{statuses['archived_failed'] + statuses['interrupted']} runs。",
        "- `Final return` 沿用各 run 的 `summary.json` 定义，即最后 5 个评估点均值；"
        "AUC 为训练区间归一化曲线面积。",
        "- `+/-` 是跨 seed 的样本标准差；训练时间单位为秒。",
        "- Ant 1M 的 CrossQ seed 3 和 Cross3B strict seed 3 墙钟时间分别约为 "
        "50.1k/35.1k 秒，远高于其余 seeds 的约 4.8k-5.8k 秒；该组时间均值和 "
        "`vs CrossQ` 仅作记录，不能解释为稳定的速度差。",
        "",
        "## 1M 主实验：旧评估协议",
        "",
        "协议：seeds 0/1/2，每 10k steps 评估 1 个 episode。只有这一组内可直接横比。",
        "",
        *comparison_table(legacy_1m),
        "",
        "## 1M 实验：固定 5-episode 协议",
        "",
        "协议：seeds 3/4/5，每 25k steps 用固定评估种子评估 5 个 episodes。"
        "Ant 有同协议 CrossQ 基线；Hopper/Walker2d 的 global projection 没有匹配的 "
        "CrossQ seeds 3/4/5，因此差值留空。",
        "",
        *comparison_table(fixed_1m),
        "",
        "## 300k 消融筛选",
        "",
        "协议：seeds 0/1/2，每 25k steps 固定评估 5 个 episodes。",
        "",
        *comparison_table(screens_300k),
        "",
        "## 横向结论",
        "",
        *best_summary(legacy_1m, "1M/旧协议"),
        *best_summary(fixed_1m, "1M/5-episode"),
        *best_summary(screens_300k, "300k"),
        "",
        "不同训练预算或不同评估协议之间不应根据绝对 AUC/Final 数值直接定胜负。"
        "尤其是 1M global projection 与旧主实验使用了不同 seeds 和评估方差设置。",
        "",
        "## 未完成与归档 run",
        "",
        "| 状态 | 实验 | 方法 | 环境 | Seed | 进度 | 路径 |",
        "|---|---|---|---|---:|---:|---|",
    ]

    families = sorted({row["comparison_family"] for row in run_rows} - {"legacy"})
    insertion = lines.index("## 横向结论")
    screening_lines = []
    for family in families:
        family_runs = [row for row in run_rows if row["comparison_family"] == family]
        family_aggregates = [row for row in aggregates if row["comparison_family"] == family]
        completed = sum(row["status"] == "completed" for row in family_runs)
        screening_lines.extend([
            f"## 新三批次筛选：{family}", "",
            f"已生成配置 {len(family_runs)} runs，完成 {completed} runs。完整排队计划和实时状态见 "
            f"`runs/{family}/screen_plan.json`、`screen_state.json`。",
            "固定 5-episode 曲线；最终 actor 另用独立 20 episodes 评估。"
            "单独使用本轮 CrossQ 作对照，仅相同 seed 集合显示差值；共享 GPU 时间不用于速度排名。", "",
            *comparison_table(family_aggregates), "",
            "| 环境 | 方法 | Seeds | Heldout final (跨 seed 均值 +/- 标准差) | vs CrossQ |",
            "|---|---|---|---:|---:|",
        ])
        for row in family_aggregates:
            screening_lines.append(
                f"| {row['env']} | {row['method']} | {row['seeds']} | "
                f"{metric(row['heldout_final_return_mean'], row['heldout_final_return_std'])} | "
                f"{delta(row['heldout_final_vs_crossq_pct'])} |"
            )
        screening_lines.append("")
    lines[insertion:insertion] = screening_lines

    outstanding = [row for row in run_rows if row["status"] != "completed"]
    for row in outstanding:
        progress = (
            f"{100.0 * row['completion_ratio']:.1f}%"
            if row["completion_ratio"] is not None
            else "-"
        )
        lines.append(
            f"| {row['status']} | {row['experiment']} | {row['method']} | "
            f"{row['env'] or '-'} | {row['seed'] if row['seed'] is not None else '-'} | "
            f"{progress} | `{row['path']}` |"
        )

    lines.extend(
        [
            "",
            "## 明细文件",
            "",
            "- `results_all_runs.csv`: 每个 run 一行，含配置、状态、进度和指标。",
            "- `results_all_aggregate.csv`: 仅正式完成 run，按可比协议聚合。",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    runs_root = args.runs_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    run_rows = collect_runs(runs_root)
    aggregates = aggregate_runs(run_rows)
    write_csv(output_dir / "results_all_runs.csv", run_rows, RUN_FIELDS)
    write_csv(
        output_dir / "results_all_aggregate.csv", aggregates, AGGREGATE_FIELDS
    )
    (output_dir / "RESULTS_ALL_COMPARISON.md").write_text(
        render_report(run_rows, aggregates), encoding="utf-8"
    )

    print(f"Scanned {len(run_rows)} runs")
    print(f"Aggregated {len(aggregates)} formal result groups")
    print(f"Wrote {output_dir / 'results_all_runs.csv'}")
    print(f"Wrote {output_dir / 'results_all_aggregate.csv'}")
    print(f"Wrote {output_dir / 'RESULTS_ALL_COMPARISON.md'}")


if __name__ == "__main__":
    main()

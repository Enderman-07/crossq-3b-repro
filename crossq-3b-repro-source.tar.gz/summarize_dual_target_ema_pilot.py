"""Summarize the paired CrossQ/Cross3B-DTEMA pilot."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import statistics


BASELINE = "crossq"
METRICS = ("auc", "heldout_final_return")


def mean(values):
    return statistics.mean(values) if values else None


def sample_std(values):
    if not values:
        return None
    return statistics.stdev(values) if len(values) > 1 else 0.0


def percent_change(value, baseline):
    if value is None or baseline in {None, 0.0}:
        return None
    return 100.0 * (value - baseline) / abs(baseline)


def write_json(path, data):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    temporary.replace(path)


def summarize(group):
    plan = json.loads((group / "screen_plan.json").read_text(encoding="utf-8"))
    runs = {}
    missing = []
    for job in plan["jobs"]:
        summary_path = Path(job["run_dir"]) / "summary.json"
        if not summary_path.exists():
            missing.append(job["id"])
            continue
        runs[(job["condition"], job["env"], job["seed"])] = json.loads(
            summary_path.read_text(encoding="utf-8")
        )

    variant_names = [
        condition["name"]
        for condition in plan["conditions"]
        if condition["name"] != BASELINE
    ]
    variants = {}
    for variant in variant_names:
        environments = []
        for env_id in plan["envs"]:
            pairs = []
            for seed in plan["seeds"]:
                baseline = runs.get((BASELINE, env_id, seed))
                candidate = runs.get((variant, env_id, seed))
                if baseline is None or candidate is None:
                    continue
                pairs.append({"seed": seed, "baseline": baseline, "candidate": candidate})
            metrics = {}
            for metric in METRICS:
                baseline_values = [float(row["baseline"][metric]) for row in pairs]
                candidate_values = [float(row["candidate"][metric]) for row in pairs]
                baseline_mean = mean(baseline_values)
                candidate_mean = mean(candidate_values)
                metrics[metric] = {
                    "crossq_mean": baseline_mean,
                    "crossq_std": sample_std(baseline_values),
                    "candidate_mean": candidate_mean,
                    "candidate_std": sample_std(candidate_values),
                    "relative_change_pct": percent_change(candidate_mean, baseline_mean),
                    "paired_wins": sum(
                        candidate > baseline
                        for candidate, baseline in zip(candidate_values, baseline_values)
                    ),
                    "paired_runs": len(pairs),
                }
            complete = len(pairs) == len(plan["seeds"])
            environments.append(
                {
                    "env": env_id,
                    "complete": complete,
                    "passes": complete
                    and all(metrics[metric]["relative_change_pct"] > 0.0 for metric in METRICS),
                    "metrics": metrics,
                }
            )
        variants[variant] = {
            "pass": all(row["passes"] for row in environments),
            "environments": environments,
        }
    complete = not missing
    result = {
        "group": str(group),
        "complete": complete,
        "missing_runs": missing,
        "variants": variants,
    }
    write_json(group / "comparison.json", result)
    write_markdown(group / "comparison.md", result)
    return result


def fmt(value):
    return "-" if value is None else f"{value:+.1f}%"


def metric(mean_value, std_value):
    if mean_value is None:
        return "-"
    return f"{mean_value:.1f} +/- {std_value:.1f}"


def write_markdown(path, result):
    lines = [
        "# Cross3B-DTEMA paired pilot",
        "",
        f"Complete: **{result['complete']}**",
        "",
        "| Variant | Environment | CrossQ AUC | Candidate AUC | AUC delta | AUC wins | CrossQ held-out | Candidate held-out | Held-out delta | Held-out wins |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for variant, variant_result in result["variants"].items():
        for row in variant_result["environments"]:
            auc = row["metrics"]["auc"]
            heldout = row["metrics"]["heldout_final_return"]
            lines.append(
                f"| {variant} | {row['env']} | "
                f"{metric(auc['crossq_mean'], auc['crossq_std'])} | "
                f"{metric(auc['candidate_mean'], auc['candidate_std'])} | "
                f"{fmt(auc['relative_change_pct'])} | "
                f"{auc['paired_wins']}/{auc['paired_runs']} | "
                f"{metric(heldout['crossq_mean'], heldout['crossq_std'])} | "
                f"{metric(heldout['candidate_mean'], heldout['candidate_std'])} | "
                f"{fmt(heldout['relative_change_pct'])} | "
                f"{heldout['paired_wins']}/{heldout['paired_runs']} |"
            )
    lines.extend(
        [
            "",
            "Pass rule: mean AUC and mean held-out return must both exceed paired CrossQ on all three environments.",
            "",
        ]
    )
    path.write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--group-dir", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(summarize(args.group_dir.resolve()), indent=2))


if __name__ == "__main__":
    main()

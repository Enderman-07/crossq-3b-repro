"""Run one CrossQ or Cross3B experiment and record evaluation metrics."""

import argparse
import json
import os
import pathlib
import sys
import time
from datetime import datetime

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "third_party" / "CrossQ"))
os.environ.setdefault("JAX_PLATFORMS", "cpu")
os.environ.setdefault("MPLCONFIGDIR", "/tmp/cross3b-mpl")

import gymnasium as gym
import numpy as np
import optax
from stable_baselines3.common.callbacks import BaseCallback

from cross3b import (
    Cross3B,
    Cross3BActorEMA,
    Cross3BAntitheticTarget,
    Cross3BDualTarget,
    Cross3BDualTargetEMA,
    Cross3BOriginalEMA,
    Cross3BSupport,
)
from cross3b.checkpoint import save_actor_checkpoint
from sbx import SAC
from sbx.sac.utils import ReLU


def evaluate_policy(
    model,
    env_id: str,
    seed: int,
    n_episodes: int,
    max_episode_steps: int,
    return_details: bool = False,
):
    env = gym.make(env_id)
    returns = []
    lengths = []
    try:
        for episode in range(n_episodes):
            obs, _ = env.reset(seed=seed + episode)
            episode_return = 0.0
            episode_length = 0
            for _ in range(max_episode_steps):
                predict = getattr(model, "predict_evaluation", model.predict)
                action, _ = predict(obs, deterministic=True)
                obs, reward, terminated, truncated, _ = env.step(action)
                episode_return += float(reward)
                episode_length += 1
                if terminated or truncated:
                    break
            returns.append(episode_return)
            lengths.append(episode_length)
    finally:
        env.close()
    if return_details:
        return {
            "episodes": n_episodes,
            "eval_seed_start": seed,
            "mean_return": float(np.mean(returns)),
            "std_return": float(np.std(returns)),
            "mean_length": float(np.mean(lengths)),
            "episode_returns": returns,
            "episode_lengths": lengths,
        }
    return float(np.mean(returns)), float(np.mean(lengths))


class MetricsCallback(BaseCallback):
    def __init__(
        self,
        env_id: str,
        seed: int,
        eval_freq: int,
        eval_episodes: int,
        eval_seed_mode: str,
        max_episode_steps: int,
        output_path: pathlib.Path,
        checkpoint_freq: int = 0,
    ):
        super().__init__(verbose=0)
        self.env_id = env_id
        self.seed = seed
        self.eval_freq = eval_freq
        self.eval_episodes = eval_episodes
        self.eval_seed_mode = eval_seed_mode
        self.max_episode_steps = max_episode_steps
        self.output_path = output_path
        self.train_started = None
        self.eval_seconds = 0.0
        self.records = []
        self.checkpoint_freq = checkpoint_freq

    def _on_training_start(self) -> None:
        self.train_started = time.perf_counter()

    def _record(self) -> None:
        eval_started = time.perf_counter()
        eval_seed = self.seed
        if self.eval_seed_mode == "step":
            eval_seed += self.model.num_timesteps
        episode_return, episode_length = evaluate_policy(
            self.model,
            self.env_id,
            eval_seed,
            self.eval_episodes,
            self.max_episode_steps,
        )
        eval_elapsed = time.perf_counter() - eval_started
        self.eval_seconds += eval_elapsed
        total_wall = time.perf_counter() - self.train_started
        record = {
            "timesteps": int(self.model.num_timesteps),
            "episode_return": episode_return,
            "episode_length": episode_length,
            "eval_seed_start": int(eval_seed),
            "train_wall_seconds": total_wall - self.eval_seconds,
            "total_wall_seconds": total_wall,
        }
        if hasattr(self.model, "last_train_metrics"):
            record["train_metrics"] = self.model.last_train_metrics
        if hasattr(self.model, "consume_train_metric_means"):
            record["train_metric_means"] = (
                self.model.consume_train_metric_means()
            )
        self.records.append(record)
        with self.output_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record) + "\n")

    def _on_step(self) -> bool:
        if self.checkpoint_freq > 0 and self.n_calls % self.checkpoint_freq == 0:
            save_actor_checkpoint(
                self.model,
                self.output_path.parent / "checkpoints" / str(self.model.num_timesteps),
            )
        if self.eval_freq > 0 and self.n_calls % self.eval_freq == 0:
            self._record()
        return True

    def _on_training_end(self) -> None:
        if (
            self.eval_freq > 0
            and self.records
            and self.records[-1]["timesteps"] != self.model.num_timesteps
        ):
            self._record()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--algo",
        choices=[
            "crossq",
            "cross3b",
            "cross3b_actor_ema",
            "cross3b_antithetic_target",
            "cross3b_dual_target",
            "cross3b_dual_target_ema",
            "cross3b_original_ema",
            "cross3b_support",
        ],
        required=True,
    )
    parser.add_argument(
        "--env",
        default="Hopper-v4",
    )
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--timesteps", type=int, default=1_000_000)
    parser.add_argument("--eval-freq", type=int, default=10_000)
    parser.add_argument("--eval-episodes", type=int, default=1)
    parser.add_argument(
        "--eval-seed-mode",
        choices=["fixed", "step"],
        default="fixed",
    )
    parser.add_argument("--max-episode-steps", type=int, default=1000)
    parser.add_argument("--learning-starts", type=int, default=5000)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--n-neurons", type=int, default=2048)
    parser.add_argument("--critic-weight-normalization", action="store_true")
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--buffer-size", type=int, default=1_000_000)
    parser.add_argument("--policy-delay", type=int, default=3)
    parser.add_argument("--target-action-samples", type=int, default=2)
    parser.add_argument("--target-action-start-steps", type=int, default=0)
    parser.add_argument("--ema-start-steps", type=int, default=100_000)
    parser.add_argument("--ema-half-life-steps", type=float, default=25_000.0)
    parser.add_argument("--policy-batch-ratio", type=float, default=1.0)
    parser.add_argument("--policy-batch-start-steps", type=int, default=0)
    parser.add_argument("--policy-batch-warmup-updates", type=int, default=0)
    parser.add_argument("--policy-batch-ramp-updates", type=int, default=0)
    parser.add_argument("--action-shift-allocation", action="store_true")
    parser.add_argument("--action-shift-low", type=float, default=0.35)
    parser.add_argument("--action-shift-high", type=float, default=0.45)
    parser.add_argument("--action-shift-warmup-updates", type=int, default=0)
    parser.add_argument(
        "--action-shift-transition-updates", type=int, default=0
    )
    parser.add_argument("--support-coefficient", type=float, default=0.1)
    parser.add_argument("--support-warmup-updates", type=int, default=0)
    parser.add_argument("--support-ramp-updates", type=int, default=0)
    parser.add_argument("--support-quantile", type=float, default=0.9)
    parser.add_argument("--support-learning-rate", type=float, default=1e-3)
    parser.add_argument("--bootstrap-batch-weight", type=float, default=1.0)
    parser.add_argument("--policy-stat-gate", action="store_true")
    parser.add_argument("--policy-stat-mean-budget", type=float, default=0.1)
    parser.add_argument("--policy-stat-log-var-budget", type=float, default=0.1)
    parser.add_argument("--policy-stat-gate-recovery", type=float, default=0.01)
    parser.add_argument("--two-batch-reference-diagnostics", action="store_true")
    parser.add_argument("--two-batch-reference-control", action="store_true")
    parser.add_argument(
        "--two-batch-delta-max-norm-ratio", type=float, default=0.22
    )
    parser.add_argument(
        "--two-batch-control-ema-decay", type=float, default=0.0
    )
    parser.add_argument(
        "--two-batch-control-guard-low-delta", action="store_true"
    )
    parser.add_argument("--policy-risk-threshold", type=float, default=1.5)
    parser.add_argument("--policy-risk-min-scale", type=float, default=0.0)
    parser.add_argument(
        "--policy-risk-gate-mode",
        choices=["full_loss", "q_only"],
        default="full_loss",
    )
    parser.add_argument("--checkpoint-freq", type=int, default=0)
    parser.add_argument("--final-eval-episodes", type=int, default=0)
    parser.add_argument("--detach-policy-moments", action="store_true")
    parser.add_argument(
        "--conflict-aware-policy-moments",
        action="store_true",
    )
    parser.add_argument(
        "--policy-moment-conflict-until-updates", type=int, default=0
    )
    parser.add_argument(
        "--policy-moment-max-grad-ratio",
        type=float,
        default=1.0,
    )
    parser.add_argument(
        "--policy-moment-projection-strength",
        type=float,
        default=1.0,
    )
    parser.add_argument(
        "--policy-moment-projection-scope",
        choices=["global", "layerwise", "adaptive"],
        default="global",
    )
    parser.add_argument(
        "--policy-moment-conflict-energy-threshold",
        type=float,
        default=0.95,
    )
    parser.add_argument(
        "--policy-batch-mode",
        choices=["always", "actor_only"],
        default="always",
    )
    parser.add_argument(
        "--cross3b-variant",
        dest="cross3b_variant",
        choices=[
            "joint",
            "joint_consistent",
            "post_update_eval",
            "post_update_train",
            "policy_risk_probe",
        ],
        default="post_update_eval",
    )
    parser.add_argument(
        "--output-root",
        type=pathlib.Path,
        default=ROOT / "runs",
    )
    parser.add_argument("--run-name", default=None)
    parser.add_argument("--verbose", type=int, default=0)
    return parser.parse_args()


def summarize(records):
    if not records:
        return {
            "evaluations": 0,
            "final_return": None,
            "final_checkpoint_return": None,
            "auc": None,
            "train_wall_seconds": None,
            "diverged": False,
        }

    steps = np.asarray([record["timesteps"] for record in records], dtype=float)
    returns = np.asarray(
        [record["episode_return"] for record in records], dtype=float
    )
    finite = bool(np.isfinite(returns).all())
    if len(records) > 1 and steps[-1] > steps[0]:
        auc = float(np.trapz(returns, steps) / (steps[-1] - steps[0]))
    else:
        auc = float(returns[-1])
    return {
        "evaluations": len(records),
        "final_return": float(np.mean(returns[-min(5, len(returns)) :])),
        "final_checkpoint_return": float(returns[-1]),
        "best_checkpoint_return": float(np.max(returns)),
        "auc": auc,
        "train_wall_seconds": float(records[-1]["train_wall_seconds"]),
        "total_wall_seconds": float(records[-1]["total_wall_seconds"]),
        "diverged": not finite,
    }


def main() -> None:
    args = parse_args()
    if args.timesteps <= 0:
        raise ValueError("--timesteps must be positive")
    if args.batch_size <= 0 or args.n_neurons <= 0:
        raise ValueError("--batch-size and --n-neurons must be positive")
    if args.target_action_samples < 1:
        raise ValueError("--target-action-samples must be positive")
    if args.target_action_start_steps < 0:
        raise ValueError("--target-action-start-steps must be nonnegative")
    if args.policy_batch_start_steps < 0:
        raise ValueError("--policy-batch-start-steps must be nonnegative")
    if args.ema_start_steps < 0:
        raise ValueError("--ema-start-steps must be nonnegative")
    if not np.isfinite(args.ema_half_life_steps) or args.ema_half_life_steps <= 0:
        raise ValueError("--ema-half-life-steps must be finite and positive")
    if (
        args.policy_batch_warmup_updates < 0
        or args.policy_batch_ramp_updates < 0
    ):
        raise ValueError("policy batch schedule updates must be nonnegative")
    if (
        not np.isfinite(args.action_shift_low)
        or not np.isfinite(args.action_shift_high)
        or args.action_shift_low < 0.0
        or args.action_shift_high <= args.action_shift_low
    ):
        raise ValueError(
            "action shift thresholds require 0 <= low < high"
        )
    if (
        args.action_shift_warmup_updates < 0
        or args.action_shift_transition_updates < 0
    ):
        raise ValueError("action shift schedule updates must be nonnegative")
    if args.checkpoint_freq < 0 or args.final_eval_episodes < 0:
        raise ValueError("checkpoint frequency and final episodes must be nonnegative")
    if not np.isfinite(args.bootstrap_batch_weight) or args.bootstrap_batch_weight <= 0:
        raise ValueError("--bootstrap-batch-weight must be finite and positive")
    if not np.isfinite(args.policy_stat_mean_budget) or args.policy_stat_mean_budget <= 0:
        raise ValueError("--policy-stat-mean-budget must be finite and positive")
    if (
        not np.isfinite(args.policy_stat_log_var_budget)
        or args.policy_stat_log_var_budget <= 0
    ):
        raise ValueError("--policy-stat-log-var-budget must be finite and positive")
    if not 0.0 < args.policy_stat_gate_recovery <= 1.0:
        raise ValueError("--policy-stat-gate-recovery must be in (0, 1]")
    if (
        not np.isfinite(args.two_batch_delta_max_norm_ratio)
        or args.two_batch_delta_max_norm_ratio <= 0.0
    ):
        raise ValueError(
            "--two-batch-delta-max-norm-ratio must be finite and positive"
        )
    if not 0.0 <= args.two_batch_control_ema_decay < 1.0:
        raise ValueError("--two-batch-control-ema-decay must be in [0, 1)")
    if not np.isfinite(args.policy_risk_threshold) or args.policy_risk_threshold <= 0:
        raise ValueError("--policy-risk-threshold must be finite and positive")
    if args.policy_moment_conflict_until_updates < 0:
        raise ValueError(
            "--policy-moment-conflict-until-updates must be nonnegative"
        )
    if not 0.0 <= args.policy_risk_min_scale <= 1.0:
        raise ValueError("--policy-risk-min-scale must be in [0, 1]")
    if not np.isfinite(args.support_coefficient) or args.support_coefficient < 0:
        raise ValueError("--support-coefficient must be finite and nonnegative")
    if args.support_warmup_updates < 0 or args.support_ramp_updates < 0:
        raise ValueError("support schedule updates must be nonnegative")
    if not 0.0 < args.support_quantile < 1.0:
        raise ValueError("--support-quantile must be in (0, 1)")
    if not np.isfinite(args.support_learning_rate) or args.support_learning_rate <= 0:
        raise ValueError("--support-learning-rate must be finite and positive")
    if args.algo == "crossq" and args.bootstrap_batch_weight != 1.0:
        raise ValueError("weighted bootstrap requires --algo cross3b")
    if args.algo == "crossq" and (
        args.policy_batch_warmup_updates or args.policy_batch_ramp_updates
    ):
        raise ValueError("policy batch schedule requires --algo cross3b")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    run_name = args.run_name or (
        f"{args.algo}_{args.env}_seed{args.seed}_{timestamp}"
    )
    run_dir = args.output_root / run_name
    run_dir.mkdir(parents=True, exist_ok=False)
    records_path = run_dir / "evaluations.jsonl"
    records_path.touch()

    config = vars(args).copy()
    config["output_root"] = str(config["output_root"])
    config["run_name"] = run_name
    (run_dir / "config.json").write_text(
        json.dumps(config, indent=2), encoding="utf-8"
    )

    env = gym.make(args.env)
    policy_kwargs = dict(
        activation_fn=ReLU,
        net_arch={
            "pi": [256, 256],
            "qf": [args.n_neurons, args.n_neurons],
        },
        batch_norm=True,
        batch_norm_momentum=0.99,
        batch_norm_mode="brn_actor",
        n_critics=2,
        critic_weight_normalization=args.critic_weight_normalization,
        optimizer_class=optax.adam,
        optimizer_kwargs={"b1": 0.5, "b2": 0.999},
    )
    common_kwargs = dict(
        policy_kwargs=policy_kwargs,
        gradient_steps=1,
        policy_delay=args.policy_delay,
        crossq_style=True,
        tau=1.0,
        learning_starts=args.learning_starts,
        learning_rate=args.learning_rate,
        qf_learning_rate=args.learning_rate,
        buffer_size=args.buffer_size,
        batch_size=args.batch_size,
        gamma=0.99,
        seed=args.seed,
        verbose=args.verbose,
        stats_window_size=1,
    )
    model_class = {
        "crossq": SAC,
        "cross3b": Cross3B,
        "cross3b_actor_ema": Cross3BActorEMA,
        "cross3b_antithetic_target": Cross3BAntitheticTarget,
        "cross3b_dual_target": Cross3BDualTarget,
        "cross3b_dual_target_ema": Cross3BDualTargetEMA,
        "cross3b_original_ema": Cross3BOriginalEMA,
        "cross3b_support": Cross3BSupport,
    }[args.algo]
    if args.algo == "cross3b":
        common_kwargs["cross3b_variant"] = args.cross3b_variant
        common_kwargs["policy_batch_ratio"] = args.policy_batch_ratio
        common_kwargs["policy_batch_warmup_updates"] = (
            args.policy_batch_warmup_updates
        )
        common_kwargs["policy_batch_ramp_updates"] = (
            args.policy_batch_ramp_updates
        )
        common_kwargs["action_shift_allocation"] = (
            args.action_shift_allocation
        )
        common_kwargs["action_shift_low"] = args.action_shift_low
        common_kwargs["action_shift_high"] = args.action_shift_high
        common_kwargs["action_shift_warmup_updates"] = (
            args.action_shift_warmup_updates
        )
        common_kwargs["action_shift_transition_updates"] = (
            args.action_shift_transition_updates
        )
        common_kwargs["bootstrap_batch_weight"] = args.bootstrap_batch_weight
        common_kwargs["policy_stat_gate"] = args.policy_stat_gate
        common_kwargs["policy_stat_mean_budget"] = args.policy_stat_mean_budget
        common_kwargs["policy_stat_log_var_budget"] = (
            args.policy_stat_log_var_budget
        )
        common_kwargs["policy_stat_gate_recovery"] = (
            args.policy_stat_gate_recovery
        )
        common_kwargs["two_batch_reference_diagnostics"] = (
            args.two_batch_reference_diagnostics
        )
        common_kwargs["two_batch_reference_control"] = (
            args.two_batch_reference_control
        )
        common_kwargs["two_batch_delta_max_norm_ratio"] = (
            args.two_batch_delta_max_norm_ratio
        )
        common_kwargs["two_batch_control_ema_decay"] = (
            args.two_batch_control_ema_decay
        )
        common_kwargs["two_batch_control_guard_low_delta"] = (
            args.two_batch_control_guard_low_delta
        )
        common_kwargs["policy_risk_threshold"] = args.policy_risk_threshold
        common_kwargs["policy_risk_min_scale"] = args.policy_risk_min_scale
        common_kwargs["policy_risk_gate_mode"] = args.policy_risk_gate_mode
        common_kwargs["policy_batch_mode"] = args.policy_batch_mode
        common_kwargs["detach_policy_moments"] = args.detach_policy_moments
        common_kwargs["conflict_aware_policy_moments"] = (
            args.conflict_aware_policy_moments
        )
        common_kwargs["policy_moment_conflict_until_updates"] = (
            args.policy_moment_conflict_until_updates
        )
        common_kwargs["policy_moment_max_grad_ratio"] = (
            args.policy_moment_max_grad_ratio
        )
        common_kwargs["policy_moment_projection_strength"] = (
            args.policy_moment_projection_strength
        )
        common_kwargs["policy_moment_projection_scope"] = (
            args.policy_moment_projection_scope
        )
        common_kwargs["policy_moment_conflict_energy_threshold"] = (
            args.policy_moment_conflict_energy_threshold
        )
    elif args.algo == "cross3b_actor_ema":
        common_kwargs["ema_start_steps"] = args.ema_start_steps
        common_kwargs["ema_half_life_steps"] = args.ema_half_life_steps
    elif args.algo == "cross3b_original_ema":
        common_kwargs["policy_batch_start_steps"] = (
            args.policy_batch_start_steps
        )
        common_kwargs["ema_start_steps"] = args.ema_start_steps
        common_kwargs["ema_half_life_steps"] = args.ema_half_life_steps
    elif args.algo == "cross3b_dual_target_ema":
        common_kwargs["target_action_samples"] = args.target_action_samples
        common_kwargs["target_action_start_steps"] = (
            args.target_action_start_steps
        )
        common_kwargs["ema_start_steps"] = args.ema_start_steps
        common_kwargs["ema_half_life_steps"] = args.ema_half_life_steps
    elif args.algo in {
        "cross3b_antithetic_target",
        "cross3b_dual_target",
    }:
        common_kwargs["target_action_samples"] = args.target_action_samples
        if args.algo == "cross3b_dual_target":
            common_kwargs["target_action_start_steps"] = (
                args.target_action_start_steps
            )
    elif args.algo == "cross3b_support":
        common_kwargs["support_coefficient"] = args.support_coefficient
        common_kwargs["support_warmup_updates"] = args.support_warmup_updates
        common_kwargs["support_ramp_updates"] = args.support_ramp_updates
        common_kwargs["support_quantile"] = args.support_quantile
        common_kwargs["support_learning_rate"] = args.support_learning_rate
    model = model_class("MlpPolicy", env, **common_kwargs)

    callback = MetricsCallback(
        env_id=args.env,
        seed=args.seed + 100_000,
        eval_freq=args.eval_freq,
        eval_episodes=args.eval_episodes,
        eval_seed_mode=args.eval_seed_mode,
        max_episode_steps=args.max_episode_steps,
        output_path=records_path,
        checkpoint_freq=args.checkpoint_freq,
    )
    model.learn(
        total_timesteps=args.timesteps,
        callback=callback,
        progress_bar=False,
    )
    save_actor_checkpoint(model, run_dir)

    final_evaluation = None
    if args.final_eval_episodes:
        final_evaluation = evaluate_policy(
            model,
            args.env,
            args.seed + 200_000,
            args.final_eval_episodes,
            args.max_episode_steps,
            return_details=True,
        )
        (run_dir / "final_evaluation.json").write_text(
            json.dumps(final_evaluation, indent=2), encoding="utf-8"
        )

    summary = {
        "algo": args.algo,
        "env": args.env,
        "seed": args.seed,
        "timesteps": int(model.num_timesteps),
        "checkpoint_dir": str(run_dir),
        **summarize(callback.records),
    }
    if final_evaluation is not None:
        summary["heldout_final_return"] = final_evaluation["mean_return"]
        summary["heldout_final_return_std"] = final_evaluation["std_return"]
        summary["heldout_final_episodes"] = final_evaluation["episodes"]
    (run_dir / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(json.dumps({"run_dir": str(run_dir), **summary}, indent=2))
    env.close()


if __name__ == "__main__":
    main()

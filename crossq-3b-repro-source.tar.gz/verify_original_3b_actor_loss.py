"""Verify that original 3B actor loss uses only the policy batch."""

import os
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "third_party" / "CrossQ"))
os.environ.setdefault("JAX_PLATFORMS", "cpu")
os.environ.setdefault("MPLCONFIGDIR", "/tmp/cross3b-mpl")

import jax.numpy as jnp
import numpy as np

from cross3b.agent import _joint_actor_loss_from_outputs


def main() -> None:
    # Shape: [critic, current/bootstrap/policy samples, value].  The first
    # four samples are deliberately extreme so they expose a wrong batch slice.
    q_values = jnp.asarray(
        [
            [[100.0], [101.0], [200.0], [201.0], [1.0], [3.0]],
            [[-100.0], [-101.0], [-200.0], [-201.0], [2.0], [0.0]],
        ]
    )
    log_prob = jnp.asarray([[0.25], [-0.75]])

    loss_without_entropy = _joint_actor_loss_from_outputs(
        q_values,
        log_prob,
        0.0,
    )
    # min(Q1, Q2) on policy samples is [1, 0].
    expected_without_entropy = -0.5

    loss_with_entropy = _joint_actor_loss_from_outputs(
        q_values,
        log_prob,
        0.2,
    )
    expected_with_entropy = np.mean(0.2 * np.asarray([0.25, -0.75]) - [1.0, 0.0])

    checks = {
        "policy_batch_only": np.isclose(
            float(loss_without_entropy), expected_without_entropy
        ),
        "entropy_term_preserved": np.isclose(
            float(loss_with_entropy), expected_with_entropy
        ),
    }
    print(checks)
    if not all(checks.values()):
        raise SystemExit("original 3B actor-loss verification failed")
    print("ORIGINAL_3B_ACTOR_LOSS_OK")


if __name__ == "__main__":
    main()

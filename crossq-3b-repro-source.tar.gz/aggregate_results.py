"""Aggregate CrossQ/Cross3B summaries and evaluation curves."""

import argparse
import csv
import json
import pathlib
from collections import defaultdict

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_root", type=pathlib.Path)
    parser.add_argument(
        "--reference-root",
        type=pathlib.Path,
        action="append",
        default=[],
        help="Additional completed matrix to include in the comparison.",
    )
    parser.add_argument(
        "--reference-algos",
        nargs="+",
        choices=["crossq", "cross3b"],
        default=None,
        help="Only include these algorithms from reference roots.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary_paths = {
        path
        for path in args.run_root.glob("**/summary.json")
        if "_failed" not in path.parts
    }
    allowed_reference_algos = (
        set(args.reference_algos) if args.reference_algos else None
    )
    for root in args.reference_root:
        for path in root.glob("**/summary.json"):
            if "_failed" in path.parts:
                continue
            if allowed_reference_algos is not None:
                algo = json.loads(path.read_text(encoding="utf-8"))["algo"]
                if algo not in allowed_reference_algos:
                    continue
            summary_paths.add(path)
    summary_paths = sorted(summary_paths)
    if not summary_paths:
        raise SystemExit(f"No summary.json files under {args.run_root}")

    summaries = [
        json.loads(path.read_text(encoding="utf-8")) for path in summary_paths
    ]
    grouped = defaultdict(list)
    for summary in summaries:
        grouped[(summary["algo"], summary["env"])].append(summary)

    aggregate = []
    for (algo, env_id), runs in sorted(grouped.items()):
        aggregate.append(
            {
                "algo": algo,
                "env": env_id,
                "runs": len(runs),
                "final_return_mean": float(
                    np.mean([run["final_return"] for run in runs])
                ),
                "final_return_std": float(
                    np.std([run["final_return"] for run in runs], ddof=1)
                    if len(runs) > 1
                    else 0.0
                ),
                "auc_mean": float(np.mean([run["auc"] for run in runs])),
                "auc_std": float(
                    np.std([run["auc"] for run in runs], ddof=1)
                    if len(runs) > 1
                    else 0.0
                ),
                "train_wall_seconds_mean": float(
                    np.mean([run["train_wall_seconds"] for run in runs])
                ),
                "diverged_runs": int(
                    sum(bool(run["diverged"]) for run in runs)
                ),
            }
        )

    (args.run_root / "aggregate.json").write_text(
        json.dumps(aggregate, indent=2), encoding="utf-8"
    )
    with (args.run_root / "aggregate.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=aggregate[0].keys())
        writer.writeheader()
        writer.writerows(aggregate)

    curve_rows = []
    for summary_path in summary_paths:
        run_dir = summary_path.parent
        records_path = run_dir / "evaluations.jsonl"
        if not records_path.exists():
            continue
        for line in records_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            record = json.loads(line)
            run = json.loads(summary_path.read_text(encoding="utf-8"))
            curve_rows.append(
                {
                    "algo": run["algo"],
                    "env": run["env"],
                    "seed": run["seed"],
                    "timesteps": record["timesteps"],
                    "episode_return": record["episode_return"],
                    "train_wall_seconds": record["train_wall_seconds"],
                }
            )

    if curve_rows:
        with (args.run_root / "curves.csv").open(
            "w", newline="", encoding="utf-8"
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=curve_rows[0].keys())
            writer.writeheader()
            writer.writerows(curve_rows)

    print(f"Wrote {args.run_root / 'aggregate.json'}")
    print(f"Wrote {args.run_root / 'aggregate.csv'}")
    if curve_rows:
        print(f"Wrote {args.run_root / 'curves.csv'}")


if __name__ == "__main__":
    main()

"""Prepare, run, and inspect the paired CrossQ-WN/Cross3B-WN pilot."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import queue
import shutil
import subprocess
import threading
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parent
CONDITIONS = [
    {"name": "crossq-wn", "algo": "crossq", "policy": 0.0},
    {"name": "cross3b-wn-r050", "algo": "cross3b", "policy": 0.5},
]


def now():
    return datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds")


def write_json(path, data):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    temporary.replace(path)


def prepare(args):
    group = args.group_dir.resolve()
    group.mkdir(parents=True, exist_ok=False)
    snapshot = group / "source"
    snapshot.mkdir()
    shutil.copytree(
        ROOT / "cross3b",
        snapshot / "cross3b",
        ignore=shutil.ignore_patterns("__pycache__"),
    )
    shutil.copytree(
        ROOT / "third_party" / "CrossQ",
        snapshot / "third_party" / "CrossQ",
        ignore=shutil.ignore_patterns("__pycache__"),
    )
    source_files = [
        ROOT / "run_experiment.py",
        ROOT / "run_cross3b_wn_pilot.py",
        ROOT / "EXPERIMENT_CROSS3B_WN_20261031.md",
    ]
    for source in source_files:
        shutil.copy2(source, snapshot / source.name)

    hash_paths = [
        *source_files,
        *sorted((ROOT / "cross3b").glob("*.py")),
        ROOT / "third_party" / "CrossQ" / "sbx" / "sac" / "sac.py",
        ROOT / "third_party" / "CrossQ" / "sbx" / "sac" / "policies.py",
    ]
    hashes = {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in hash_paths
    }

    jobs = []
    for env_id in args.envs:
        for condition in CONDITIONS:
            for seed in args.seeds:
                run_name = f"{condition['algo']}_{env_id}_seed{seed}"
                output_root = group / condition["name"]
                run_dir = output_root / run_name
                command = [
                    str(ROOT / ".venv" / "bin" / "python"),
                    "-u",
                    str(snapshot / "run_experiment.py"),
                    "--algo",
                    condition["algo"],
                    "--env",
                    env_id,
                    "--seed",
                    str(seed),
                    "--timesteps",
                    str(args.timesteps),
                    "--eval-freq",
                    "25000",
                    "--eval-episodes",
                    "5",
                    "--eval-seed-mode",
                    "fixed",
                    "--batch-size",
                    "256",
                    "--n-neurons",
                    "2048",
                    "--policy-delay",
                    "3",
                    "--learning-rate",
                    "0.001",
                    "--policy-batch-ratio",
                    str(condition["policy"]),
                    "--critic-weight-normalization",
                    "--checkpoint-freq",
                    "100000",
                    "--final-eval-episodes",
                    "20",
                    "--output-root",
                    str(output_root),
                    "--run-name",
                    run_name,
                ]
                jobs.append(
                    {
                        "id": f"{condition['name']}/{run_name}",
                        "condition": condition["name"],
                        "env": env_id,
                        "seed": seed,
                        "run_dir": str(run_dir),
                        "command": command,
                    }
                )

    plan = {
        "name": group.name,
        "created_at": now(),
        "total_runs": len(jobs),
        "timesteps": args.timesteps,
        "envs": args.envs,
        "seeds": args.seeds,
        "conditions": CONDITIONS,
        "source_sha256": hashes,
        "source_snapshot": str(snapshot),
        "jobs": jobs,
        "evaluation": "fixed +100000 seeds, 5 episodes; heldout +200000, 20 episodes",
        "decision": (
            "Continue to seeds 1/2 only if seed-0 WN runs remain finite and "
            "Cross3B-WN has no clear cross-environment AUC regression."
        ),
    }
    write_json(group / "screen_plan.json", plan)
    for condition in CONDITIONS:
        condition_dir = group / condition["name"]
        condition_dir.mkdir()
        write_json(
            condition_dir / "matrix_plan.json",
            {
                "matrix_name": condition["name"],
                "total_runs": len(args.seeds) * len(args.envs),
                "timesteps": args.timesteps,
                "condition": condition,
                "planned_runs": [
                    Path(job["run_dir"]).name
                    for job in jobs
                    if job["condition"] == condition["name"]
                ],
            },
        )
    print(f"Prepared {len(jobs)} runs: {group}")


def run(args):
    group = args.group_dir.resolve()
    plan = json.loads((group / "screen_plan.json").read_text())
    guard = (group / "controller.lock").open("a")
    try:
        fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit("This pilot already has an active controller")

    jobs = queue.Queue()
    for job in plan["jobs"]:
        jobs.put(job)
    state = {
        "controller_pid": os.getpid(),
        "started_at": now(),
        "jobs": {},
        "gpus": args.gpus,
        "workers_per_gpu": args.workers_per_gpu,
    }
    mutex = threading.Lock()

    def record(job, **values):
        with mutex:
            state["jobs"].setdefault(job["id"], {}).update(
                values, updated_at=now()
            )
            write_json(group / "screen_state.json", state)

    def worker(gpu, slot):
        failures = 0
        while True:
            try:
                job = jobs.get_nowait()
            except queue.Empty:
                return
            run_dir = Path(job["run_dir"])
            if (run_dir / "summary.json").exists():
                record(job, status="completed", gpu=gpu, slot=slot)
                continue
            if run_dir.exists():
                record(
                    job,
                    status="incomplete",
                    gpu=gpu,
                    slot=slot,
                    error="Existing unfinished directory preserved",
                )
                continue
            environment = os.environ.copy()
            environment.update(
                CUDA_VISIBLE_DEVICES=str(gpu),
                JAX_PLATFORMS="cuda",
                XLA_PYTHON_CLIENT_PREALLOCATE="false",
                XLA_PYTHON_CLIENT_MEM_FRACTION="0.45",
                OMP_NUM_THREADS="2",
                OPENBLAS_NUM_THREADS="1",
                MKL_NUM_THREADS="1",
                PYTHONUNBUFFERED="1",
            )
            log_path = run_dir.parent / f"{run_dir.name}.log"
            with log_path.open("a", encoding="utf-8") as log:
                process = subprocess.Popen(
                    [str(ROOT / "run_gpu.sh"), *job["command"]],
                    cwd=group / "source",
                    env=environment,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                )
                record(
                    job,
                    status="running",
                    pid=process.pid,
                    gpu=gpu,
                    slot=slot,
                    log=str(log_path),
                    started_at=now(),
                )
                code = process.wait()
            completed = code == 0 and (run_dir / "summary.json").exists()
            record(
                job,
                status="completed" if completed else "failed",
                exit_code=code,
            )
            failures = 0 if completed else failures + 1
            if failures >= 2:
                return

    with ThreadPoolExecutor(
        max_workers=len(args.gpus) * args.workers_per_gpu
    ) as pool:
        futures = [
            pool.submit(worker, gpu, slot)
            for gpu in args.gpus
            for slot in range(args.workers_per_gpu)
        ]
        for future in futures:
            future.result()
    state["finished_at"] = now()
    state["pending_runs"] = jobs.qsize()
    write_json(group / "screen_state.json", state)
    print(f"PILOT_FINISHED {group} pending={jobs.qsize()}", flush=True)


def status(args):
    group = args.group_dir.resolve()
    plan = json.loads((group / "screen_plan.json").read_text())
    state_path = group / "screen_state.json"
    states = (
        json.loads(state_path.read_text()).get("jobs", {})
        if state_path.exists()
        else {}
    )
    counts = {}
    active = []
    progress = 0.0
    for job in plan["jobs"]:
        run_dir = Path(job["run_dir"])
        entry = states.get(job["id"], {})
        phase = (
            "completed"
            if (run_dir / "summary.json").exists()
            else entry.get("status", "pending")
        )
        counts[phase] = counts.get(phase, 0) + 1
        records = []
        evaluations = run_dir / "evaluations.jsonl"
        if evaluations.exists():
            for line in evaluations.read_text().splitlines():
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
        step = (
            plan["timesteps"]
            if phase == "completed"
            else (records[-1]["timesteps"] if records else 0)
        )
        progress += min(step / plan["timesteps"], 1.0)
        if phase in {"running", "failed", "incomplete"}:
            latest = f"{records[-1]['episode_return']:.1f}" if records else "-"
            active.append(
                f"{phase:10} gpu={entry.get('gpu', '-')} {job['id']} "
                f"{step}/{plan['timesteps']} return={latest}"
            )
    print(f"{group}\n{now()} {counts}; evaluated progress={progress / len(plan['jobs']):.1%}")
    print("\n".join(active))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["prepare", "run", "status"])
    parser.add_argument("--group-dir", type=Path, required=True)
    parser.add_argument("--gpus", type=int, nargs="+", default=[0, 1])
    parser.add_argument("--workers-per-gpu", type=int, default=1)
    parser.add_argument(
        "--envs",
        nargs="+",
        default=["Walker2d-v4", "Hopper-v4", "Ant-v4"],
    )
    parser.add_argument("--seeds", type=int, nargs="+", default=[0])
    parser.add_argument("--timesteps", type=int, default=300_000)
    args = parser.parse_args()
    if args.workers_per_gpu < 1 or args.timesteps < 1:
        parser.error("workers and timesteps must be positive")
    if len(set(args.gpus)) != len(args.gpus):
        parser.error("GPU IDs must be unique")
    {"prepare": prepare, "run": run, "status": status}[args.action](args)


if __name__ == "__main__":
    main()

"""Cross3B-EMA: preserve CrossQ training and evaluate a tail-averaged actor."""

import math

import jax
import jax.numpy as jnp
import numpy as np
from gymnasium import spaces

from sbx.common.policies import BaseJaxPolicy
from sbx.sac.sac import SAC


class Cross3BActorEMA(SAC):
    """Official CrossQ with an evaluation-only EMA of the actor state."""

    def __init__(
        self,
        *args,
        ema_start_steps: int = 100_000,
        ema_half_life_steps: float = 25_000.0,
        **kwargs,
    ):
        if ema_start_steps < 0:
            raise ValueError("ema_start_steps must be nonnegative")
        if not math.isfinite(ema_half_life_steps) or ema_half_life_steps <= 0:
            raise ValueError("ema_half_life_steps must be finite and positive")
        self.ema_start_steps = ema_start_steps
        self.ema_half_life_steps = ema_half_life_steps
        self.ema_decay = math.exp(math.log(0.5) / ema_half_life_steps)
        self.last_train_metrics = {}
        super().__init__(*args, **kwargs)
        self.ema_actor_state = self.policy.actor_state

    @staticmethod
    @jax.jit
    def _update_ema_actor(ema_state, online_state, decay):
        def average(old, new):
            if jnp.issubdtype(old.dtype, jnp.inexact):
                return decay * old + (1.0 - decay) * new
            return new

        params = jax.tree_util.tree_map(
            average,
            ema_state.params,
            online_state.params,
        )
        batch_stats = jax.tree_util.tree_map(
            average,
            ema_state.batch_stats,
            online_state.batch_stats,
        )
        return ema_state.replace(
            step=online_state.step,
            params=params,
            batch_stats=batch_stats,
        )

    def train(self, batch_size, gradient_steps):
        super().train(batch_size, gradient_steps)
        self._update_evaluation_actor(gradient_steps)

    def _update_evaluation_actor(self, gradient_steps):
        """Advance the evaluation-only EMA after an online training step."""
        base_metrics = dict(getattr(self, "last_train_metrics", {}))
        if self._n_updates <= self.ema_start_steps:
            self.ema_actor_state = self.policy.actor_state
            effective_decay = 0.0
        else:
            effective_decay = self.ema_decay**gradient_steps
            self.ema_actor_state = self._update_ema_actor(
                self.ema_actor_state,
                self.policy.actor_state,
                effective_decay,
            )
        base_metrics.update(
            ema_active=float(self._n_updates > self.ema_start_steps),
            ema_decay=float(effective_decay),
        )
        self.last_train_metrics = base_metrics

    def evaluation_actor_state(self):
        if self._n_updates <= self.ema_start_steps:
            return self.policy.actor_state
        return self.ema_actor_state

    def predict_evaluation(
        self,
        observation,
        state=None,
        episode_start=None,
        deterministic=True,
    ):
        if not deterministic:
            return self.predict(
                observation,
                state=state,
                episode_start=episode_start,
                deterministic=False,
            )
        observation, vectorized_env = self.policy.prepare_obs(observation)
        actions = BaseJaxPolicy.select_action(
            self.evaluation_actor_state(), observation
        )
        actions = np.array(actions).reshape(
            (-1, *self.action_space.shape)
        )
        if isinstance(self.action_space, spaces.Box):
            if self.policy.squash_output:
                actions = np.clip(actions, -1, 1)
                actions = self.policy.unscale_action(actions)
            else:
                actions = np.clip(
                    actions,
                    self.action_space.low,
                    self.action_space.high,
                )
        if not vectorized_env:
            actions = actions.squeeze(axis=0)
        return actions, state

"""CrossQ with an independent conditional action-support model."""

from __future__ import annotations

from functools import partial
from typing import Sequence

import flax
import flax.linen as nn
import jax
import jax.numpy as jnp
import numpy as np
import optax
from flax.training.train_state import TrainState
from gymnasium import spaces

from sbx.common.type_aliases import ReplayBufferSamplesNp
from sbx.sac.sac import SAC


class ConditionalActionSupport(nn.Module):
    action_dim: int
    hidden_dims: Sequence[int] = (128, 128)

    @nn.compact
    def __call__(self, observations):
        x = observations
        for width in self.hidden_dims:
            x = nn.relu(nn.Dense(width)(x))
        output = nn.Dense(2 * self.action_dim)(x)
        mean, log_std = jnp.split(output, 2, axis=-1)
        mean = jnp.tanh(mean)
        log_std = jnp.clip(log_std, -4.0, 1.0)
        return mean, log_std


def action_nll(mean, log_std, actions):
    """Diagonal Gaussian NLL per action dimension, without constants."""
    normalized = (actions - mean) * jnp.exp(-log_std)
    return jnp.mean(0.5 * jnp.square(normalized) + log_std, axis=-1)


class Cross3BSupport(SAC):
    """Keep CrossQ's critic exact and regularize only unsupported actor moves."""

    def __init__(
        self,
        *args,
        support_coefficient: float = 0.1,
        support_warmup_updates: int = 0,
        support_ramp_updates: int = 0,
        support_quantile: float = 0.9,
        support_learning_rate: float = 1e-3,
        support_hidden_dims: Sequence[int] = (128, 128),
        **kwargs,
    ):
        if support_coefficient < 0.0 or not np.isfinite(support_coefficient):
            raise ValueError("support_coefficient must be finite and nonnegative")
        if not 0.0 < support_quantile < 1.0:
            raise ValueError("support_quantile must be in (0, 1)")
        if support_learning_rate <= 0.0 or not np.isfinite(support_learning_rate):
            raise ValueError("support_learning_rate must be finite and positive")
        self.support_coefficient = float(support_coefficient)
        if support_warmup_updates < 0 or support_ramp_updates < 0:
            raise ValueError("support schedule updates must be nonnegative")
        self.support_warmup_updates = int(support_warmup_updates)
        self.support_ramp_updates = int(support_ramp_updates)
        self.support_quantile = float(support_quantile)
        self.support_learning_rate = float(support_learning_rate)
        self.support_hidden_dims = tuple(int(width) for width in support_hidden_dims)
        if not self.support_hidden_dims or min(self.support_hidden_dims) <= 0:
            raise ValueError("support_hidden_dims must contain positive widths")
        self._support_metric_sums = {}
        self._support_metric_count = 0
        self._support_actor_metric_sums = {}
        self._support_actor_metric_count = 0
        super().__init__(*args, **kwargs)

    def _setup_model(self):
        super()._setup_model()
        if hasattr(self, "support_state"):
            return
        observation_dim = spaces.flatdim(self.observation_space)
        action_dim = int(np.prod(self.action_space.shape))
        observations = jnp.zeros((1, observation_dim), dtype=jnp.float32)
        support_key = jax.random.PRNGKey((int(self.seed or 0) + 9173) % (2**31))
        self.support_model = ConditionalActionSupport(
            action_dim=action_dim,
            hidden_dims=self.support_hidden_dims,
        )
        support_params = self.support_model.init(
            support_key, observations
        )["params"]
        self.support_state = TrainState.create(
            apply_fn=self.support_model.apply,
            params=support_params,
            tx=optax.adam(self.support_learning_rate),
        )

    def train(self, batch_size, gradient_steps):
        data = self.replay_buffer.sample(
            batch_size * gradient_steps, env=self._vec_normalize_env
        )
        policy_delay_indices = {
            i: True
            for i in range(gradient_steps)
            if ((self._n_updates + i + 1) % self.policy_delay) == 0
        }
        policy_delay_indices = flax.core.FrozenDict(policy_delay_indices)

        if isinstance(data.observations, dict):
            keys = list(self.observation_space.keys())
            observations = np.concatenate(
                [data.observations[key].numpy() for key in keys], axis=1
            )
            next_observations = np.concatenate(
                [data.next_observations[key].numpy() for key in keys], axis=1
            )
        else:
            observations = data.observations.numpy()
            next_observations = data.next_observations.numpy()
        data = ReplayBufferSamplesNp(
            observations,
            data.actions.numpy(),
            next_observations,
            data.dones.numpy().flatten(),
            data.rewards.numpy().flatten(),
        )

        self.support_state, support_metrics = self.update_support(
            self.support_state, data.observations, data.actions
        )
        effective_coefficient = self.current_support_coefficient()
        if effective_coefficient == 0.0:
            (
                self.policy.qf_state,
                self.policy.actor_state,
                self.ent_coef_state,
                self.key,
                train_metrics,
            ) = SAC._train(
                self.crossq_style,
                self.td3_mode,
                self.use_bnstats_from_live_net,
                self.gamma,
                self.tau,
                self.target_entropy,
                gradient_steps,
                data,
                policy_delay_indices,
                self.policy.qf_state,
                self.policy.actor_state,
                self.ent_coef_state,
                self.key,
                self.policy_q_reduce_fn,
            )
        else:
            (
                self.policy.qf_state,
                self.policy.actor_state,
                self.ent_coef_state,
                self.key,
                train_metrics,
            ) = self._train_guarded(
                self.crossq_style,
                self.td3_mode,
                self.use_bnstats_from_live_net,
                self.gamma,
                self.tau,
                self.target_entropy,
                gradient_steps,
                data,
                policy_delay_indices,
                self.policy.qf_state,
                self.policy.actor_state,
                self.ent_coef_state,
                self.support_state,
                self.key,
                effective_coefficient,
                self.support_quantile,
                self.policy_q_reduce_fn,
            )
        self._n_updates += gradient_steps
        metrics = {
            **train_metrics,
            **support_metrics,
            "support_effective_coefficient": jnp.asarray(
                effective_coefficient, dtype=jnp.float32
            ),
        }
        self.last_train_metrics = {
            name: float(value.item()) for name, value in metrics.items()
        }
        actor_update = bool(
            self.last_train_metrics.get("support_actor_update", 0.0)
        )
        for name, value in self.last_train_metrics.items():
            if name.startswith("support_actor_") and name != "support_actor_update":
                if actor_update:
                    self._support_actor_metric_sums[name] = (
                        self._support_actor_metric_sums.get(name, 0.0) + value
                    )
            else:
                self._support_metric_sums[name] = (
                    self._support_metric_sums.get(name, 0.0) + value
                )
            self.logger.record(f"train/{name}", value)
        if actor_update:
            self._support_actor_metric_count += 1
        self._support_metric_count += 1
        self.logger.record("train/n_updates", self._n_updates, exclude="tensorboard")

    def consume_train_metric_means(self):
        if self._support_metric_count == 0:
            return {}
        means = {
            name: value / self._support_metric_count
            for name, value in self._support_metric_sums.items()
        }
        if self._support_actor_metric_count:
            means.update(
                {
                    name: value / self._support_actor_metric_count
                    for name, value in self._support_actor_metric_sums.items()
                }
            )
        self._support_metric_sums = {}
        self._support_metric_count = 0
        self._support_actor_metric_sums = {}
        self._support_actor_metric_count = 0
        return means

    def current_support_coefficient(self):
        if self.support_coefficient == 0.0:
            return 0.0
        completed = int(self._n_updates)
        if completed < self.support_warmup_updates:
            return 0.0
        if self.support_ramp_updates == 0:
            return self.support_coefficient
        progress = (
            completed - self.support_warmup_updates
        ) / self.support_ramp_updates
        return float(
            self.support_coefficient * min(max(progress, 0.0), 1.0)
        )

    @staticmethod
    @jax.jit
    def update_support(support_state, observations, actions):
        def loss(params):
            mean, log_std = support_state.apply_fn(
                {"params": params}, observations
            )
            nll = action_nll(mean, log_std, actions)
            return jnp.mean(nll), (
                jnp.mean(nll),
                jnp.mean(jnp.square(mean - actions)),
                jnp.mean(log_std),
            )

        (loss_value, (nll, mse, log_std)), grads = jax.value_and_grad(
            loss, has_aux=True
        )(support_state.params)
        support_state = support_state.apply_gradients(grads=grads)
        return support_state, {
            "support_loss": loss_value,
            "support_replay_nll": nll,
            "support_replay_mse": mse,
            "support_log_std": log_std,
        }

    @staticmethod
    @partial(
        jax.jit,
        static_argnames=["q_reduce_fn", "support_quantile", "td3_mode"],
    )
    def update_actor_supported(
        actor_state,
        qf_state,
        ent_coef_state,
        support_state,
        observations,
        replay_actions,
        key,
        support_coefficient,
        support_quantile,
        q_reduce_fn=jnp.min,
        td3_mode=False,
    ):
        key, dropout_key, noise_key, _ = jax.random.split(key, 4)
        support_mean, support_log_std = support_state.apply_fn(
            {"params": support_state.params}, observations
        )
        replay_nll = action_nll(
            support_mean, support_log_std, replay_actions
        )
        threshold = jnp.quantile(replay_nll, support_quantile)
        nll_scale = jnp.std(replay_nll) + 0.1

        def actor_loss(params, batch_stats):
            dist, state_updates = actor_state.apply_fn(
                {"params": params, "batch_stats": batch_stats},
                observations,
                mutable=["batch_stats"],
                train=True,
            )
            if td3_mode:
                actor_actions = dist.mode()
                ent_coef_value = 0.0
                log_prob = jnp.zeros((actor_actions.shape[0], 1))
            else:
                actor_actions = dist.sample(seed=noise_key)
                ent_coef_value = ent_coef_state.apply_fn(
                    {"params": ent_coef_state.params}
                )
                log_prob = dist.log_prob(actor_actions).reshape(-1, 1)

            qf_pi = qf_state.apply_fn(
                {
                    "params": qf_state.params,
                    "batch_stats": qf_state.batch_stats,
                },
                observations,
                actor_actions,
                rngs={"dropout": dropout_key},
                train=False,
            )
            min_qf_pi = q_reduce_fn(qf_pi, axis=0)
            policy_nll = action_nll(
                support_mean, support_log_std, actor_actions
            )
            standardized_excess = jax.nn.relu(
                (policy_nll - threshold) / nll_scale
            )
            unsupported = jax.lax.stop_gradient(
                1.0 - jnp.exp(-standardized_excess)
            )
            bc_error = jnp.mean(
                jnp.square(actor_actions - replay_actions), axis=-1
            )
            q_scale = jax.lax.stop_gradient(
                jnp.maximum(jnp.mean(jnp.abs(min_qf_pi)), 1.0)
            )
            support_penalty = (
                support_coefficient
                * q_scale
                * jnp.mean(unsupported * bc_error)
            )
            base_loss = jnp.mean(ent_coef_value * log_prob - min_qf_pi)
            total_loss = base_loss + support_penalty
            metrics = {
                "support_actor_replay_nll": jnp.mean(replay_nll),
                "support_actor_policy_nll": jnp.mean(policy_nll),
                "support_actor_threshold": threshold,
                "support_actor_unsupported_mean": jnp.mean(unsupported),
                "support_actor_active_fraction": jnp.mean(unsupported > 0.1),
                "support_actor_bc_error": jnp.mean(bc_error),
                "support_actor_q_scale": q_scale,
                "support_actor_penalty": support_penalty,
                "support_actor_base_loss": base_loss,
            }
            return total_loss, (-jnp.mean(log_prob), state_updates, metrics)

        (loss_value, (entropy, state_updates, metrics)), grads = (
            jax.value_and_grad(actor_loss, has_aux=True)(
                actor_state.params, actor_state.batch_stats
            )
        )
        actor_state = actor_state.apply_gradients(grads=grads)
        actor_state = actor_state.replace(
            batch_stats=state_updates["batch_stats"]
        )
        return actor_state, qf_state, loss_value, key, entropy, metrics

    @classmethod
    @partial(
        jax.jit,
        static_argnames=[
            "cls",
            "crossq_style",
            "td3_mode",
            "use_bnstats_from_live_net",
            "gradient_steps",
            "support_quantile",
            "q_reduce_fn",
        ],
    )
    def _train_guarded(
        cls,
        crossq_style,
        td3_mode,
        use_bnstats_from_live_net,
        gamma,
        tau,
        target_entropy,
        gradient_steps,
        data,
        policy_delay_indices,
        qf_state,
        actor_state,
        ent_coef_state,
        support_state,
        key,
        support_coefficient,
        support_quantile,
        q_reduce_fn,
    ):
        actor_loss_value = jnp.array(0.0)
        support_metrics = {
            "support_actor_update": jnp.array(0.0),
            "support_actor_replay_nll": jnp.array(0.0),
            "support_actor_policy_nll": jnp.array(0.0),
            "support_actor_threshold": jnp.array(0.0),
            "support_actor_unsupported_mean": jnp.array(0.0),
            "support_actor_active_fraction": jnp.array(0.0),
            "support_actor_bc_error": jnp.array(0.0),
            "support_actor_q_scale": jnp.array(0.0),
            "support_actor_penalty": jnp.array(0.0),
            "support_actor_base_loss": jnp.array(0.0),
        }
        for index in range(gradient_steps):
            def take(values, step=index):
                size = values.shape[0] // gradient_steps
                return values[size * step : size * (step + 1)]

            qf_state, critic_metrics, key = SAC.update_critic(
                crossq_style,
                td3_mode,
                use_bnstats_from_live_net,
                gamma,
                actor_state,
                qf_state,
                ent_coef_state,
                take(data.observations),
                take(data.actions),
                take(data.next_observations),
                take(data.rewards),
                take(data.dones),
                key,
            )
            qf_state = SAC.soft_update(tau, qf_state)
            if index in policy_delay_indices:
                (
                    actor_state,
                    qf_state,
                    actor_loss_value,
                    key,
                    entropy,
                    support_metrics,
                ) = cls.update_actor_supported(
                    actor_state,
                    qf_state,
                    ent_coef_state,
                    support_state,
                    take(data.observations),
                    take(data.actions),
                    key,
                    support_coefficient,
                    support_quantile,
                    q_reduce_fn,
                    td3_mode,
                )
                support_metrics = {
                    "support_actor_update": jnp.array(1.0),
                    **support_metrics,
                }
                ent_coef_state, _ = SAC.update_temperature(
                    target_entropy, ent_coef_state, entropy
                )
        return (
            qf_state,
            actor_state,
            ent_coef_state,
            key,
            {
                "actor_loss": actor_loss_value,
                **critic_metrics,
                **support_metrics,
            },
        )

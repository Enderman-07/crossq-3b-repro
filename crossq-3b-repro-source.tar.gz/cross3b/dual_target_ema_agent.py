"""Cross3B-DTEMA: dual policy targets with an EMA evaluation actor."""

from cross3b.actor_ema_agent import Cross3BActorEMA
from cross3b.dual_target_agent import Cross3BDualTarget


class Cross3BDualTargetEMA(Cross3BActorEMA, Cross3BDualTarget):
    """Compose dual-target training with evaluation-only actor averaging."""


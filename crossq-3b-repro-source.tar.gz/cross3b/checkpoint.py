"""Save and restore the actor without depending on SBX model serialization."""

import pathlib

import flax


def save_actor_checkpoint(model, output_dir: pathlib.Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    actor_state = (
        model.evaluation_actor_state()
        if hasattr(model, "evaluation_actor_state")
        else model.policy.actor_state
    )
    (output_dir / "actor_params.msgpack").write_bytes(
        flax.serialization.to_bytes(actor_state.params)
    )
    (output_dir / "actor_batch_stats.msgpack").write_bytes(
        flax.serialization.to_bytes(actor_state.batch_stats)
    )


def load_actor_checkpoint(model, checkpoint_dir: pathlib.Path) -> None:
    actor_state = model.policy.actor_state
    params = flax.serialization.from_bytes(
        actor_state.params,
        (checkpoint_dir / "actor_params.msgpack").read_bytes(),
    )
    batch_stats = flax.serialization.from_bytes(
        actor_state.batch_stats,
        (checkpoint_dir / "actor_batch_stats.msgpack").read_bytes(),
    )
    model.policy.actor_state = actor_state.replace(
        params=params,
        batch_stats=batch_stats,
    )

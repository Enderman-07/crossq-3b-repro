"""Original actor-step Cross3B with an evaluation-only actor EMA."""

from functools import partial

import flax
import jax
import jax.numpy as jnp
import numpy as np

from sbx.common.type_aliases import ReplayBufferSamplesNp
from sbx.sac.sac import SAC

from cross3b.actor_ema_agent import Cross3BActorEMA
from cross3b.agent import Cross3B


class Cross3BOriginalEMA(Cross3BActorEMA):
    """Use true 3N joint updates only on actor-update critic steps.

    Before ``policy_batch_start_steps`` every update is leaf-equivalent to
    CrossQ. Once active, non-actor steps remain official 2N CrossQ updates,
    while actor steps use one joint B/T/P forward from the same pre-update
    critic snapshot. EMA affects evaluation only.
    """

    def __init__(
        self,
        *args,
        policy_batch_start_steps: int = 0,
        **kwargs,
    ):
        if policy_batch_start_steps < 0:
            raise ValueError("policy_batch_start_steps must be nonnegative")
        self.policy_batch_start_steps = policy_batch_start_steps
        super().__init__(*args, **kwargs)

    def train(self, batch_size, gradient_steps):
        data = self.replay_buffer.sample(
            batch_size * gradient_steps,
            env=self._vec_normalize_env,
        )
        policy_delay_indices = flax.core.FrozenDict(
            {
                i: True
                for i in range(gradient_steps)
                if ((self._n_updates + i + 1) % self.policy_delay) == 0
            }
        )

        if isinstance(data.observations, dict):
            keys = list(self.observation_space.keys())
            observations = np.concatenate(
                [data.observations[key].numpy() for key in keys], axis=1
            )
            next_observations = np.concatenate(
                [data.next_observations[key].numpy() for key in keys], axis=1
            )
        else:
            observations = data.observations.numpy()
            next_observations = data.next_observations.numpy()
        data = ReplayBufferSamplesNp(
            observations,
            data.actions.numpy(),
            next_observations,
            data.dones.numpy().flatten(),
            data.rewards.numpy().flatten(),
        )

        policy_batch_active = (
            self._n_updates >= self.policy_batch_start_steps
        )
        (
            self.policy.qf_state,
            self.policy.actor_state,
            self.ent_coef_state,
            self.key,
            log_metrics,
        ) = self._train_original_3b(
            self.crossq_style,
            self.td3_mode,
            self.use_bnstats_from_live_net,
            self.gamma,
            self.tau,
            self.target_entropy,
            gradient_steps,
            data,
            policy_delay_indices,
            self.policy.qf_state,
            self.policy.actor_state,
            self.ent_coef_state,
            self.key,
            self.policy_q_reduce_fn,
            policy_batch_active,
        )
        self._n_updates += gradient_steps
        self.logger.record(
            "train/n_updates", self._n_updates, exclude="tensorboard"
        )
        self.last_train_metrics = {
            key: value.item() for key, value in log_metrics.items()
        }
        for key, value in self.last_train_metrics.items():
            self.logger.record(f"train/{key}", value)
        self._update_evaluation_actor(gradient_steps)

    @classmethod
    @partial(
        jax.jit,
        static_argnames=[
            "cls",
            "crossq_style",
            "td3_mode",
            "use_bnstats_from_live_net",
            "gradient_steps",
            "q_reduce_fn",
            "policy_batch_active",
        ],
    )
    def _train_original_3b(
        cls,
        crossq_style,
        td3_mode,
        use_bnstats_from_live_net,
        gamma,
        tau,
        target_entropy,
        gradient_steps,
        data,
        policy_delay_indices,
        qf_state,
        actor_state,
        ent_coef_state,
        key,
        q_reduce_fn,
        policy_batch_active,
    ):
        actor_loss_value = jnp.array(0.0)
        entropy = jnp.array(0.0)
        log_metrics_critic = {}
        policy_batch_updates = 0

        for index in range(gradient_steps):

            def slice_batch(value, step=index):
                batch_size = value.shape[0] // gradient_steps
                return value[batch_size * step : batch_size * (step + 1)]

            update_actor = index in policy_delay_indices
            if update_actor and policy_batch_active:
                (
                    qf_state,
                    actor_state,
                    entropy,
                    log_metrics_critic,
                    key,
                ) = Cross3B.update_critic_and_actor(
                    True,
                    td3_mode,
                    gamma,
                    actor_state,
                    qf_state,
                    ent_coef_state,
                    slice_batch(data.observations),
                    slice_batch(data.actions),
                    slice_batch(data.next_observations),
                    slice_batch(data.rewards),
                    slice_batch(data.dones),
                    key,
                    q_reduce_fn,
                    False,
                )
                actor_loss_value = log_metrics_critic["actor_loss"]
                policy_batch_updates += 1
            else:
                qf_state, log_metrics_critic, key = SAC.update_critic(
                    crossq_style,
                    td3_mode,
                    use_bnstats_from_live_net,
                    gamma,
                    actor_state,
                    qf_state,
                    ent_coef_state,
                    slice_batch(data.observations),
                    slice_batch(data.actions),
                    slice_batch(data.next_observations),
                    slice_batch(data.rewards),
                    slice_batch(data.dones),
                    key,
                )

            qf_state = SAC.soft_update(tau, qf_state)
            if update_actor:
                if not policy_batch_active:
                    (
                        actor_state,
                        qf_state,
                        actor_loss_value,
                        key,
                        entropy,
                    ) = SAC.update_actor(
                        actor_state,
                        qf_state,
                        ent_coef_state,
                        slice_batch(data.observations),
                        key,
                        q_reduce_fn,
                        td3_mode,
                    )
                ent_coef_state, _ = SAC.update_temperature(
                    target_entropy,
                    ent_coef_state,
                    entropy,
                )

        return (
            qf_state,
            actor_state,
            ent_coef_state,
            key,
            {
                "actor_loss": actor_loss_value,
                **log_metrics_critic,
                "policy_batch_active": jnp.asarray(
                    float(policy_batch_active)
                ),
                "policy_batch_updates": jnp.asarray(
                    float(policy_batch_updates)
                ),
            },
        )

"""Snapshot and restore the mutable state used by causal replay forks."""

from __future__ import annotations

import copy
from dataclasses import dataclass
import json
import pathlib
import pickle
import random
from typing import Any

import flax
import jax
import numpy as np
import torch


@dataclass(frozen=True)
class TrainingSnapshot:
    actor_state: Any
    qf_state: Any
    ent_coef_state: Any
    key: Any
    n_updates: int
    num_timesteps: int
    two_batch_delta_ema: Any
    last_train_metrics: dict[str, float]
    train_metric_sums: dict[str, float]
    train_metric_count: int
    policy_risk_metric_sums: dict[str, float]
    policy_risk_metric_count: int
    policy_batch_ratio: float
    two_batch_reference_diagnostics: bool
    two_batch_reference_control: bool
    numpy_rng_state: tuple
    python_rng_state: tuple
    torch_rng_state: torch.Tensor


def _copy_numpy_rng_state(state: tuple) -> tuple:
    return (state[0], state[1].copy(), state[2], state[3], state[4])


def capture_training_state(model) -> TrainingSnapshot:
    """Capture all state mutated by offline gradient updates."""
    return TrainingSnapshot(
        actor_state=model.policy.actor_state,
        qf_state=model.policy.qf_state,
        ent_coef_state=model.ent_coef_state,
        key=model.key,
        n_updates=int(model._n_updates),
        num_timesteps=int(model.num_timesteps),
        two_batch_delta_ema=model._two_batch_delta_ema,
        last_train_metrics=copy.deepcopy(
            getattr(model, "last_train_metrics", {})
        ),
        train_metric_sums=copy.deepcopy(model._train_metric_sums),
        train_metric_count=int(model._train_metric_count),
        policy_risk_metric_sums=copy.deepcopy(
            model._policy_risk_metric_sums
        ),
        policy_risk_metric_count=int(model._policy_risk_metric_count),
        policy_batch_ratio=float(model.policy_batch_ratio),
        two_batch_reference_diagnostics=bool(
            model.two_batch_reference_diagnostics
        ),
        two_batch_reference_control=bool(
            model.two_batch_reference_control
        ),
        numpy_rng_state=_copy_numpy_rng_state(np.random.get_state()),
        python_rng_state=random.getstate(),
        torch_rng_state=torch.get_rng_state().clone(),
    )


def restore_training_state(model, snapshot: TrainingSnapshot) -> None:
    """Restore a snapshot before another branch consumes replay samples."""
    model.policy.actor_state = snapshot.actor_state
    model.policy.qf_state = snapshot.qf_state
    model.ent_coef_state = snapshot.ent_coef_state
    model.key = snapshot.key
    model._n_updates = snapshot.n_updates
    model.num_timesteps = snapshot.num_timesteps
    model._two_batch_delta_ema = snapshot.two_batch_delta_ema
    model.last_train_metrics = copy.deepcopy(snapshot.last_train_metrics)
    model._train_metric_sums = copy.deepcopy(snapshot.train_metric_sums)
    model._train_metric_count = snapshot.train_metric_count
    model._policy_risk_metric_sums = copy.deepcopy(
        snapshot.policy_risk_metric_sums
    )
    model._policy_risk_metric_count = snapshot.policy_risk_metric_count
    model.policy_batch_ratio = snapshot.policy_batch_ratio
    model.two_batch_reference_diagnostics = (
        snapshot.two_batch_reference_diagnostics
    )
    model.two_batch_reference_control = snapshot.two_batch_reference_control
    np.random.set_state(_copy_numpy_rng_state(snapshot.numpy_rng_state))
    random.setstate(snapshot.python_rng_state)
    torch.set_rng_state(snapshot.torch_rng_state.clone())


def compare_training_states(left: TrainingSnapshot, right: TrainingSnapshot):
    """Return an exact reproducibility report for learned and RNG state."""
    named_trees = {
        "actor_state": (left.actor_state, right.actor_state),
        "qf_state": (left.qf_state, right.qf_state),
        "ent_coef_state": (left.ent_coef_state, right.ent_coef_state),
        "key": (left.key, right.key),
        "two_batch_delta_ema": (
            left.two_batch_delta_ema,
            right.two_batch_delta_ema,
        ),
    }
    mismatches = []
    max_abs_difference = 0.0
    compared_leaves = 0
    for tree_name, (left_tree, right_tree) in named_trees.items():
        left_leaves = jax.tree_util.tree_leaves(left_tree)
        right_leaves = jax.tree_util.tree_leaves(right_tree)
        if len(left_leaves) != len(right_leaves):
            mismatches.append(f"{tree_name}:leaf_count")
            continue
        for index, (left_leaf, right_leaf) in enumerate(
            zip(left_leaves, right_leaves)
        ):
            left_array = np.asarray(jax.device_get(left_leaf))
            right_array = np.asarray(jax.device_get(right_leaf))
            compared_leaves += 1
            if left_array.shape != right_array.shape or left_array.dtype != right_array.dtype:
                mismatches.append(f"{tree_name}:{index}:metadata")
                continue
            if not np.array_equal(left_array, right_array, equal_nan=True):
                mismatches.append(f"{tree_name}:{index}:value")
                if np.issubdtype(left_array.dtype, np.number):
                    difference = np.abs(left_array - right_array)
                    finite = difference[np.isfinite(difference)]
                    if finite.size:
                        max_abs_difference = max(
                            max_abs_difference,
                            float(np.max(finite)),
                        )

    scalar_fields = (
        "n_updates",
        "num_timesteps",
        "train_metric_count",
        "policy_risk_metric_count",
        "policy_batch_ratio",
        "two_batch_reference_diagnostics",
        "two_batch_reference_control",
    )
    for field in scalar_fields:
        if getattr(left, field) != getattr(right, field):
            mismatches.append(field)
    if left.last_train_metrics != right.last_train_metrics:
        mismatches.append("last_train_metrics")
    if left.train_metric_sums != right.train_metric_sums:
        mismatches.append("train_metric_sums")
    if left.policy_risk_metric_sums != right.policy_risk_metric_sums:
        mismatches.append("policy_risk_metric_sums")
    left_numpy = _copy_numpy_rng_state(left.numpy_rng_state)
    right_numpy = _copy_numpy_rng_state(right.numpy_rng_state)
    if not (
        left_numpy[0] == right_numpy[0]
        and np.array_equal(left_numpy[1], right_numpy[1])
        and left_numpy[2:] == right_numpy[2:]
    ):
        mismatches.append("numpy_rng_state")
    if left.python_rng_state != right.python_rng_state:
        mismatches.append("python_rng_state")
    if not torch.equal(left.torch_rng_state, right.torch_rng_state):
        mismatches.append("torch_rng_state")

    return {
        "exact": not mismatches,
        "compared_leaves": compared_leaves,
        "max_abs_difference": max_abs_difference,
        "mismatches": mismatches,
    }


def persist_training_state(
    model,
    snapshot: TrainingSnapshot,
    output_dir: pathlib.Path,
) -> None:
    """Persist source state for audit/recovery, including the frozen replay."""
    output_dir.mkdir(parents=True, exist_ok=False)
    (output_dir / "actor_state.msgpack").write_bytes(
        flax.serialization.to_bytes(snapshot.actor_state)
    )
    (output_dir / "qf_state.msgpack").write_bytes(
        flax.serialization.to_bytes(snapshot.qf_state)
    )
    (output_dir / "ent_coef_state.msgpack").write_bytes(
        flax.serialization.to_bytes(snapshot.ent_coef_state)
    )
    np.save(output_dir / "jax_key.npy", np.asarray(jax.device_get(snapshot.key)))
    with (output_dir / "rng_state.pkl").open("wb") as handle:
        pickle.dump(
            {
                "numpy": snapshot.numpy_rng_state,
                "python": snapshot.python_rng_state,
                "torch": snapshot.torch_rng_state,
            },
            handle,
            protocol=pickle.HIGHEST_PROTOCOL,
        )
    metadata = {
        "n_updates": snapshot.n_updates,
        "num_timesteps": snapshot.num_timesteps,
        "two_batch_delta_ema": float(snapshot.two_batch_delta_ema),
        "policy_batch_ratio": snapshot.policy_batch_ratio,
        "two_batch_reference_diagnostics": (
            snapshot.two_batch_reference_diagnostics
        ),
        "two_batch_reference_control": (
            snapshot.two_batch_reference_control
        ),
        "last_train_metrics": snapshot.last_train_metrics,
        "train_metric_sums": snapshot.train_metric_sums,
        "train_metric_count": snapshot.train_metric_count,
        "policy_risk_metric_sums": snapshot.policy_risk_metric_sums,
        "policy_risk_metric_count": snapshot.policy_risk_metric_count,
    }
    (output_dir / "metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    model.save_replay_buffer(output_dir / "replay_buffer.pkl")


def load_training_state(
    model,
    input_dir: pathlib.Path,
    *,
    load_replay_buffer: bool = True,
) -> TrainingSnapshot:
    """Load a persisted source snapshot into a compatible initialized model.

    Snapshots written before risk-probe metrics were added remain usable; their
    diagnostic accumulators default to empty because they do not affect updates.
    """
    input_dir = pathlib.Path(input_dir)
    metadata = json.loads(
        (input_dir / "metadata.json").read_text(encoding="utf-8")
    )
    with (input_dir / "rng_state.pkl").open("rb") as handle:
        rng_state = pickle.load(handle)

    snapshot = TrainingSnapshot(
        actor_state=flax.serialization.from_bytes(
            model.policy.actor_state,
            (input_dir / "actor_state.msgpack").read_bytes(),
        ),
        qf_state=flax.serialization.from_bytes(
            model.policy.qf_state,
            (input_dir / "qf_state.msgpack").read_bytes(),
        ),
        ent_coef_state=flax.serialization.from_bytes(
            model.ent_coef_state,
            (input_dir / "ent_coef_state.msgpack").read_bytes(),
        ),
        key=jax.device_put(np.load(input_dir / "jax_key.npy")),
        n_updates=int(metadata["n_updates"]),
        num_timesteps=int(metadata["num_timesteps"]),
        two_batch_delta_ema=jax.numpy.asarray(
            metadata["two_batch_delta_ema"]
        ),
        last_train_metrics=copy.deepcopy(
            metadata.get("last_train_metrics", {})
        ),
        train_metric_sums=copy.deepcopy(
            metadata.get("train_metric_sums", {})
        ),
        train_metric_count=int(metadata.get("train_metric_count", 0)),
        policy_risk_metric_sums=copy.deepcopy(
            metadata.get("policy_risk_metric_sums", {})
        ),
        policy_risk_metric_count=int(
            metadata.get("policy_risk_metric_count", 0)
        ),
        policy_batch_ratio=float(metadata["policy_batch_ratio"]),
        two_batch_reference_diagnostics=bool(
            metadata["two_batch_reference_diagnostics"]
        ),
        two_batch_reference_control=bool(
            metadata["two_batch_reference_control"]
        ),
        numpy_rng_state=_copy_numpy_rng_state(rng_state["numpy"]),
        python_rng_state=rng_state["python"],
        torch_rng_state=rng_state["torch"].clone(),
    )
    if load_replay_buffer:
        model.load_replay_buffer(
            input_dir / "replay_buffer.pkl",
            truncate_last_traj=False,
        )
    restore_training_state(model, snapshot)
    return snapshot

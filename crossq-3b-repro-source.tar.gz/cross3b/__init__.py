"""Cross3B experiment package."""

from cross3b.agent import Cross3B
from cross3b.actor_ema_agent import Cross3BActorEMA
from cross3b.antithetic_target_agent import Cross3BAntitheticTarget
from cross3b.dual_target_agent import Cross3BDualTarget
from cross3b.dual_target_ema_agent import Cross3BDualTargetEMA
from cross3b.original_ema_agent import Cross3BOriginalEMA
from cross3b.support_agent import Cross3BSupport

__all__ = [
    "Cross3B",
    "Cross3BActorEMA",
    "Cross3BAntitheticTarget",
    "Cross3BDualTarget",
    "Cross3BDualTargetEMA",
    "Cross3BOriginalEMA",
    "Cross3BSupport",
]

"""Cross3B-AT: a zero-stat antithetic Bellman-target batch."""

from functools import partial
from typing import ClassVar, Dict, Type

import jax
import jax.numpy as jnp
import numpy as np
from flax.training.train_state import TrainState

from cross3b.dual_target_agent import Cross3BDualTarget
from cross3b.weighted_policy import WeightedSACPolicy
from sbx.common.type_aliases import ActorTrainState, RLTrainState


class Cross3BAntitheticTarget(Cross3BDualTarget):
    """Average antithetic targets without changing CrossQ's 2N BRN moments."""

    def __init__(self, *args, target_action_samples: int = 2, **kwargs):
        if target_action_samples not in {1, 2}:
            raise ValueError(
                "Cross3B-AT supports one target for its CrossQ leaf or "
                "two antithetic targets"
            )
        policy_kwargs = dict(kwargs.get("policy_kwargs") or {})
        policy_kwargs["crossq_parameter_names"] = True
        kwargs["policy_kwargs"] = policy_kwargs
        super().__init__(
            *args,
            target_action_samples=target_action_samples,
            **kwargs,
        )

    @staticmethod
    def sample_antithetic_actions(distribution, noise_key, sample_count):
        """Return one policy draw and its pre-tanh reflection about the mean."""
        latent_action = distribution.distribution.sample(seed=noise_key)
        actions = [distribution.bijector.forward(latent_action)]
        if sample_count == 2:
            latent_mean = distribution.distribution.mean()
            reflected_latent = 2.0 * latent_mean - latent_action
            actions.append(distribution.bijector.forward(reflected_latent))
        log_probs = jnp.stack(
            [distribution.log_prob(action) for action in actions]
        )
        return actions, log_probs

    @staticmethod
    @partial(
        jax.jit,
        static_argnames=[
            "crossq_style",
            "td3_mode",
            "use_bnstats_from_live_net",
            "target_action_samples",
        ],
    )
    def update_critic_dual_target(
        crossq_style: bool,
        td3_mode: bool,
        use_bnstats_from_live_net: bool,
        gamma: float,
        actor_state: ActorTrainState,
        qf_state: RLTrainState,
        ent_coef_state: TrainState,
        observations: np.ndarray,
        actions: np.ndarray,
        next_observations: np.ndarray,
        rewards: np.ndarray,
        dones: np.ndarray,
        key: jax.random.KeyArray,
        target_action_samples: int,
    ):
        key, noise_key, dropout_key_target, dropout_key_current, redq_key = (
            jax.random.split(key, 5)
        )
        distribution = actor_state.apply_fn(
            {
                "params": actor_state.params,
                "batch_stats": actor_state.batch_stats,
            },
            next_observations,
            train=False,
        )

        if td3_mode:
            ent_coef_value = 0.0
            mode = distribution.mode()
            noise = jnp.clip(
                jax.random.normal(noise_key, mode.shape) * 0.2,
                -0.5,
                0.5,
            )
            target_actions = [jnp.clip(mode + noise, -1.0, 1.0)]
            if target_action_samples == 2:
                target_actions.append(jnp.clip(mode - noise, -1.0, 1.0))
            target_log_probs = jnp.zeros(
                (target_action_samples, observations.shape[0])
            )
        else:
            ent_coef_value = ent_coef_state.apply_fn(
                {"params": ent_coef_state.params}
            )
            target_actions, target_log_probs = (
                Cross3BAntitheticTarget.sample_antithetic_actions(
                    distribution,
                    noise_key,
                    target_action_samples,
                )
            )
        target_actions = [
            jax.lax.stop_gradient(action) for action in target_actions
        ]

        def critic_loss(params, batch_stats, dropout_key):
            if not crossq_style:
                target_values = []
                for target_action in target_actions:
                    value = qf_state.apply_fn(
                        {
                            "params": qf_state.target_params,
                            "batch_stats": (
                                batch_stats
                                if use_bnstats_from_live_net
                                else qf_state.target_batch_stats
                            ),
                        },
                        next_observations,
                        target_action,
                        None,
                        None,
                        None,
                        rngs={"dropout": dropout_key_target},
                        train=False,
                    )
                    target_values.append(value)
                current_q_values, state_updates = qf_state.apply_fn(
                    {"params": params, "batch_stats": batch_stats},
                    observations,
                    actions,
                    None,
                    None,
                    None,
                    rngs={"dropout": dropout_key},
                    mutable=["batch_stats"],
                    train=True,
                )
                target_q_values = jnp.stack(target_values, axis=1)
            else:
                batch_size = observations.shape[0]
                catted_observations = jnp.concatenate(
                    [observations]
                    + [next_observations] * target_action_samples,
                    axis=0,
                )
                catted_actions = jnp.concatenate(
                    [actions] + target_actions,
                    axis=0,
                )
                sample_weights = jnp.concatenate(
                    [
                        jnp.ones(2 * batch_size, dtype=jnp.float32),
                        jnp.zeros(
                            (target_action_samples - 1) * batch_size,
                            dtype=jnp.float32,
                        ),
                    ]
                )
                catted_q_values, state_updates = qf_state.apply_fn(
                    {"params": params, "batch_stats": batch_stats},
                    catted_observations,
                    catted_actions,
                    sample_weights,
                    None,
                    None,
                    rngs={"dropout": dropout_key},
                    mutable=["batch_stats"],
                    train=True,
                )
                current_q_values = catted_q_values[:, :batch_size]
                target_q_values = catted_q_values[:, batch_size:].reshape(
                    catted_q_values.shape[0],
                    target_action_samples,
                    batch_size,
                    1,
                )

            if target_q_values.shape[0] > 2:
                target_q_values = jax.random.choice(
                    redq_key,
                    target_q_values,
                    (2,),
                    replace=False,
                    axis=0,
                )
            target_q_values = jnp.min(target_q_values, axis=0)
            soft_target_values = target_q_values - (
                ent_coef_value * target_log_probs[..., None]
            )
            next_q_values = jnp.mean(soft_target_values, axis=0)
            bellman_target = rewards.reshape(-1, 1) + (
                1 - dones.reshape(-1, 1)
            ) * gamma * next_q_values
            loss = (
                0.5
                * (
                    (
                        jax.lax.stop_gradient(bellman_target)
                        - current_q_values
                    )
                    ** 2
                ).mean(axis=1).sum()
            )
            if target_action_samples == 2:
                first = soft_target_values[0, :, 0]
                second = soft_target_values[1, :, 0]
                centered_first = first - jnp.mean(first)
                centered_second = second - jnp.mean(second)
                covariance = jnp.mean(centered_first * centered_second)
                correlation = covariance / jnp.sqrt(
                    jnp.mean(jnp.square(centered_first))
                    * jnp.mean(jnp.square(centered_second))
                    + jnp.finfo(jnp.float32).eps
                )
                pair_delta = jnp.mean(jnp.abs(first - second))
            else:
                correlation = jnp.array(0.0)
                pair_delta = jnp.array(0.0)
            return loss, (
                state_updates,
                current_q_values,
                next_q_values,
                jnp.mean(jnp.std(soft_target_values, axis=0)),
                correlation,
                pair_delta,
            )

        (
            qf_loss_value,
            (
                state_updates,
                current_q_values,
                next_q_values,
                target_sample_std,
                target_pair_correlation,
                target_pair_abs_delta,
            ),
        ), grads = jax.value_and_grad(critic_loss, has_aux=True)(
            qf_state.params,
            qf_state.batch_stats,
            dropout_key_current,
        )
        qf_state = qf_state.apply_gradients(grads=grads)
        qf_state = qf_state.replace(
            batch_stats=state_updates["batch_stats"]
        )
        metrics = {
            "critic_loss": qf_loss_value,
            "ent_coef": ent_coef_value,
            "current_q_values": current_q_values.mean(),
            "next_q_values": next_q_values.mean(),
            "target_sample_std": target_sample_std,
            "target_pair_correlation": target_pair_correlation,
            "target_pair_abs_delta": target_pair_abs_delta,
        }
        return qf_state, metrics, key

    policy_aliases: ClassVar[Dict[str, Type]] = {
        "MlpPolicy": WeightedSACPolicy,
        "MultiInputPolicy": WeightedSACPolicy,
    }

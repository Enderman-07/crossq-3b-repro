"""Cross3B: share critic normalization across all three training uses."""

from collections.abc import Mapping
from functools import partial
import math
from typing import ClassVar, Dict, Type

import flax
import jax
import jax.numpy as jnp
import numpy as np
from flax.training.train_state import TrainState

from sbx.common.type_aliases import (
    ActorTrainState,
    ReplayBufferSamplesNp,
    RLTrainState,
)
from sbx.sac.sac import SAC
from cross3b.weighted_policy import WeightedSACPolicy


def _batch_stat_values(tree, name, default=0.0):
    values = []

    def collect(node):
        if isinstance(node, Mapping):
            for key, value in node.items():
                if key == name:
                    values.append(jnp.mean(value))
                else:
                    collect(value)

    collect(tree)
    return jnp.stack(values) if values else jnp.full((1,), default)


def _tree_dot(left, right):
    return sum(
        jnp.vdot(left_leaf, right_leaf)
        for left_leaf, right_leaf in zip(
            jax.tree_util.tree_leaves(left),
            jax.tree_util.tree_leaves(right),
        )
    )


def _tree_difference(left, right):
    return jax.tree_util.tree_map(lambda a, b: a - b, left, right)


def _joint_actor_loss_from_outputs(
    q_values,
    action_log_prob,
    ent_coef_value,
    q_reduce_fn=jnp.min,
):
    """Compute actor loss from the policy third of a joint 3N forward."""
    _, _, policy_q_values = jnp.split(q_values, 3, axis=1)
    min_qf_pi = q_reduce_fn(policy_q_values, axis=0)
    return (ent_coef_value * action_log_prob - min_qf_pi).mean()


def _tree_comparison_metrics(reference, candidate, prefix):
    """Compare a candidate vector with a reference vector and its delta."""
    epsilon = jnp.finfo(jnp.float32).eps
    delta = _tree_difference(candidate, reference)
    reference_norm = jnp.sqrt(_tree_dot(reference, reference))
    candidate_norm = jnp.sqrt(_tree_dot(candidate, candidate))
    delta_norm_sq = _tree_dot(delta, delta)
    delta_norm = jnp.sqrt(delta_norm_sq)
    dot = _tree_dot(reference, candidate)
    delta_dot = _tree_dot(reference, delta)

    reference_leaves = jax.tree_util.tree_leaves(reference)
    delta_leaves = jax.tree_util.tree_leaves(delta)
    conflict_flags = []
    conflict_energy = jnp.array(0.0)
    for reference_leaf, delta_leaf in zip(reference_leaves, delta_leaves):
        conflict = jnp.vdot(reference_leaf, delta_leaf) < 0.0
        conflict_flags.append(conflict.astype(jnp.float32))
        conflict_energy += jnp.where(
            conflict,
            jnp.vdot(delta_leaf, delta_leaf),
            0.0,
        )

    return {
        f"{prefix}_cosine": dot
        / (reference_norm * candidate_norm + epsilon),
        f"{prefix}_delta_norm_ratio": delta_norm
        / (reference_norm + epsilon),
        f"{prefix}_delta_conflict": (delta_dot < 0.0).astype(jnp.float32),
        f"{prefix}_delta_conflict_leaf_fraction": jnp.mean(
            jnp.stack(conflict_flags)
        ),
        f"{prefix}_delta_conflict_energy_fraction": conflict_energy
        / (delta_norm_sq + epsilon),
    }


def _named_tree_leaves(tree, name):
    leaves = []

    def collect(node):
        if isinstance(node, Mapping):
            for key, value in node.items():
                if key == name:
                    leaves.append(value)
                else:
                    collect(value)

    collect(tree)
    return leaves


def _batch_stat_candidate_metrics(initial, reference, candidate):
    """Measure 3N batch-stat candidates relative to the true 2N update."""
    epsilon = jnp.finfo(jnp.float32).eps
    metrics = {}
    for name in ("mean", "var"):
        initial_leaves = _named_tree_leaves(initial, name)
        reference_leaves = _named_tree_leaves(reference, name)
        candidate_leaves = _named_tree_leaves(candidate, name)
        reference_update = [
            updated - previous
            for updated, previous in zip(reference_leaves, initial_leaves)
        ]
        candidate_difference = [
            three_batch - two_batch
            for three_batch, two_batch in zip(
                candidate_leaves,
                reference_leaves,
            )
        ]
        reference_norm_sq = sum(
            jnp.vdot(leaf, leaf) for leaf in reference_update
        )
        difference_norm_sq = sum(
            jnp.vdot(leaf, leaf) for leaf in candidate_difference
        )
        element_count = sum(leaf.size for leaf in candidate_difference)
        metrics[f"two_batch_ref_batch_{name}_rms_diff"] = jnp.sqrt(
            difference_norm_sq / element_count
        )
        metrics[
            f"two_batch_ref_batch_{name}_delta_norm_ratio"
        ] = jnp.sqrt(difference_norm_sq) / (
            jnp.sqrt(reference_norm_sq) + epsilon
        )
    return metrics


def _conflict_aware_merge(
    primary_grads,
    auxiliary_grads,
    max_norm_ratio,
    projection_strength=1.0,
):
    """Remove conflicting projection, then add a norm-bounded auxiliary."""
    epsilon = jnp.finfo(jnp.float32).eps
    primary_norm_sq = _tree_dot(primary_grads, primary_grads)
    primary_norm = jnp.sqrt(primary_norm_sq)
    auxiliary_norm = jnp.sqrt(_tree_dot(auxiliary_grads, auxiliary_grads))
    dot = _tree_dot(primary_grads, auxiliary_grads)
    cosine = dot / (primary_norm * auxiliary_norm + epsilon)
    conflicting_projection = (
        projection_strength
        * jnp.minimum(dot, 0.0)
        / (primary_norm_sq + epsilon)
    )
    projected_auxiliary = jax.tree_util.tree_map(
        lambda auxiliary, primary: (
            auxiliary - conflicting_projection * primary
        ),
        auxiliary_grads,
        primary_grads,
    )
    projected_norm = jnp.sqrt(
        _tree_dot(projected_auxiliary, projected_auxiliary)
    )
    norm_scale = jnp.minimum(
        1.0,
        max_norm_ratio * primary_norm / (projected_norm + epsilon),
    )
    applied_scale = jnp.where(projected_norm > epsilon, norm_scale, 0.0)
    merged = jax.tree_util.tree_map(
        lambda primary, auxiliary: primary + applied_scale * auxiliary,
        primary_grads,
        projected_auxiliary,
    )
    diagnostics = {
        "policy_moment_grad_cosine": cosine,
        "policy_moment_grad_scale": applied_scale,
        "policy_moment_grad_norm_ratio": auxiliary_norm
        / (primary_norm + epsilon),
        "policy_moment_grad_retained_ratio": projected_norm
        / (auxiliary_norm + epsilon),
        "policy_moment_grad_conflict": (dot < 0.0).astype(jnp.float32),
        "policy_moment_conflict_leaf_fraction": (
            (dot < 0.0).astype(jnp.float32)
        ),
        "policy_moment_conflict_energy_fraction": (
            (dot < 0.0).astype(jnp.float32)
        ),
        "policy_moment_projection_layerwise": jnp.array(0.0),
    }
    return merged, diagnostics


def _layerwise_conflict_aware_merge(
    primary_grads,
    auxiliary_grads,
    max_norm_ratio,
    projection_strength=1.0,
):
    """Project conflicting auxiliary components independently per leaf."""
    epsilon = jnp.finfo(jnp.float32).eps
    primary_leaves, tree_def = jax.tree_util.tree_flatten(primary_grads)
    auxiliary_leaves = jax.tree_util.tree_leaves(auxiliary_grads)
    projected_leaves = []
    conflict_flags = []
    conflict_energy = jnp.array(0.0)
    auxiliary_norm_sq = jnp.array(0.0)

    for primary, auxiliary in zip(primary_leaves, auxiliary_leaves):
        primary_norm_sq = jnp.vdot(primary, primary)
        auxiliary_leaf_norm_sq = jnp.vdot(auxiliary, auxiliary)
        dot = jnp.vdot(primary, auxiliary)
        conflict = dot < 0.0
        coefficient = (
            projection_strength
            * jnp.minimum(dot, 0.0)
            / (primary_norm_sq + epsilon)
        )
        projected_leaves.append(auxiliary - coefficient * primary)
        conflict_flags.append(conflict.astype(jnp.float32))
        auxiliary_norm_sq += auxiliary_leaf_norm_sq
        conflict_energy += jnp.where(
            conflict,
            auxiliary_leaf_norm_sq,
            0.0,
        )

    projected_auxiliary = jax.tree_util.tree_unflatten(
        tree_def,
        projected_leaves,
    )
    primary_norm = jnp.sqrt(_tree_dot(primary_grads, primary_grads))
    auxiliary_norm = jnp.sqrt(auxiliary_norm_sq)
    projected_norm = jnp.sqrt(
        _tree_dot(projected_auxiliary, projected_auxiliary)
    )
    dot = _tree_dot(primary_grads, auxiliary_grads)
    cosine = dot / (primary_norm * auxiliary_norm + epsilon)
    norm_scale = jnp.minimum(
        1.0,
        max_norm_ratio * primary_norm / (projected_norm + epsilon),
    )
    applied_scale = jnp.where(projected_norm > epsilon, norm_scale, 0.0)
    merged = jax.tree_util.tree_map(
        lambda primary, auxiliary: primary + applied_scale * auxiliary,
        primary_grads,
        projected_auxiliary,
    )
    diagnostics = {
        "policy_moment_grad_cosine": cosine,
        "policy_moment_grad_scale": applied_scale,
        "policy_moment_grad_norm_ratio": auxiliary_norm
        / (primary_norm + epsilon),
        "policy_moment_grad_retained_ratio": projected_norm
        / (auxiliary_norm + epsilon),
        "policy_moment_grad_conflict": (dot < 0.0).astype(jnp.float32),
        "policy_moment_conflict_leaf_fraction": jnp.mean(
            jnp.stack(conflict_flags)
        ),
        "policy_moment_conflict_energy_fraction": conflict_energy
        / (auxiliary_norm_sq + epsilon),
        "policy_moment_projection_layerwise": jnp.array(1.0),
    }
    return merged, diagnostics


def _adaptive_conflict_aware_merge(
    primary_grads,
    auxiliary_grads,
    max_norm_ratio,
    projection_strength=1.0,
    conflict_energy_threshold=0.95,
):
    """Select global or layerwise projection from current conflict energy."""
    global_grads, global_metrics = _conflict_aware_merge(
        primary_grads,
        auxiliary_grads,
        max_norm_ratio,
        projection_strength,
    )
    layerwise_grads, layerwise_metrics = _layerwise_conflict_aware_merge(
        primary_grads,
        auxiliary_grads,
        max_norm_ratio,
        projection_strength,
    )
    use_layerwise = (
        layerwise_metrics["policy_moment_conflict_energy_fraction"]
        >= conflict_energy_threshold
    ).astype(jnp.float32)
    merged = jax.tree_util.tree_map(
        lambda global_grad, layerwise_grad: (
            global_grad
            + use_layerwise * (layerwise_grad - global_grad)
        ),
        global_grads,
        layerwise_grads,
    )
    diagnostics = {
        **layerwise_metrics,
        "policy_moment_grad_scale": (
            global_metrics["policy_moment_grad_scale"]
            + use_layerwise
            * (
                layerwise_metrics["policy_moment_grad_scale"]
                - global_metrics["policy_moment_grad_scale"]
            )
        ),
        "policy_moment_grad_retained_ratio": (
            global_metrics["policy_moment_grad_retained_ratio"]
            + use_layerwise
            * (
                layerwise_metrics["policy_moment_grad_retained_ratio"]
                - global_metrics["policy_moment_grad_retained_ratio"]
            )
        ),
        "policy_moment_projection_layerwise": use_layerwise,
    }
    return merged, diagnostics


class Cross3B(SAC):
    """CrossQ variants that use or probe a policy-action batch.

    The original variants mix the policy batch into critic normalization.
    ``policy_risk_probe`` instead keeps a true-2N critic update and uses the
    policy batch only to guard actor updates. All variants retain CrossQ's
    policy-delay cadence.
    """

    def __init__(
        self,
        *args,
        cross3b_variant: str = "post_update_eval",
        policy_batch_ratio: float = 1.0,
        policy_batch_warmup_updates: int = 0,
        policy_batch_ramp_updates: int = 0,
        policy_batch_mode: str = "always",
        action_shift_allocation: bool = False,
        action_shift_low: float = 0.35,
        action_shift_high: float = 0.45,
        action_shift_warmup_updates: int = 0,
        action_shift_transition_updates: int = 0,
        detach_policy_moments: bool = False,
        conflict_aware_policy_moments: bool = False,
        policy_moment_conflict_until_updates: int = 0,
        policy_moment_max_grad_ratio: float = 1.0,
        policy_moment_projection_strength: float = 1.0,
        policy_moment_projection_scope: str = "global",
        policy_moment_conflict_energy_threshold: float = 0.95,
        bootstrap_batch_weight: float = 1.0,
        policy_stat_gate: bool = False,
        policy_stat_mean_budget: float = 0.1,
        policy_stat_log_var_budget: float = 0.1,
        policy_stat_gate_recovery: float = 0.01,
        two_batch_reference_diagnostics: bool = False,
        two_batch_reference_control: bool = False,
        two_batch_delta_max_norm_ratio: float = 0.22,
        two_batch_control_ema_decay: float = 0.0,
        two_batch_control_guard_low_delta: bool = False,
        policy_risk_threshold: float = 1.5,
        policy_risk_min_scale: float = 0.0,
        policy_risk_gate_mode: str = "full_loss",
        **kwargs,
    ):
        self.cross3b_variant = cross3b_variant
        self.policy_batch_ratio = policy_batch_ratio
        self.policy_batch_warmup_updates = policy_batch_warmup_updates
        self.policy_batch_ramp_updates = policy_batch_ramp_updates
        self.policy_batch_mode = policy_batch_mode
        self.action_shift_allocation = action_shift_allocation
        self.action_shift_low = action_shift_low
        self.action_shift_high = action_shift_high
        self.action_shift_warmup_updates = action_shift_warmup_updates
        self.action_shift_transition_updates = (
            action_shift_transition_updates
        )
        self.detach_policy_moments = detach_policy_moments
        self.conflict_aware_policy_moments = conflict_aware_policy_moments
        self.policy_moment_conflict_until_updates = (
            policy_moment_conflict_until_updates
        )
        self.policy_moment_max_grad_ratio = policy_moment_max_grad_ratio
        self.policy_moment_projection_strength = (
            policy_moment_projection_strength
        )
        self.policy_moment_projection_scope = policy_moment_projection_scope
        self.policy_moment_conflict_energy_threshold = (
            policy_moment_conflict_energy_threshold
        )
        self.bootstrap_batch_weight = bootstrap_batch_weight
        self.policy_stat_gate = policy_stat_gate
        self.policy_stat_mean_budget = policy_stat_mean_budget
        self.policy_stat_log_var_budget = policy_stat_log_var_budget
        self.policy_stat_gate_recovery = policy_stat_gate_recovery
        self.two_batch_reference_diagnostics = (
            two_batch_reference_diagnostics or two_batch_reference_control
        )
        self.two_batch_reference_control = two_batch_reference_control
        self.two_batch_delta_max_norm_ratio = two_batch_delta_max_norm_ratio
        self.two_batch_control_ema_decay = two_batch_control_ema_decay
        self.two_batch_control_guard_low_delta = (
            two_batch_control_guard_low_delta
        )
        self.policy_risk_threshold = policy_risk_threshold
        self.policy_risk_min_scale = policy_risk_min_scale
        self.policy_risk_gate_mode = policy_risk_gate_mode
        self._two_batch_delta_ema = jnp.array(0.0, dtype=jnp.float32)
        self._train_metric_sums = {}
        self._train_metric_count = 0
        self._policy_risk_metric_sums = {}
        self._policy_risk_metric_count = 0
        policy_kwargs = dict(kwargs.get("policy_kwargs") or {})
        policy_kwargs.update(
            policy_stat_gate=policy_stat_gate,
            policy_stat_mean_budget=policy_stat_mean_budget,
            policy_stat_log_var_budget=policy_stat_log_var_budget,
            policy_stat_gate_recovery=policy_stat_gate_recovery,
        )
        kwargs["policy_kwargs"] = policy_kwargs
        super().__init__(*args, **kwargs)
        if not 0.0 <= policy_batch_ratio <= 1.0:
            raise ValueError("policy_batch_ratio must be in [0, 1]")
        if policy_batch_warmup_updates < 0 or policy_batch_ramp_updates < 0:
            raise ValueError("policy batch schedule updates must be nonnegative")
        if not math.isfinite(bootstrap_batch_weight) or bootstrap_batch_weight <= 0:
            raise ValueError("bootstrap_batch_weight must be finite and positive")
        if bootstrap_batch_weight != 1.0 and cross3b_variant != "post_update_eval":
            raise ValueError(
                "bootstrap_batch_weight requires post_update_eval"
            )
        if policy_stat_gate and cross3b_variant != "post_update_eval":
            raise ValueError("policy_stat_gate requires post_update_eval")
        if (
            self.two_batch_reference_diagnostics
            and cross3b_variant != "post_update_eval"
        ):
            raise ValueError(
                "two_batch_reference_diagnostics requires post_update_eval"
            )
        if self.two_batch_reference_diagnostics and policy_batch_ratio <= 0.0:
            raise ValueError(
                "two_batch_reference_diagnostics requires a policy batch"
            )
        if (
            self.two_batch_reference_diagnostics
            and policy_batch_mode != "always"
        ):
            raise ValueError(
                "two_batch_reference_diagnostics requires policy_batch_mode=always"
            )
        if self.two_batch_reference_diagnostics and (
            detach_policy_moments or conflict_aware_policy_moments
        ):
            raise ValueError(
                "two_batch_reference_diagnostics requires attached 3N gradients"
            )
        if (
            not math.isfinite(two_batch_delta_max_norm_ratio)
            or two_batch_delta_max_norm_ratio <= 0.0
        ):
            raise ValueError(
                "two_batch_delta_max_norm_ratio must be finite and positive"
            )
        if not 0.0 <= two_batch_control_ema_decay < 1.0:
            raise ValueError(
                "two_batch_control_ema_decay must be in [0, 1)"
            )
        if not math.isfinite(policy_risk_threshold) or policy_risk_threshold <= 0.0:
            raise ValueError("policy_risk_threshold must be finite and positive")
        if not 0.0 <= policy_risk_min_scale <= 1.0:
            raise ValueError("policy_risk_min_scale must be in [0, 1]")
        if policy_risk_gate_mode not in {"full_loss", "q_only"}:
            raise ValueError(
                "policy_risk_gate_mode must be full_loss or q_only"
            )
        if not math.isfinite(policy_stat_mean_budget) or policy_stat_mean_budget <= 0:
            raise ValueError("policy_stat_mean_budget must be finite and positive")
        if (
            not math.isfinite(policy_stat_log_var_budget)
            or policy_stat_log_var_budget <= 0
        ):
            raise ValueError(
                "policy_stat_log_var_budget must be finite and positive"
            )
        if not 0.0 < policy_stat_gate_recovery <= 1.0:
            raise ValueError("policy_stat_gate_recovery must be in (0, 1]")
        if policy_batch_mode not in {"always", "actor_only"}:
            raise ValueError("policy_batch_mode must be always or actor_only")
        if action_shift_allocation:
            if cross3b_variant != "post_update_eval":
                raise ValueError(
                    "action_shift_allocation requires post_update_eval"
                )
            if policy_batch_ratio <= 0.0:
                raise ValueError(
                    "action_shift_allocation requires policy_batch_ratio > 0"
                )
            if policy_batch_mode != "always":
                raise ValueError(
                    "action_shift_allocation requires policy_batch_mode=always"
                )
        if (
            not math.isfinite(action_shift_low)
            or not math.isfinite(action_shift_high)
            or action_shift_low < 0.0
            or action_shift_high <= action_shift_low
        ):
            raise ValueError(
                "action shift thresholds must be finite with 0 <= low < high"
            )
        if (
            action_shift_warmup_updates < 0
            or action_shift_transition_updates < 0
        ):
            raise ValueError(
                "action shift schedule updates must be nonnegative"
            )
        if detach_policy_moments and conflict_aware_policy_moments:
            raise ValueError(
                "detach_policy_moments and conflict_aware_policy_moments "
                "are mutually exclusive"
            )
        if policy_moment_conflict_until_updates < 0:
            raise ValueError(
                "policy_moment_conflict_until_updates must be nonnegative"
            )
        if policy_moment_max_grad_ratio <= 0.0:
            raise ValueError("policy_moment_max_grad_ratio must be positive")
        if not 0.0 <= policy_moment_projection_strength <= 1.0:
            raise ValueError(
                "policy_moment_projection_strength must be in [0, 1]"
            )
        if policy_moment_projection_scope not in {
            "global",
            "layerwise",
            "adaptive",
        }:
            raise ValueError(
                "policy_moment_projection_scope must be global, layerwise, "
                "or adaptive"
            )
        if not 0.0 <= policy_moment_conflict_energy_threshold <= 1.0:
            raise ValueError(
                "policy_moment_conflict_energy_threshold must be in [0, 1]"
            )
        if cross3b_variant not in {
            "joint",
            "joint_consistent",
            "post_update_eval",
            "post_update_train",
            "policy_risk_probe",
        }:
            raise ValueError(
                f"Unknown Cross3B variant: {cross3b_variant}"
            )
        if cross3b_variant == "policy_risk_probe":
            if policy_batch_ratio != 0.0:
                raise ValueError(
                    "policy_risk_probe requires policy_batch_ratio=0 so P "
                    "cannot enter critic normalization statistics"
                )
            if bootstrap_batch_weight != 1.0:
                raise ValueError(
                    "policy_risk_probe requires bootstrap_batch_weight=1"
                )
            if (
                policy_stat_gate
                or detach_policy_moments
                or conflict_aware_policy_moments
                or self.two_batch_reference_diagnostics
            ):
                raise ValueError(
                    "policy_risk_probe cannot be combined with 3N critic "
                    "statistics, moment projection, or 2N/3N control"
                )

    def train(self, batch_size, gradient_steps):
        data = self.replay_buffer.sample(
            batch_size * gradient_steps,
            env=self._vec_normalize_env,
        )

        policy_delay_indices = {
            i: True
            for i in range(gradient_steps)
            if ((self._n_updates + i + 1) % self.policy_delay) == 0
        }
        policy_delay_indices = flax.core.FrozenDict(policy_delay_indices)

        if isinstance(data.observations, dict):
            keys = list(self.observation_space.keys())
            obs = np.concatenate(
                [data.observations[key].numpy() for key in keys], axis=1
            )
            next_obs = np.concatenate(
                [data.next_observations[key].numpy() for key in keys], axis=1
            )
        else:
            obs = data.observations.numpy()
            next_obs = data.next_observations.numpy()

        data = ReplayBufferSamplesNp(
            obs,
            data.actions.numpy(),
            next_obs,
            data.dones.numpy().flatten(),
            data.rewards.numpy().flatten(),
        )

        if self.cross3b_variant in {
            "post_update_eval",
            "post_update_train",
            "policy_risk_probe",
        }:
            (
                self.policy.qf_state,
                self.policy.actor_state,
                self.ent_coef_state,
                self.key,
                log_metrics,
                self._two_batch_delta_ema,
            ) = self._train_3n_post_update(
                self.td3_mode,
                self.gamma,
                self.tau,
                self.target_entropy,
                gradient_steps,
                data,
                policy_delay_indices,
                self.policy.qf_state,
                self.policy.actor_state,
                self.ent_coef_state,
                self.key,
                self.policy_q_reduce_fn,
                self.cross3b_variant == "post_update_train",
                self.current_policy_batch_weight(),
                self.policy_batch_ratio > 0.0,
                self.policy_batch_mode == "actor_only",
                self.action_shift_allocation,
                self.action_shift_low,
                self.action_shift_high,
                self.current_action_shift_allocation_floor(),
                self.detach_policy_moments,
                self.current_conflict_aware_policy_moments(),
                self.policy_moment_max_grad_ratio,
                self.policy_moment_projection_strength,
                self.policy_moment_projection_scope,
                self.policy_moment_conflict_energy_threshold,
                self.bootstrap_batch_weight,
                self.two_batch_reference_diagnostics,
                self.two_batch_reference_control,
                self.two_batch_delta_max_norm_ratio,
                self._two_batch_delta_ema,
                self.two_batch_control_ema_decay,
                self.two_batch_control_guard_low_delta,
                self.cross3b_variant == "policy_risk_probe",
                self.policy_risk_threshold,
                self.policy_risk_min_scale,
                self.policy_risk_gate_mode,
            )
        else:
            (
                self.policy.qf_state,
                self.policy.actor_state,
                self.ent_coef_state,
                self.key,
                log_metrics,
            ) = self._train_3b(
                self.td3_mode,
                self.gamma,
                self.tau,
                self.target_entropy,
                gradient_steps,
                data,
                policy_delay_indices,
                self.policy.qf_state,
                self.policy.actor_state,
                self.ent_coef_state,
                self.key,
                self.policy_q_reduce_fn,
                self.cross3b_variant == "joint_consistent",
            )
        self._n_updates += gradient_steps

        self.logger.record("train/n_updates", self._n_updates, exclude="tensorboard")
        self.last_train_metrics = {
            key: value.item() for key, value in log_metrics.items()
        }
        risk_actor_update = bool(
            self.last_train_metrics.get("policy_risk_actor_update", 0.0)
        )
        for key, value in self.last_train_metrics.items():
            if key.startswith("policy_risk_") and key != "policy_risk_actor_update":
                if risk_actor_update:
                    self._policy_risk_metric_sums[key] = (
                        self._policy_risk_metric_sums.get(key, 0.0) + value
                    )
            else:
                self._train_metric_sums[key] = (
                    self._train_metric_sums.get(key, 0.0) + value
                )
        if risk_actor_update:
            self._policy_risk_metric_count += 1
        self._train_metric_count += 1
        for key, value in self.last_train_metrics.items():
            self.logger.record(f"train/{key}", value)

    def current_policy_batch_weight(self) -> float:
        """Return the curriculum weight for the current critic update."""
        if self.policy_batch_ratio <= 0.0:
            return 0.0
        completed = int(self._n_updates)
        if completed < self.policy_batch_warmup_updates:
            return 0.0
        if self.policy_batch_ramp_updates == 0:
            return float(self.policy_batch_ratio)
        progress = (
            completed - self.policy_batch_warmup_updates
        ) / self.policy_batch_ramp_updates
        return float(self.policy_batch_ratio * min(max(progress, 0.0), 1.0))

    def current_action_shift_allocation_floor(self) -> float:
        """Keep policy-batch mass during the action-alignment warm start."""
        if not self.action_shift_allocation:
            return 0.0
        completed = int(self._n_updates)
        if completed < self.action_shift_warmup_updates:
            return 1.0
        if self.action_shift_transition_updates == 0:
            return 0.0
        progress = (
            completed - self.action_shift_warmup_updates
        ) / self.action_shift_transition_updates
        return float(1.0 - min(max(progress, 0.0), 1.0))

    def current_conflict_aware_policy_moments(self) -> bool:
        """Apply policy-moment projection only in its configured phase."""
        if not self.conflict_aware_policy_moments:
            return False
        limit = self.policy_moment_conflict_until_updates
        return limit == 0 or int(self._n_updates) < limit

    def consume_train_metric_means(self):
        if self._train_metric_count == 0:
            return {}
        means = {
            key: value / self._train_metric_count
            for key, value in self._train_metric_sums.items()
        }
        if self._policy_risk_metric_count:
            means.update(
                {
                    key: value / self._policy_risk_metric_count
                    for key, value in self._policy_risk_metric_sums.items()
                }
            )
        self._train_metric_sums = {}
        self._train_metric_count = 0
        self._policy_risk_metric_sums = {}
        self._policy_risk_metric_count = 0
        return means

    @staticmethod
    @partial(
        jax.jit,
        static_argnames=[
            "update_actor",
            "td3_mode",
            "q_reduce_fn",
            "consistent_actor_train",
        ],
    )
    def update_critic_and_actor(
        update_actor: bool,
        td3_mode: bool,
        gamma: float,
        actor_state: ActorTrainState,
        qf_state: RLTrainState,
        ent_coef_state: TrainState,
        observations: np.ndarray,
        actions: np.ndarray,
        next_observations: np.ndarray,
        rewards: np.ndarray,
        dones: np.ndarray,
        key: jax.random.KeyArray,
        q_reduce_fn=jnp.min,
        consistent_actor_train=False,
    ):
        key, noise_key, next_noise_key, dropout_key, redq_key = jax.random.split(
            key, 5
        )

        next_dist = actor_state.apply_fn(
            {
                "params": actor_state.params,
                "batch_stats": actor_state.batch_stats,
            },
            next_observations,
            train=False,
        )

        if td3_mode:
            ent_coef_value = 0.0
            target_policy_noise = 0.2
            target_noise_clip = 0.5
            next_actions = next_dist.mode()
            noise = (
                jax.random.normal(next_noise_key, next_actions.shape)
                * target_policy_noise
            )
            noise = jnp.clip(noise, -target_noise_clip, target_noise_clip)
            next_actions = jnp.clip(next_actions + noise, -1.0, 1.0)
            next_log_prob = jnp.zeros(next_actions.shape[0])
        else:
            ent_coef_value = ent_coef_state.apply_fn(
                {"params": ent_coef_state.params}
            )
            next_actions = next_dist.sample(seed=next_noise_key)
            next_log_prob = next_dist.log_prob(next_actions)

        # Bootstrap actions are targets, not actor parameters.
        next_actions = jax.lax.stop_gradient(next_actions)

        def forward(qf_params, actor_params):
            if update_actor or consistent_actor_train:
                actor_dist, actor_updates = actor_state.apply_fn(
                    {
                        "params": actor_params,
                        "batch_stats": actor_state.batch_stats,
                    },
                    observations,
                    mutable=["batch_stats"],
                    train=True,
                )
            else:
                actor_dist = actor_state.apply_fn(
                    {
                        "params": actor_params,
                        "batch_stats": actor_state.batch_stats,
                    },
                    observations,
                    train=False,
                )
                actor_updates = {"batch_stats": actor_state.batch_stats}

            if td3_mode:
                actor_actions = actor_dist.mode()
                log_prob = jnp.zeros(actor_actions.shape[0])
            else:
                actor_actions = actor_dist.sample(seed=noise_key)
                log_prob = actor_dist.log_prob(actor_actions).reshape(-1, 1)

            # [current (s, a), bootstrap (s', a'), policy (s, pi(s))]
            catted_observations = jnp.concatenate(
                [observations, next_observations, observations], axis=0
            )
            catted_actions = jnp.concatenate(
                [actions, next_actions, actor_actions], axis=0
            )
            catted_q_values, qf_updates = qf_state.apply_fn(
                {"params": qf_params, "batch_stats": qf_state.batch_stats},
                catted_observations,
                catted_actions,
                rngs={"dropout": dropout_key},
                mutable=["batch_stats"],
                train=True,
            )
            return (catted_q_values, log_prob), (qf_updates, actor_updates)

        (
            catted_q_values,
            log_prob,
        ), pullback, (qf_updates, actor_updates) = jax.vjp(
            forward,
            qf_state.params,
            actor_state.params,
            has_aux=True,
        )
        _, _, actor_q_values = jnp.split(catted_q_values, 3, axis=1)

        def critic_loss_from_q(q_values):
            current_q_values, next_q_values, _ = jnp.split(q_values, 3, axis=1)
            if next_q_values.shape[0] > 2:
                next_q_values = jax.random.choice(
                    redq_key,
                    next_q_values,
                    (2,),
                    replace=False,
                    axis=0,
                )

            next_q_values = jnp.min(next_q_values, axis=0)
            next_q_values = next_q_values - ent_coef_value * next_log_prob.reshape(
                -1, 1
            )
            target_q_values = rewards.reshape(
                -1, 1
            ) + (1 - dones.reshape(-1, 1)) * gamma * next_q_values
            critic_loss = (
                0.5
                * (
                    (
                        jax.lax.stop_gradient(target_q_values)
                        - current_q_values
                    )
                    ** 2
                ).mean(axis=1).sum()
            )
            return critic_loss, current_q_values, next_q_values

        critic_loss, current_q_values, next_q_values = critic_loss_from_q(
            catted_q_values
        )
        critic_q_cotangent = jax.grad(
            lambda q_values: critic_loss_from_q(q_values)[0]
        )(catted_q_values)
        qf_grads = pullback(
            (critic_q_cotangent, jnp.zeros_like(log_prob))
        )[0]

        def actor_loss_from_outputs(q_values, action_log_prob):
            return _joint_actor_loss_from_outputs(
                q_values,
                action_log_prob,
                ent_coef_value,
                q_reduce_fn,
            )

        actor_loss = actor_loss_from_outputs(catted_q_values, log_prob)
        if update_actor:
            actor_q_cotangent, actor_log_prob_cotangent = jax.grad(
                actor_loss_from_outputs,
                argnums=(0, 1),
            )(catted_q_values, log_prob)
            actor_grads = pullback(
                (actor_q_cotangent, actor_log_prob_cotangent)
            )[1]
            actor_state = actor_state.apply_gradients(grads=actor_grads)
            actor_state = actor_state.replace(
                batch_stats=actor_updates["batch_stats"]
            )

        qf_state = qf_state.apply_gradients(grads=qf_grads)
        qf_state = qf_state.replace(batch_stats=qf_updates["batch_stats"])

        entropy = -log_prob.mean()
        metrics = {
            "critic_loss": critic_loss,
            "actor_loss": actor_loss,
            "ent_coef": ent_coef_value,
            "current_q_values": current_q_values.mean(),
            "next_q_values": next_q_values.mean(),
            "actor_q_values": actor_q_values.mean(),
        }

        return qf_state, actor_state, entropy, metrics, key

    @classmethod
    @partial(
        jax.jit,
        static_argnames=[
            "cls",
            "td3_mode",
            "gradient_steps",
            "q_reduce_fn",
            "consistent_actor_train",
        ],
    )
    def _train_3b(
        cls,
        td3_mode: bool,
        gamma: float,
        tau: float,
        target_entropy: np.ndarray,
        gradient_steps: int,
        data: ReplayBufferSamplesNp,
        policy_delay_indices: flax.core.FrozenDict,
        qf_state: RLTrainState,
        actor_state: ActorTrainState,
        ent_coef_state: TrainState,
        key,
        q_reduce_fn,
        consistent_actor_train: bool = False,
    ):
        entropy = jnp.array(0.0)
        log_metrics_critic = {}

        for i in range(gradient_steps):

            def slice_batch(x, step=i):
                assert x.shape[0] % gradient_steps == 0
                batch_size = x.shape[0] // gradient_steps
                return x[batch_size * step : batch_size * (step + 1)]

            update_actor = i in policy_delay_indices
            (
                qf_state,
                actor_state,
                entropy,
                log_metrics_critic,
                key,
            ) = cls.update_critic_and_actor(
                update_actor,
                td3_mode,
                gamma,
                actor_state,
                qf_state,
                ent_coef_state,
                slice_batch(data.observations),
                slice_batch(data.actions),
                slice_batch(data.next_observations),
                slice_batch(data.rewards),
                slice_batch(data.dones),
                key,
                q_reduce_fn,
                consistent_actor_train,
            )
            qf_state = SAC.soft_update(tau, qf_state)

            if update_actor:
                ent_coef_state, _ = SAC.update_temperature(
                    target_entropy,
                    ent_coef_state,
                    entropy,
                )

        log_metrics = {
            "actor_loss": log_metrics_critic["actor_loss"],
            **log_metrics_critic,
        }
        return (
            qf_state,
            actor_state,
            ent_coef_state,
            key,
            log_metrics,
        )

    @staticmethod
    @partial(
        jax.jit,
        static_argnames=[
            "td3_mode",
            "include_policy_batch",
            "action_shift_allocation",
            "detach_policy_moments",
            "conflict_aware_policy_moments",
            "policy_moment_projection_scope",
            "two_batch_reference_diagnostics",
            "two_batch_reference_control",
            "two_batch_control_guard_low_delta",
        ],
    )
    def update_critic_3n_eval_actor(
        td3_mode: bool,
        gamma: float,
        actor_state: ActorTrainState,
        qf_state: RLTrainState,
        ent_coef_state: TrainState,
        observations: np.ndarray,
        actions: np.ndarray,
        next_observations: np.ndarray,
        rewards: np.ndarray,
        dones: np.ndarray,
        key: jax.random.KeyArray,
        policy_batch_weight: float,
        include_policy_batch: bool,
        detach_policy_moments: bool,
        conflict_aware_policy_moments: bool,
        policy_moment_max_grad_ratio: float,
        policy_moment_projection_strength: float,
        policy_moment_projection_scope: str,
        policy_moment_conflict_energy_threshold: float,
        bootstrap_batch_weight: float = 1.0,
        two_batch_reference_diagnostics: bool = False,
        two_batch_reference_control: bool = False,
        two_batch_delta_max_norm_ratio: float = 0.22,
        two_batch_delta_ema: float = 0.0,
        two_batch_control_ema_decay: float = 0.0,
        two_batch_control_guard_low_delta: bool = False,
        action_shift_allocation: bool = False,
        action_shift_low: float = 0.35,
        action_shift_high: float = 0.45,
        action_shift_allocation_floor: float = 0.0,
    ):
        key, next_noise_key, policy_noise_key, dropout_key = jax.random.split(
            key, 4
        )

        next_dist = actor_state.apply_fn(
            {
                "params": actor_state.params,
                "batch_stats": actor_state.batch_stats,
            },
            next_observations,
            train=False,
        )
        if include_policy_batch:
            policy_dist = actor_state.apply_fn(
                {
                    "params": actor_state.params,
                    "batch_stats": actor_state.batch_stats,
                },
                observations,
                train=False,
            )

        if td3_mode:
            ent_coef_value = 0.0
            next_actions = next_dist.mode()
        else:
            ent_coef_value = ent_coef_state.apply_fn(
                {"params": ent_coef_state.params}
            )
            next_actions = next_dist.sample(seed=next_noise_key)

        next_log_prob = (
            jnp.zeros(next_actions.shape[0])
            if td3_mode
            else next_dist.log_prob(next_actions)
        )
        next_actions = jax.lax.stop_gradient(next_actions)
        if include_policy_batch:
            policy_actions = policy_dist.sample(seed=policy_noise_key)

        if include_policy_batch:
            policy_action_shift = jnp.mean(jnp.abs(policy_actions - actions))
        else:
            policy_action_shift = jnp.array(0.0)
        if action_shift_allocation:
            raw_allocation_scale = jnp.clip(
                (action_shift_high - policy_action_shift)
                / (action_shift_high - action_shift_low),
                0.0,
                1.0,
            )
            allocation_scale = jnp.maximum(
                raw_allocation_scale,
                action_shift_allocation_floor,
            )
            allocation_scale = jax.lax.stop_gradient(allocation_scale)
            effective_policy_batch_weight = (
                policy_batch_weight * allocation_scale
            )
            effective_bootstrap_batch_weight = (
                bootstrap_batch_weight
                + policy_batch_weight * (1.0 - allocation_scale)
            )
        else:
            raw_allocation_scale = jnp.array(1.0)
            allocation_scale = jnp.array(1.0)
            effective_policy_batch_weight = jnp.asarray(
                policy_batch_weight, dtype=jnp.float32
            )
            effective_bootstrap_batch_weight = jnp.asarray(
                bootstrap_batch_weight, dtype=jnp.float32
            )

        def critic_loss(params, use_policy_batch, detach_moments):
            batch_size = observations.shape[0]
            if use_policy_batch:
                sample_weights = jnp.concatenate(
                    [
                        jnp.ones(batch_size, dtype=jnp.float32),
                        jnp.full(
                            batch_size,
                            effective_bootstrap_batch_weight,
                            dtype=jnp.float32,
                        ),
                        jnp.full(
                            batch_size,
                            effective_policy_batch_weight,
                            dtype=jnp.float32,
                        ),
                    ]
                )
                catted_observations = jnp.concatenate(
                    [observations, next_observations, observations],
                    axis=0,
                )
                catted_actions = jnp.concatenate(
                    [actions, next_actions, policy_actions], axis=0
                )
                sample_grad_mask = None
                policy_batch_mask = jnp.concatenate(
                    [
                        jnp.zeros(2 * batch_size, dtype=jnp.float32),
                        jnp.ones(batch_size, dtype=jnp.float32),
                    ]
                )
                if detach_moments:
                    sample_grad_mask = jnp.concatenate(
                        [
                            jnp.ones(2 * batch_size, dtype=jnp.float32),
                            jnp.zeros(batch_size, dtype=jnp.float32),
                        ]
                    )
            else:
                sample_weights = jnp.concatenate(
                    [
                        jnp.ones(batch_size, dtype=jnp.float32),
                        jnp.full(
                            batch_size,
                            effective_bootstrap_batch_weight,
                            dtype=jnp.float32,
                        ),
                    ]
                )
                sample_grad_mask = None
                policy_batch_mask = None
                catted_observations = jnp.concatenate(
                    [observations, next_observations], axis=0
                )
                catted_actions = jnp.concatenate(
                    [actions, next_actions], axis=0
                )

            catted_q_values, state_updates = qf_state.apply_fn(
                {"params": params, "batch_stats": qf_state.batch_stats},
                catted_observations,
                catted_actions,
                sample_weights,
                sample_grad_mask,
                policy_batch_mask,
                rngs={"dropout": dropout_key},
                mutable=["batch_stats"],
                train=True,
            )
            current_q_values = catted_q_values[:, :batch_size]
            next_q_values = catted_q_values[:, batch_size : 2 * batch_size]
            next_q_values = jnp.min(next_q_values, axis=0)
            next_q_values = next_q_values - ent_coef_value * next_log_prob.reshape(
                -1, 1
            )
            target_q_values = rewards.reshape(
                -1, 1
            ) + (1 - dones.reshape(-1, 1)) * gamma * next_q_values
            loss = (
                0.5
                * (
                    (
                        jax.lax.stop_gradient(target_q_values)
                        - current_q_values
                    )
                    ** 2
                ).mean(axis=1).sum()
            )
            metrics = {
                "critic_loss": loss,
                "ent_coef": ent_coef_value,
                "current_q_values": current_q_values.mean(),
                "next_q_values": next_q_values.mean(),
            }
            return loss, (state_updates, metrics)

        def loss_and_grad(use_policy_batch, detach_moments):
            return jax.value_and_grad(
                lambda params: critic_loss(
                    params,
                    use_policy_batch,
                    detach_moments,
                ),
                has_aux=True,
            )(qf_state.params)

        if conflict_aware_policy_moments and include_policy_batch:
            (
                (_, (state_updates, metrics)),
                attached_grads,
            ) = loss_and_grad(True, False)
            (_, _), detached_grads = loss_and_grad(True, True)
            policy_moment_grads = jax.tree_util.tree_map(
                lambda attached, detached: attached - detached,
                attached_grads,
                detached_grads,
            )
            if policy_moment_projection_scope == "adaptive":
                grads, moment_metrics = _adaptive_conflict_aware_merge(
                    detached_grads,
                    policy_moment_grads,
                    policy_moment_max_grad_ratio,
                    policy_moment_projection_strength,
                    policy_moment_conflict_energy_threshold,
                )
            else:
                merge_fn = (
                    _layerwise_conflict_aware_merge
                    if policy_moment_projection_scope == "layerwise"
                    else _conflict_aware_merge
                )
                grads, moment_metrics = merge_fn(
                    detached_grads,
                    policy_moment_grads,
                    policy_moment_max_grad_ratio,
                    policy_moment_projection_strength,
                )
        else:
            (_, (state_updates, metrics)), grads = loss_and_grad(
                include_policy_batch,
                detach_policy_moments,
            )
            moment_metrics = {
                "policy_moment_grad_cosine": jnp.array(0.0),
                "policy_moment_grad_scale": jnp.array(
                    0.0 if detach_policy_moments else 1.0
                ),
                "policy_moment_grad_norm_ratio": jnp.array(0.0),
                "policy_moment_grad_retained_ratio": jnp.array(0.0),
                "policy_moment_grad_conflict": jnp.array(0.0),
                "policy_moment_conflict_leaf_fraction": jnp.array(0.0),
                "policy_moment_conflict_energy_fraction": jnp.array(0.0),
                "policy_moment_projection_layerwise": jnp.array(0.0),
            }
        reference_metrics = {}
        if two_batch_reference_diagnostics:
            (
                (
                    two_batch_loss,
                    (two_batch_state_updates, two_batch_metrics),
                ),
                two_batch_grads,
            ) = loss_and_grad(False, False)
            two_batch_candidate = qf_state.apply_gradients(
                grads=two_batch_grads
            )
            three_batch_candidate = qf_state.apply_gradients(grads=grads)
            two_batch_step = _tree_difference(
                two_batch_candidate.params,
                qf_state.params,
            )
            three_batch_step = _tree_difference(
                three_batch_candidate.params,
                qf_state.params,
            )
            reference_metrics = {
                "two_batch_ref_critic_loss": two_batch_loss,
                "two_batch_ref_critic_loss_relative_delta": (
                    metrics["critic_loss"] - two_batch_loss
                )
                / (jnp.abs(two_batch_loss) + jnp.finfo(jnp.float32).eps),
                **_tree_comparison_metrics(
                    two_batch_grads,
                    grads,
                    "two_batch_ref_grad",
                ),
                **_tree_comparison_metrics(
                    two_batch_step,
                    three_batch_step,
                    "two_batch_ref_adam_step",
                ),
                **_batch_stat_candidate_metrics(
                    qf_state.batch_stats,
                    two_batch_state_updates["batch_stats"],
                    state_updates["batch_stats"],
                ),
            }
            step_delta_ratio = reference_metrics[
                "two_batch_ref_adam_step_delta_norm_ratio"
            ]
            updated_delta_ema = (
                two_batch_control_ema_decay * two_batch_delta_ema
                + (1.0 - two_batch_control_ema_decay) * step_delta_ratio
            )
            if two_batch_control_guard_low_delta:
                accept_three_batch = jnp.logical_or(
                    updated_delta_ema <= two_batch_delta_max_norm_ratio,
                    step_delta_ratio <= two_batch_delta_max_norm_ratio,
                )
            else:
                accept_three_batch = (
                    updated_delta_ema <= two_batch_delta_max_norm_ratio
                )
            reference_metrics.update(
                two_batch_ref_adam_step_delta_ema=updated_delta_ema,
                two_batch_ref_three_batch_accepted=jnp.where(
                    two_batch_reference_control,
                    accept_three_batch.astype(jnp.float32),
                    jnp.array(1.0),
                ),
                two_batch_ref_committed_step_delta_norm_ratio=jnp.where(
                    two_batch_reference_control
                    & jnp.logical_not(accept_three_batch),
                    jnp.array(0.0),
                    step_delta_ratio,
                ),
            )
            if two_batch_reference_control:
                selected_params = jax.tree_util.tree_map(
                    lambda three_batch, two_batch: jnp.where(
                        accept_three_batch,
                        three_batch,
                        two_batch,
                    ),
                    three_batch_candidate.params,
                    two_batch_candidate.params,
                )
                selected_opt_state = jax.tree_util.tree_map(
                    lambda three_batch, two_batch: jnp.where(
                        accept_three_batch,
                        three_batch,
                        two_batch,
                    ),
                    three_batch_candidate.opt_state,
                    two_batch_candidate.opt_state,
                )
                committed_batch_stats = jax.tree_util.tree_map(
                    lambda three_batch, two_batch: jnp.where(
                        accept_three_batch,
                        three_batch,
                        two_batch,
                    ),
                    state_updates["batch_stats"],
                    two_batch_state_updates["batch_stats"],
                )
                qf_state = three_batch_candidate.replace(
                    params=selected_params,
                    opt_state=selected_opt_state,
                )
                committed_grads = jax.tree_util.tree_map(
                    lambda three_batch, two_batch: jnp.where(
                        accept_three_batch,
                        three_batch,
                        two_batch,
                    ),
                    grads,
                    two_batch_grads,
                )
                metrics = jax.tree_util.tree_map(
                    lambda three_batch, two_batch: jnp.where(
                        accept_three_batch,
                        three_batch,
                        two_batch,
                    ),
                    metrics,
                    two_batch_metrics,
                )
            else:
                committed_batch_stats = state_updates["batch_stats"]
                committed_grads = grads
                qf_state = three_batch_candidate
        else:
            committed_batch_stats = state_updates["batch_stats"]
            committed_grads = grads
            qf_state = qf_state.apply_gradients(grads=grads)
        qf_state = qf_state.replace(batch_stats=committed_batch_stats)
        grad_norm = jnp.sqrt(
            sum(
                jnp.sum(jnp.square(leaf))
                for leaf in jax.tree_util.tree_leaves(committed_grads)
            )
        )
        gate_scales = _batch_stat_values(
            committed_batch_stats, "policy_gate_scale", default=1.0
        )
        gate_mean_shifts = _batch_stat_values(
            committed_batch_stats, "policy_gate_mean_shift"
        )
        gate_log_var_shifts = _batch_stat_values(
            committed_batch_stats, "policy_gate_log_var_shift"
        )
        gate_cap_mean_shifts = _batch_stat_values(
            committed_batch_stats, "policy_gate_cap_mean_shift"
        )
        gate_cap_log_var_shifts = _batch_stat_values(
            committed_batch_stats, "policy_gate_cap_log_var_shift"
        )
        metrics = {
            **metrics,
            "critic_grad_norm": grad_norm,
            "policy_batch_weight": jnp.where(
                include_policy_batch,
                effective_policy_batch_weight,
                jnp.array(0.0, dtype=jnp.float32),
            ),
            "bootstrap_batch_weight": effective_bootstrap_batch_weight,
            "action_shift_allocation_scale": jnp.where(
                action_shift_allocation,
                allocation_scale,
                jnp.array(1.0, dtype=jnp.float32),
            ),
            "action_shift_raw_allocation_scale": jnp.where(
                action_shift_allocation,
                raw_allocation_scale,
                jnp.array(1.0, dtype=jnp.float32),
            ),
            "action_shift_allocation_floor": jnp.where(
                action_shift_allocation,
                jnp.asarray(
                    action_shift_allocation_floor, dtype=jnp.float32
                ),
                jnp.array(0.0, dtype=jnp.float32),
            ),
            "policy_action_shift": policy_action_shift,
            "policy_stat_gate_scale_mean": jnp.mean(gate_scales),
            "policy_stat_gate_scale_min": jnp.min(gate_scales),
            "policy_stat_gate_active_fraction": jnp.mean(gate_scales < 0.999),
            "policy_stat_gate_mean_shift": jnp.mean(gate_mean_shifts),
            "policy_stat_gate_mean_shift_max": jnp.max(gate_mean_shifts),
            "policy_stat_gate_log_var_shift": jnp.mean(gate_log_var_shifts),
            "policy_stat_gate_log_var_shift_max": jnp.max(
                gate_log_var_shifts
            ),
            "policy_stat_gate_cap_mean_shift": jnp.mean(
                gate_cap_mean_shifts
            ),
            "policy_stat_gate_cap_mean_shift_max": jnp.max(
                gate_cap_mean_shifts
            ),
            "policy_stat_gate_cap_log_var_shift": jnp.mean(
                gate_cap_log_var_shifts
            ),
            "policy_stat_gate_cap_log_var_shift_max": jnp.max(
                gate_cap_log_var_shifts
            ),
            **moment_metrics,
            **reference_metrics,
        }
        return qf_state, metrics, key

    @staticmethod
    @partial(
        jax.jit,
        static_argnames=["q_reduce_fn", "td3_mode"],
    )
    def update_actor_train(
        actor_state: ActorTrainState,
        qf_state: RLTrainState,
        ent_coef_state: TrainState,
        observations: np.ndarray,
        key: jax.random.KeyArray,
        q_reduce_fn=jnp.min,
        td3_mode=False,
    ):
        key, dropout_key, noise_key = jax.random.split(key, 3)

        def actor_loss(params, batch_stats):
            actor_dist, state_updates = actor_state.apply_fn(
                {"params": params, "batch_stats": batch_stats},
                observations,
                mutable=["batch_stats"],
                train=True,
            )
            if td3_mode:
                actor_actions = actor_dist.mode()
                ent_coef_value = 0.0
                log_prob = jnp.zeros(actor_actions.shape[0])
            else:
                actor_actions = actor_dist.sample(seed=noise_key)
                ent_coef_value = ent_coef_state.apply_fn(
                    {"params": ent_coef_state.params}
                )
                log_prob = actor_dist.log_prob(actor_actions).reshape(-1, 1)

            qf_pi, _ = qf_state.apply_fn(
                {
                    "params": qf_state.params,
                    "batch_stats": qf_state.batch_stats,
                },
                observations,
                actor_actions,
                rngs={"dropout": dropout_key},
                mutable=["batch_stats"],
                train=True,
            )
            loss = (
                ent_coef_value * log_prob - q_reduce_fn(qf_pi, axis=0)
            ).mean()
            return loss, (-log_prob.mean(), state_updates)

        (actor_loss_value, (entropy, state_updates)), grads = (
            jax.value_and_grad(actor_loss, has_aux=True)(
                actor_state.params,
                actor_state.batch_stats,
            )
        )
        actor_state = actor_state.apply_gradients(grads=grads)
        actor_state = actor_state.replace(
            batch_stats=state_updates["batch_stats"]
        )
        return actor_state, qf_state, actor_loss_value, key, entropy

    @staticmethod
    @partial(
        jax.jit,
        static_argnames=["risk_gate_mode", "q_reduce_fn", "td3_mode"],
    )
    def update_actor_policy_risk_probe(
        actor_state: ActorTrainState,
        qf_state: RLTrainState,
        ent_coef_state: TrainState,
        observations: np.ndarray,
        replay_actions: np.ndarray,
        key: jax.random.KeyArray,
        risk_threshold: float,
        risk_min_scale: float,
        risk_gate_mode: str,
        q_reduce_fn=jnp.min,
        td3_mode=False,
    ):
        """Update the actor while keeping P out of critic training statistics.

        Twin-critic disagreement on P=(s, pi(s)) is normalized by disagreement
        on replay actions from the same states. Samples beyond the configured
        risk threshold receive a smoothly reduced actor-loss weight. The
        weight is stopped so the actor cannot optimize the risk estimator.
        """
        key, dropout_key, noise_key, _ = jax.random.split(key, 4)
        epsilon = jnp.finfo(jnp.float32).eps

        replay_q_values = qf_state.apply_fn(
            {
                "params": qf_state.params,
                "batch_stats": qf_state.batch_stats,
            },
            observations,
            replay_actions,
            rngs={"dropout": dropout_key},
            train=False,
        )
        replay_disagreement = jnp.max(replay_q_values, axis=0) - jnp.min(
            replay_q_values, axis=0
        )
        replay_disagreement_mean = jnp.mean(replay_disagreement)
        replay_q_scale = jnp.mean(jnp.abs(replay_q_values))
        risk_normalizer = replay_disagreement_mean + epsilon * (
            1.0 + replay_q_scale
        )

        def actor_loss(params, batch_stats):
            actor_dist, state_updates = actor_state.apply_fn(
                {"params": params, "batch_stats": batch_stats},
                observations,
                mutable=["batch_stats"],
                train=True,
            )
            if td3_mode:
                actor_actions = actor_dist.mode()
                ent_coef_value = 0.0
                log_prob = jnp.zeros((actor_actions.shape[0], 1))
            else:
                actor_actions = actor_dist.sample(seed=noise_key)
                ent_coef_value = ent_coef_state.apply_fn(
                    {"params": ent_coef_state.params}
                )
                log_prob = actor_dist.log_prob(actor_actions).reshape(-1, 1)

            policy_q_values = qf_state.apply_fn(
                {
                    "params": qf_state.params,
                    "batch_stats": qf_state.batch_stats,
                },
                observations,
                actor_actions,
                rngs={"dropout": dropout_key},
                train=False,
            )
            policy_disagreement = jnp.max(
                policy_q_values, axis=0
            ) - jnp.min(policy_q_values, axis=0)
            risk_ratio = policy_disagreement / risk_normalizer
            risk_scale = jnp.clip(
                risk_threshold / (risk_ratio + epsilon),
                risk_min_scale,
                1.0,
            )
            risk_scale = jax.lax.stop_gradient(risk_scale)

            min_qf_pi = q_reduce_fn(policy_q_values, axis=0)
            entropy_term = ent_coef_value * log_prob
            if risk_gate_mode == "q_only":
                per_sample_loss = entropy_term - risk_scale * min_qf_pi
            else:
                per_sample_loss = risk_scale * (entropy_term - min_qf_pi)
            loss = jnp.mean(per_sample_loss)
            risk_metrics = {
                "policy_risk_policy_disagreement": jnp.mean(
                    policy_disagreement
                ),
                "policy_risk_replay_disagreement": replay_disagreement_mean,
                "policy_risk_ratio_mean": jnp.mean(risk_ratio),
                "policy_risk_ratio_p90": jnp.quantile(risk_ratio, 0.9),
                "policy_risk_ratio_max": jnp.max(risk_ratio),
                "policy_risk_scale_mean": jnp.mean(risk_scale),
                "policy_risk_scale_min": jnp.min(risk_scale),
                "policy_risk_active_fraction": jnp.mean(risk_scale < 0.999),
            }
            return loss, (-log_prob.mean(), state_updates, risk_metrics)

        (
            actor_loss_value,
            (entropy, state_updates, risk_metrics),
        ), grads = jax.value_and_grad(actor_loss, has_aux=True)(
            actor_state.params,
            actor_state.batch_stats,
        )
        actor_state = actor_state.apply_gradients(grads=grads)
        actor_state = actor_state.replace(
            batch_stats=state_updates["batch_stats"]
        )
        return (
            actor_state,
            qf_state,
            actor_loss_value,
            key,
            entropy,
            risk_metrics,
        )

    @classmethod
    @partial(
        jax.jit,
        static_argnames=[
            "cls",
            "td3_mode",
            "gradient_steps",
            "q_reduce_fn",
            "actor_train",
            "policy_batch_enabled",
            "actor_only",
            "action_shift_allocation",
            "detach_policy_moments",
            "conflict_aware_policy_moments",
            "policy_moment_projection_scope",
            "two_batch_reference_diagnostics",
            "two_batch_reference_control",
            "two_batch_control_guard_low_delta",
            "policy_risk_probe",
            "policy_risk_gate_mode",
        ],
    )
    def _train_3n_post_update(
        cls,
        td3_mode: bool,
        gamma: float,
        tau: float,
        target_entropy: np.ndarray,
        gradient_steps: int,
        data: ReplayBufferSamplesNp,
        policy_delay_indices: flax.core.FrozenDict,
        qf_state: RLTrainState,
        actor_state: ActorTrainState,
        ent_coef_state: TrainState,
        key,
        q_reduce_fn,
        actor_train: bool = False,
        policy_batch_weight: float = 1.0,
        policy_batch_enabled: bool = True,
        actor_only: bool = False,
        action_shift_allocation: bool = False,
        action_shift_low: float = 0.35,
        action_shift_high: float = 0.45,
        action_shift_allocation_floor: float = 0.0,
        detach_policy_moments: bool = False,
        conflict_aware_policy_moments: bool = False,
        policy_moment_max_grad_ratio: float = 1.0,
        policy_moment_projection_strength: float = 1.0,
        policy_moment_projection_scope: str = "global",
        policy_moment_conflict_energy_threshold: float = 0.95,
        bootstrap_batch_weight: float = 1.0,
        two_batch_reference_diagnostics: bool = False,
        two_batch_reference_control: bool = False,
        two_batch_delta_max_norm_ratio: float = 0.22,
        two_batch_delta_ema: float = 0.0,
        two_batch_control_ema_decay: float = 0.0,
        two_batch_control_guard_low_delta: bool = False,
        policy_risk_probe: bool = False,
        policy_risk_threshold: float = 1.5,
        policy_risk_min_scale: float = 0.0,
        policy_risk_gate_mode: str = "full_loss",
    ):
        actor_loss_value = jnp.array(0.0)
        log_metrics_critic = {}
        risk_metrics = {
            "policy_risk_actor_update": jnp.array(0.0),
            "policy_risk_policy_disagreement": jnp.array(0.0),
            "policy_risk_replay_disagreement": jnp.array(0.0),
            "policy_risk_ratio_mean": jnp.array(0.0),
            "policy_risk_ratio_p90": jnp.array(0.0),
            "policy_risk_ratio_max": jnp.array(0.0),
            "policy_risk_scale_mean": jnp.array(1.0),
            "policy_risk_scale_min": jnp.array(1.0),
            "policy_risk_active_fraction": jnp.array(0.0),
        }

        for i in range(gradient_steps):

            def slice_batch(x, step=i):
                assert x.shape[0] % gradient_steps == 0
                batch_size = x.shape[0] // gradient_steps
                return x[batch_size * step : batch_size * (step + 1)]

            update_actor = i in policy_delay_indices
            include_policy_batch = policy_batch_enabled and (
                update_actor or not actor_only
            )
            qf_state, log_metrics_critic, key = (
                cls.update_critic_3n_eval_actor(
                    td3_mode,
                    gamma,
                    actor_state,
                    qf_state,
                    ent_coef_state,
                    slice_batch(data.observations),
                    slice_batch(data.actions),
                    slice_batch(data.next_observations),
                    slice_batch(data.rewards),
                    slice_batch(data.dones),
                    key,
                    policy_batch_weight,
                    include_policy_batch,
                    detach_policy_moments,
                    conflict_aware_policy_moments,
                    policy_moment_max_grad_ratio,
                    policy_moment_projection_strength,
                    policy_moment_projection_scope,
                    policy_moment_conflict_energy_threshold,
                    bootstrap_batch_weight,
                    two_batch_reference_diagnostics,
                    two_batch_reference_control,
                    two_batch_delta_max_norm_ratio,
                    two_batch_delta_ema,
                    two_batch_control_ema_decay,
                    two_batch_control_guard_low_delta,
                    action_shift_allocation,
                    action_shift_low,
                    action_shift_high,
                    action_shift_allocation_floor,
                )
            )
            if two_batch_reference_diagnostics:
                two_batch_delta_ema = log_metrics_critic[
                    "two_batch_ref_adam_step_delta_ema"
                ]
            qf_state = SAC.soft_update(tau, qf_state)

            if update_actor:
                if policy_risk_probe:
                    (
                        actor_state,
                        qf_state,
                        actor_loss_value,
                        key,
                        entropy,
                        risk_metrics,
                    ) = cls.update_actor_policy_risk_probe(
                        actor_state,
                        qf_state,
                        ent_coef_state,
                        slice_batch(data.observations),
                        slice_batch(data.actions),
                        key,
                        policy_risk_threshold,
                        policy_risk_min_scale,
                        policy_risk_gate_mode,
                        q_reduce_fn,
                        td3_mode,
                    )
                    risk_metrics = {
                        "policy_risk_actor_update": jnp.array(1.0),
                        **risk_metrics,
                    }
                else:
                    update_actor_fn = (
                        cls.update_actor_train
                        if actor_train
                        else SAC.update_actor
                    )
                    (
                        actor_state,
                        qf_state,
                        actor_loss_value,
                        key,
                        entropy,
                    ) = update_actor_fn(
                        actor_state,
                        qf_state,
                        ent_coef_state,
                        slice_batch(data.observations),
                        key,
                        q_reduce_fn,
                        td3_mode,
                    )
                ent_coef_state, _ = SAC.update_temperature(
                    target_entropy,
                    ent_coef_state,
                    entropy,
                )

        return (
            qf_state,
            actor_state,
            ent_coef_state,
            key,
            {
                "actor_loss": actor_loss_value,
                **log_metrics_critic,
                **(risk_metrics if policy_risk_probe else {}),
            },
            two_batch_delta_ema,
        )
    policy_aliases: ClassVar[Dict[str, Type]] = {
        "MlpPolicy": WeightedSACPolicy,
        "MultiInputPolicy": WeightedSACPolicy,
    }


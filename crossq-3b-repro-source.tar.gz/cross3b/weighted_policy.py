"""Critic and policy with strictly sample-weighted BatchRenorm statistics."""

from functools import partial
from typing import Any, Callable, Dict, List, Optional, Sequence, Type, Union

import flax.linen as nn
import jax
import jax.numpy as jnp
import numpy as np
import optax
from flax.linen.dtypes import canonicalize_dtype
from flax.linen.module import Module, compact, merge_param
from flax.linen.normalization import _canonicalize_axes, _normalize
from flax.training.train_state import TrainState
from gymnasium import spaces
from stable_baselines3.common.type_aliases import Schedule

from sbx.common.type_aliases import ActorTrainState, RLTrainState
from sbx.sac.policies import Actor, SACPolicy, UnitNormDense


def _weighted_stats(x, axes, sample_weights, sample_grad_mask=None):
    dtype = jnp.promote_types(jnp.result_type(x), jnp.float32)
    x = jnp.asarray(x, dtype)
    weights = jnp.asarray(sample_weights, dtype)
    if weights.ndim == 1 and x.ndim > 1:
        weights = weights.reshape(
            (weights.shape[0],) + (1,) * (x.ndim - 1)
        )
    stats_x = x
    if sample_grad_mask is not None:
        grad_mask = jnp.asarray(sample_grad_mask, dtype)
        if grad_mask.ndim == 1 and x.ndim > 1:
            grad_mask = grad_mask.reshape(
                (grad_mask.shape[0],) + (1,) * (x.ndim - 1)
            )
        stats_x = grad_mask * x + (1.0 - grad_mask) * jax.lax.stop_gradient(x)
    active = weights != 0
    safe_stats_x = jnp.where(active, stats_x, 0.0)
    weight_sum = jnp.sum(weights, axis=axes)
    mean = jnp.sum(safe_stats_x * weights, axis=axes) / weight_sum
    centered = jnp.where(
        active,
        stats_x - jnp.expand_dims(mean, axes),
        0.0,
    )
    var = jnp.sum(jnp.square(centered) * weights, axis=axes) / weight_sum
    return mean, var


class WeightedBatchRenorm(Module):
    """Batch Renormalization using per-sample weights for batch moments."""

    use_running_average: Optional[bool] = None
    axis: int = -1
    momentum: float = 0.999
    epsilon: float = 0.001
    dtype: Optional[Any] = None
    param_dtype: Any = jnp.float32
    use_bias: bool = True
    use_scale: bool = True
    bias_init: Callable = nn.initializers.zeros
    scale_init: Callable = nn.initializers.ones
    use_fast_variance: bool = True
    policy_stat_gate: bool = False
    policy_stat_mean_budget: float = 0.1
    policy_stat_log_var_budget: float = 0.1
    policy_stat_gate_recovery: float = 0.01
    policy_stat_gate_iterations: int = 8

    @compact
    def __call__(
        self,
        x,
        sample_weights=None,
        sample_grad_mask=None,
        policy_batch_mask=None,
        use_running_average: Optional[bool] = None,
    ):
        use_running_average = merge_param(
            "use_running_average",
            self.use_running_average,
            use_running_average,
        )
        feature_axes = _canonicalize_axes(x.ndim, self.axis)
        reduction_axes = tuple(
            i for i in range(x.ndim) if i not in feature_axes
        )
        feature_shape = [x.shape[ax] for ax in feature_axes]

        ra_mean = self.variable(
            "batch_stats",
            "mean",
            lambda s: jnp.zeros(s, jnp.float32),
            feature_shape,
        )
        ra_var = self.variable(
            "batch_stats",
            "var",
            lambda s: jnp.ones(s, jnp.float32),
            feature_shape,
        )
        r_max = self.variable("batch_stats", "r_max", lambda s: s, 3)
        d_max = self.variable("batch_stats", "d_max", lambda s: s, 5)
        steps = self.variable("batch_stats", "steps", lambda s: s, 0)
        if self.policy_stat_gate:
            gate_scale = self.variable(
                "batch_stats", "policy_gate_scale", lambda: jnp.array(1.0)
            )
            gate_mean_shift = self.variable(
                "batch_stats", "policy_gate_mean_shift", lambda: jnp.array(0.0)
            )
            gate_log_var_shift = self.variable(
                "batch_stats", "policy_gate_log_var_shift", lambda: jnp.array(0.0)
            )
            gate_cap_mean_shift = self.variable(
                "batch_stats", "policy_gate_cap_mean_shift", lambda: jnp.array(0.0)
            )
            gate_cap_log_var_shift = self.variable(
                "batch_stats", "policy_gate_cap_log_var_shift", lambda: jnp.array(0.0)
            )

        if use_running_average:
            mean, var = ra_mean.value, ra_var.value
            custom_mean, custom_var = mean, var
        else:
            if sample_weights is None:
                sample_weights = jnp.ones(x.shape[0], dtype=x.dtype)
            if self.policy_stat_gate and policy_batch_mask is not None:
                detached_x = jax.lax.stop_gradient(x)
                policy_mask = jnp.asarray(policy_batch_mask, dtype=x.dtype)
                base_weights = sample_weights * (1.0 - policy_mask)
                policy_weights = sample_weights * policy_mask
                base_mean, base_var = _weighted_stats(
                    detached_x, reduction_axes, base_weights
                )

                def shift_for(scale):
                    candidate_mean, candidate_var = _weighted_stats(
                        detached_x,
                        reduction_axes,
                        base_weights + scale * policy_weights,
                    )
                    mean_shift = jnp.sqrt(
                        jnp.mean(
                            jnp.square(candidate_mean - base_mean)
                            / (base_var + self.epsilon)
                        )
                    )
                    log_var_shift = jnp.sqrt(
                        jnp.mean(
                            jnp.square(
                                jnp.log(
                                    (candidate_var + self.epsilon)
                                    / (base_var + self.epsilon)
                                )
                            )
                        )
                    )
                    return mean_shift, log_var_shift

                cap_mean_shift, cap_log_var_shift = shift_for(1.0)

                def bisect(_, bounds):
                    low, high = bounds
                    middle = 0.5 * (low + high)
                    mean_shift, log_var_shift = shift_for(middle)
                    allowed = jnp.logical_and(
                        mean_shift <= self.policy_stat_mean_budget,
                        log_var_shift <= self.policy_stat_log_var_budget,
                    )
                    return (
                        jnp.where(allowed, middle, low),
                        jnp.where(allowed, high, middle),
                    )

                cap_allowed = jnp.logical_and(
                    cap_mean_shift <= self.policy_stat_mean_budget,
                    cap_log_var_shift <= self.policy_stat_log_var_budget,
                )

                def find_allowed_scale(_):
                    low, _ = jax.lax.fori_loop(
                        0,
                        self.policy_stat_gate_iterations,
                        bisect,
                        (jnp.array(0.0), jnp.array(1.0)),
                    )
                    return low

                allowed_scale = jax.lax.cond(
                    cap_allowed,
                    lambda _: jnp.array(1.0),
                    find_allowed_scale,
                    operand=None,
                )
                recovered_scale = gate_scale.value + self.policy_stat_gate_recovery * (
                    allowed_scale - gate_scale.value
                )
                applied_scale = jnp.where(
                    allowed_scale < gate_scale.value,
                    allowed_scale,
                    recovered_scale,
                )
                applied_scale = jax.lax.stop_gradient(applied_scale)
                sample_weights = base_weights + applied_scale * policy_weights
                actual_mean_shift, actual_log_var_shift = shift_for(applied_scale)
                if not self.is_initializing():
                    gate_scale.value = applied_scale
                    gate_mean_shift.value = actual_mean_shift
                    gate_log_var_shift.value = actual_log_var_shift
                    gate_cap_mean_shift.value = cap_mean_shift
                    gate_cap_log_var_shift.value = cap_log_var_shift
            mean, var = _weighted_stats(
                x,
                reduction_axes,
                sample_weights,
                sample_grad_mask,
            )
            custom_mean, custom_var = mean, var
            if not self.is_initializing():
                std = jnp.sqrt(var + self.epsilon)
                ra_std = jnp.sqrt(ra_var.value + self.epsilon)
                r = jax.lax.stop_gradient(std / ra_std)
                r = jnp.clip(r, 1 / r_max.value, r_max.value)
                d = jax.lax.stop_gradient(
                    (mean - ra_mean.value) / ra_std
                )
                d = jnp.clip(d, -d_max.value, d_max.value)
                tmp_var = var / (r**2)
                tmp_mean = mean - d * jnp.sqrt(custom_var) / r

                warmed_up = jnp.greater_equal(
                    steps.value, 100_000
                ).astype(jnp.float32)
                custom_var = (
                    warmed_up * tmp_var + (1.0 - warmed_up) * custom_var
                )
                custom_mean = (
                    warmed_up * tmp_mean + (1.0 - warmed_up) * custom_mean
                )

                ra_mean.value = (
                    self.momentum * ra_mean.value
                    + (1 - self.momentum) * mean
                )
                ra_var.value = (
                    self.momentum * ra_var.value
                    + (1 - self.momentum) * var
                )
                steps.value += 1

        return _normalize(
            self,
            x,
            custom_mean,
            custom_var,
            reduction_axes,
            feature_axes,
            self.dtype,
            self.param_dtype,
            self.epsilon,
            self.use_bias,
            self.use_scale,
            self.bias_init,
            self.scale_init,
        )


class WeightedCritic(nn.Module):
    net_arch: Sequence[int]
    activation_fn: Type[nn.Module]
    batch_norm_momentum: float
    use_layer_norm: bool = False
    dropout_rate: Optional[float] = None
    use_batch_norm: bool = False
    bn_mode: str = "brn"
    policy_stat_gate: bool = False
    policy_stat_mean_budget: float = 0.1
    policy_stat_log_var_budget: float = 0.1
    policy_stat_gate_recovery: float = 0.01
    weight_normalization: bool = False
    crossq_parameter_names: bool = False

    @nn.compact
    def __call__(
        self,
        x,
        action,
        sample_weights=None,
        sample_grad_mask=None,
        policy_batch_mask=None,
        train=True,
    ):
        x = jnp.concatenate([x, action], -1)
        if self.use_batch_norm:
            x = WeightedBatchRenorm(
                use_running_average=not train,
                momentum=self.batch_norm_momentum,
                policy_stat_gate=self.policy_stat_gate,
                policy_stat_mean_budget=self.policy_stat_mean_budget,
                policy_stat_log_var_budget=self.policy_stat_log_var_budget,
                policy_stat_gate_recovery=self.policy_stat_gate_recovery,
                name=(
                    "BatchRenorm_0"
                    if self.crossq_parameter_names
                    else None
                ),
            )(x, sample_weights, sample_grad_mask, policy_batch_mask)

        for layer_index, n_units in enumerate(self.net_arch):
            dense = UnitNormDense if self.weight_normalization else nn.Dense
            x = dense(n_units, name=f"Dense_{layer_index}")(x)
            if self.dropout_rate is not None and self.dropout_rate > 0:
                x = nn.Dropout(rate=self.dropout_rate)(x, deterministic=False)
            if self.use_layer_norm:
                x = nn.LayerNorm()(x)
            x = self.activation_fn()(x)
            if self.use_batch_norm:
                x = WeightedBatchRenorm(
                    use_running_average=not train,
                    momentum=self.batch_norm_momentum,
                    policy_stat_gate=self.policy_stat_gate,
                    policy_stat_mean_budget=self.policy_stat_mean_budget,
                    policy_stat_log_var_budget=self.policy_stat_log_var_budget,
                    policy_stat_gate_recovery=self.policy_stat_gate_recovery,
                    name=(
                        f"BatchRenorm_{layer_index + 1}"
                        if self.crossq_parameter_names
                        else None
                    ),
                )(x, sample_weights, sample_grad_mask, policy_batch_mask)
        return nn.Dense(1, name=f"Dense_{len(self.net_arch)}")(x)


class WeightedVectorCritic(nn.Module):
    net_arch: Sequence[int]
    activation_fn: Type[nn.Module]
    batch_norm_momentum: float
    use_batch_norm: bool = False
    batch_norm_mode: str = "brn"
    use_layer_norm: bool = False
    dropout_rate: Optional[float] = None
    n_critics: int = 2
    policy_stat_gate: bool = False
    policy_stat_mean_budget: float = 0.1
    policy_stat_log_var_budget: float = 0.1
    policy_stat_gate_recovery: float = 0.01
    weight_normalization: bool = False
    crossq_parameter_names: bool = False

    @nn.compact
    def __call__(
        self,
        obs,
        action,
        sample_weights=None,
        sample_grad_mask=None,
        policy_batch_mask=None,
        train=True,
    ):
        vmap_critic = nn.vmap(
            WeightedCritic,
            variable_axes={"params": 0, "batch_stats": 0},
            split_rngs={"params": True, "dropout": True, "batch_stats": True},
            in_axes=None,
            out_axes=0,
            axis_size=self.n_critics,
        )
        return vmap_critic(
            use_layer_norm=self.use_layer_norm,
            use_batch_norm=self.use_batch_norm,
            batch_norm_momentum=self.batch_norm_momentum,
            bn_mode=self.batch_norm_mode,
            dropout_rate=self.dropout_rate,
            net_arch=self.net_arch,
            activation_fn=self.activation_fn,
            policy_stat_gate=self.policy_stat_gate,
            policy_stat_mean_budget=self.policy_stat_mean_budget,
            policy_stat_log_var_budget=self.policy_stat_log_var_budget,
            policy_stat_gate_recovery=self.policy_stat_gate_recovery,
            weight_normalization=self.weight_normalization,
            crossq_parameter_names=self.crossq_parameter_names,
            name=("VmapCritic_0" if self.crossq_parameter_names else None),
        )(obs, action, sample_weights, sample_grad_mask, policy_batch_mask, train)


class WeightedSACPolicy(SACPolicy):
    """SAC policy that builds a sample-weighted critic."""

    def __init__(
        self,
        *args,
        policy_stat_gate: bool = False,
        policy_stat_mean_budget: float = 0.1,
        policy_stat_log_var_budget: float = 0.1,
        policy_stat_gate_recovery: float = 0.01,
        crossq_parameter_names: bool = False,
        **kwargs,
    ):
        self.policy_stat_gate = policy_stat_gate
        self.policy_stat_mean_budget = policy_stat_mean_budget
        self.policy_stat_log_var_budget = policy_stat_log_var_budget
        self.policy_stat_gate_recovery = policy_stat_gate_recovery
        self.crossq_parameter_names = crossq_parameter_names
        super().__init__(*args, **kwargs)

    def build(
        self,
        key: jax.random.KeyArray,
        lr_schedule: Schedule,
        qf_learning_rate: float,
    ) -> jax.random.KeyArray:
        key, actor_key, qf_key, dropout_key, bn_key = jax.random.split(key, 5)
        key, self.key = jax.random.split(key, 2)
        self.reset_noise()

        if isinstance(self.observation_space, spaces.Dict):
            obs = jnp.array(
                [
                    spaces.flatten(
                        self.observation_space,
                        self.observation_space.sample(),
                    )
                ]
            )
        else:
            obs = jnp.array([self.observation_space.sample()])
        action = jnp.array([self.action_space.sample()])

        self.actor = Actor(
            action_dim=int(np.prod(self.action_space.shape)),
            net_arch=self.net_arch_pi,
            use_batch_norm=self.batch_norm,
            batch_norm_momentum=self.batch_norm_momentum,
            bn_mode=self.batch_norm_mode,
        )
        self.actor.reset_noise = self.reset_noise
        actor_init_variables = self.actor.init(
            {"params": actor_key, "batch_stats": bn_key},
            obs,
            train=False,
        )
        self.actor_state = ActorTrainState.create(
            apply_fn=self.actor.apply,
            params=actor_init_variables["params"],
            batch_stats=actor_init_variables["batch_stats"],
            tx=self.optimizer_class(
                learning_rate=lr_schedule(1),
                **self.optimizer_kwargs,
            ),
        )

        self.qf = WeightedVectorCritic(
            dropout_rate=self.dropout_rate,
            use_layer_norm=self.layer_norm,
            use_batch_norm=self.batch_norm,
            batch_norm_momentum=self.batch_norm_momentum,
            batch_norm_mode=self.batch_norm_mode,
            net_arch=self.net_arch_qf,
            activation_fn=self.activation_fn,
            n_critics=self.n_critics,
            policy_stat_gate=self.policy_stat_gate,
            policy_stat_mean_budget=self.policy_stat_mean_budget,
            policy_stat_log_var_budget=self.policy_stat_log_var_budget,
            policy_stat_gate_recovery=self.policy_stat_gate_recovery,
            weight_normalization=self.critic_weight_normalization,
            crossq_parameter_names=self.crossq_parameter_names,
        )
        qf_init_variables = self.qf.init(
            {"params": qf_key, "dropout": dropout_key, "batch_stats": bn_key},
            obs,
            action,
            None,
            None,
            None,
            train=False,
        )
        target_qf_init_variables = self.qf.init(
            {"params": qf_key, "dropout": dropout_key, "batch_stats": bn_key},
            obs,
            action,
            None,
            None,
            None,
            train=False,
        )
        self.qf_state = RLTrainState.create(
            apply_fn=self.qf.apply,
            params=qf_init_variables["params"],
            batch_stats=qf_init_variables["batch_stats"],
            target_params=target_qf_init_variables["params"],
            target_batch_stats=target_qf_init_variables["batch_stats"],
            tx=self.optimizer_class(
                learning_rate=qf_learning_rate,
                **self.optimizer_kwargs,
            ),
        )

        self.actor.apply = jax.jit(
            self.actor.apply,
            static_argnames=(
                "use_batch_norm",
                "batch_norm_momentum",
                "bn_mode",
            ),
        )
        self.qf.apply = jax.jit(
            self.qf.apply,
            static_argnames=(
                "dropout_rate",
                "use_layer_norm",
                "use_batch_norm",
                "batch_norm_momentum",
                "bn_mode",
                "policy_stat_gate",
                "policy_stat_mean_budget",
                "policy_stat_log_var_budget",
                "policy_stat_gate_recovery",
            ),
        )
        return key

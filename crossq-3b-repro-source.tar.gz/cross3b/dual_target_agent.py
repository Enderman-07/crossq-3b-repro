"""Cross3B-DT: average two policy targets in one three-batch critic pass."""

from functools import partial

import flax
import jax
import jax.numpy as jnp
import numpy as np
from flax.training.train_state import TrainState

from sbx.common.type_aliases import (
    ActorTrainState,
    ReplayBufferSamplesNp,
    RLTrainState,
)
from sbx.sac.sac import SAC


class Cross3BDualTarget(SAC):
    """CrossQ with multiple independent next-action target batches."""

    def __init__(
        self,
        *args,
        target_action_samples: int = 2,
        target_action_start_steps: int = 0,
        **kwargs,
    ):
        if target_action_samples < 1:
            raise ValueError("target_action_samples must be positive")
        if target_action_start_steps < 0:
            raise ValueError("target_action_start_steps must be nonnegative")
        self.target_action_samples = target_action_samples
        self.target_action_start_steps = target_action_start_steps
        self.last_train_metrics = {}
        super().__init__(*args, **kwargs)

    def train(self, batch_size, gradient_steps):
        data = self.replay_buffer.sample(
            batch_size * gradient_steps,
            env=self._vec_normalize_env,
        )
        policy_delay_indices = flax.core.FrozenDict(
            {
                i: True
                for i in range(gradient_steps)
                if ((self._n_updates + i + 1) % self.policy_delay) == 0
            }
        )

        if isinstance(data.observations, dict):
            keys = list(self.observation_space.keys())
            obs = np.concatenate(
                [data.observations[key].numpy() for key in keys], axis=1
            )
            next_obs = np.concatenate(
                [data.next_observations[key].numpy() for key in keys], axis=1
            )
        else:
            obs = data.observations.numpy()
            next_obs = data.next_observations.numpy()
        data = ReplayBufferSamplesNp(
            obs,
            data.actions.numpy(),
            next_obs,
            data.dones.numpy().flatten(),
            data.rewards.numpy().flatten(),
        )

        active_target_action_samples = (
            1
            if self._n_updates < self.target_action_start_steps
            else self.target_action_samples
        )
        (
            self.policy.qf_state,
            self.policy.actor_state,
            self.ent_coef_state,
            self.key,
            log_metrics,
        ) = self._train_dual_target(
            self.crossq_style,
            self.td3_mode,
            self.use_bnstats_from_live_net,
            self.gamma,
            self.tau,
            self.target_entropy,
            gradient_steps,
            data,
            policy_delay_indices,
            self.policy.qf_state,
            self.policy.actor_state,
            self.ent_coef_state,
            self.key,
            self.policy_q_reduce_fn,
            active_target_action_samples,
        )
        self._n_updates += gradient_steps
        self.logger.record(
            "train/n_updates", self._n_updates, exclude="tensorboard"
        )
        self.last_train_metrics = {
            key: value.item() for key, value in log_metrics.items()
        }
        self.last_train_metrics["target_action_samples_active"] = float(
            active_target_action_samples
        )
        for key, value in self.last_train_metrics.items():
            self.logger.record(f"train/{key}", value)

    @staticmethod
    @partial(
        jax.jit,
        static_argnames=[
            "crossq_style",
            "td3_mode",
            "use_bnstats_from_live_net",
            "target_action_samples",
        ],
    )
    def update_critic_dual_target(
        crossq_style: bool,
        td3_mode: bool,
        use_bnstats_from_live_net: bool,
        gamma: float,
        actor_state: ActorTrainState,
        qf_state: RLTrainState,
        ent_coef_state: TrainState,
        observations: np.ndarray,
        actions: np.ndarray,
        next_observations: np.ndarray,
        rewards: np.ndarray,
        dones: np.ndarray,
        key: jax.random.KeyArray,
        target_action_samples: int,
    ):
        key, noise_key, dropout_key_target, dropout_key_current, redq_key = (
            jax.random.split(key, 5)
        )
        distribution = actor_state.apply_fn(
            {
                "params": actor_state.params,
                "batch_stats": actor_state.batch_stats,
            },
            next_observations,
            train=False,
        )

        sample_keys = [noise_key] + [
            jax.random.fold_in(noise_key, index)
            for index in range(1, target_action_samples)
        ]
        if td3_mode:
            ent_coef_value = 0.0
            target_actions = []
            for sample_key in sample_keys:
                action = distribution.mode()
                noise = jax.random.normal(sample_key, action.shape) * 0.2
                noise = jnp.clip(noise, -0.5, 0.5)
                target_actions.append(jnp.clip(action + noise, -1.0, 1.0))
            target_log_probs = jnp.zeros(
                (target_action_samples, observations.shape[0])
            )
        else:
            ent_coef_value = ent_coef_state.apply_fn(
                {"params": ent_coef_state.params}
            )
            target_actions = [
                distribution.sample(seed=sample_key)
                for sample_key in sample_keys
            ]
            target_log_probs = jnp.stack(
                [distribution.log_prob(action) for action in target_actions]
            )
        target_actions = [
            jax.lax.stop_gradient(action) for action in target_actions
        ]

        def critic_loss(params, batch_stats, dropout_key):
            if not crossq_style:
                target_values = []
                for target_action in target_actions:
                    value = qf_state.apply_fn(
                        {
                            "params": qf_state.target_params,
                            "batch_stats": (
                                batch_stats
                                if use_bnstats_from_live_net
                                else qf_state.target_batch_stats
                            ),
                        },
                        next_observations,
                        target_action,
                        rngs={"dropout": dropout_key_target},
                        train=False,
                    )
                    target_values.append(value)
                current_q_values, state_updates = qf_state.apply_fn(
                    {"params": params, "batch_stats": batch_stats},
                    observations,
                    actions,
                    rngs={"dropout": dropout_key},
                    mutable=["batch_stats"],
                    train=True,
                )
                target_q_values = jnp.stack(target_values, axis=1)
            else:
                batch_size = observations.shape[0]
                catted_q_values, state_updates = qf_state.apply_fn(
                    {"params": params, "batch_stats": batch_stats},
                    jnp.concatenate(
                        [observations]
                        + [next_observations] * target_action_samples,
                        axis=0,
                    ),
                    jnp.concatenate([actions] + target_actions, axis=0),
                    rngs={"dropout": dropout_key},
                    mutable=["batch_stats"],
                    train=True,
                )
                current_q_values = catted_q_values[:, :batch_size]
                target_q_values = catted_q_values[:, batch_size:].reshape(
                    catted_q_values.shape[0],
                    target_action_samples,
                    batch_size,
                    1,
                )

            if target_q_values.shape[0] > 2:
                target_q_values = jax.random.choice(
                    redq_key,
                    target_q_values,
                    (2,),
                    replace=False,
                    axis=0,
                )
            target_q_values = jnp.min(target_q_values, axis=0)
            soft_target_values = target_q_values - (
                ent_coef_value * target_log_probs[..., None]
            )
            next_q_values = jnp.mean(soft_target_values, axis=0)
            bellman_target = rewards.reshape(-1, 1) + (
                1 - dones.reshape(-1, 1)
            ) * gamma * next_q_values
            loss = (
                0.5
                * (
                    (
                        jax.lax.stop_gradient(bellman_target)
                        - current_q_values
                    )
                    ** 2
                ).mean(axis=1).sum()
            )
            return loss, (
                state_updates,
                current_q_values,
                next_q_values,
                jnp.mean(jnp.std(soft_target_values, axis=0)),
            )

        (
            qf_loss_value,
            (
                state_updates,
                current_q_values,
                next_q_values,
                target_sample_std,
            ),
        ), grads = jax.value_and_grad(critic_loss, has_aux=True)(
            qf_state.params,
            qf_state.batch_stats,
            dropout_key_current,
        )
        qf_state = qf_state.apply_gradients(grads=grads)
        qf_state = qf_state.replace(
            batch_stats=state_updates["batch_stats"]
        )
        metrics = {
            "critic_loss": qf_loss_value,
            "ent_coef": ent_coef_value,
            "current_q_values": current_q_values.mean(),
            "next_q_values": next_q_values.mean(),
            "target_sample_std": target_sample_std,
        }
        return qf_state, metrics, key

    @classmethod
    @partial(
        jax.jit,
        static_argnames=[
            "cls",
            "crossq_style",
            "td3_mode",
            "use_bnstats_from_live_net",
            "gradient_steps",
            "q_reduce_fn",
            "target_action_samples",
        ],
    )
    def _train_dual_target(
        cls,
        crossq_style: bool,
        td3_mode: bool,
        use_bnstats_from_live_net: bool,
        gamma: float,
        tau: float,
        target_entropy: np.ndarray,
        gradient_steps: int,
        data: ReplayBufferSamplesNp,
        policy_delay_indices: flax.core.FrozenDict,
        qf_state: RLTrainState,
        actor_state: ActorTrainState,
        ent_coef_state: TrainState,
        key,
        q_reduce_fn,
        target_action_samples: int,
    ):
        actor_loss_value = jnp.array(0.0)
        log_metrics_critic = {}
        for index in range(gradient_steps):

            def slice_batch(value, step=index):
                batch_size = value.shape[0] // gradient_steps
                return value[batch_size * step : batch_size * (step + 1)]

            qf_state, log_metrics_critic, key = (
                cls.update_critic_dual_target(
                    crossq_style,
                    td3_mode,
                    use_bnstats_from_live_net,
                    gamma,
                    actor_state,
                    qf_state,
                    ent_coef_state,
                    slice_batch(data.observations),
                    slice_batch(data.actions),
                    slice_batch(data.next_observations),
                    slice_batch(data.rewards),
                    slice_batch(data.dones),
                    key,
                    target_action_samples,
                )
            )
            qf_state = SAC.soft_update(tau, qf_state)
            if index in policy_delay_indices:
                actor_state, qf_state, actor_loss_value, key, entropy = (
                    cls.update_actor(
                        actor_state,
                        qf_state,
                        ent_coef_state,
                        slice_batch(data.observations),
                        key,
                        q_reduce_fn,
                        td3_mode,
                    )
                )
                ent_coef_state, _ = SAC.update_temperature(
                    target_entropy,
                    ent_coef_state,
                    entropy,
                )
        return (
            qf_state,
            actor_state,
            ent_coef_state,
            key,
            {"actor_loss": actor_loss_value, **log_metrics_critic},
        )

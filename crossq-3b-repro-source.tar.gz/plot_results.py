"""Create learning-curve, return, AUC, and wall-clock figures."""

import argparse
import json
import os
import pathlib
from collections import defaultdict

os.environ.setdefault("MPLCONFIGDIR", "/tmp/cross3b-mpl")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ALGO_LABELS = {
    "crossq": "CrossQ",
    "cross3b": "Cross3B",
}
ALGO_COLORS = {
    "crossq": "#3B6EA8",
    "cross3b": "#D9772C",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_root", type=pathlib.Path)
    parser.add_argument(
        "--reference-root",
        type=pathlib.Path,
        action="append",
        default=[],
        help="Additional completed matrix to include in the comparison.",
    )
    parser.add_argument(
        "--reference-algos",
        nargs="+",
        choices=["crossq", "cross3b"],
        default=None,
        help="Only include these algorithms from reference roots.",
    )
    parser.add_argument("--output-dir", type=pathlib.Path, default=None)
    parser.add_argument("--dpi", type=int, default=160)
    return parser.parse_args()


def load_runs(run_root: pathlib.Path, allowed_algos=None):
    runs = []
    summary_paths = {
        path
        for path in run_root.glob("**/summary.json")
        if "_failed" not in path.parts
    }
    for summary_path in sorted(summary_paths):
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        if allowed_algos is not None and summary["algo"] not in allowed_algos:
            continue
        if summary.get("final_return") is None:
            continue
        records_path = summary_path.parent / "evaluations.jsonl"
        records = []
        if records_path.exists():
            records = [
                json.loads(line)
                for line in records_path.read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
        runs.append(
            {
                "summary": summary,
                "records": records,
                "label": (
                    f"{ALGO_LABELS[summary['algo']]} "
                    f"seed={summary['seed']}"
                ),
            }
        )
    return runs


def plot_learning_curves(runs, env_id, output_dir, dpi):
    env_runs = [run for run in runs if run["summary"]["env"] == env_id]
    if not env_runs:
        return

    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    algo_runs = defaultdict(list)
    for run in env_runs:
        algo_runs[run["summary"]["algo"]].append(run)

    for algo, runs_for_algo in sorted(algo_runs.items()):
        seed_curves = defaultdict(list)
        for run in runs_for_algo:
            for record in run["records"]:
                seed_curves[float(record["timesteps"])].append(
                    float(record["episode_return"])
                )
        steps = np.asarray(sorted(seed_curves), dtype=float)
        mean = np.asarray([np.mean(seed_curves[step]) for step in steps])
        std = np.asarray([np.std(seed_curves[step]) for step in steps])
        color = ALGO_COLORS[algo]

        for run in runs_for_algo:
            seed_steps = [record["timesteps"] for record in run["records"]]
            seed_returns = [
                record["episode_return"] for record in run["records"]
            ]
            ax.plot(seed_steps, seed_returns, color=color, alpha=0.22, linewidth=1)

        ax.plot(steps, mean, color=color, linewidth=2.2, label=ALGO_LABELS[algo])
        if len(runs_for_algo) > 1:
            ax.fill_between(
                steps,
                mean - std,
                mean + std,
                color=color,
                alpha=0.16,
                linewidth=0,
            )

    ax.set_title(f"{env_id}: evaluation return during training")
    ax.set_xlabel("Environment steps")
    ax.set_ylabel("Evaluation episode return")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(
        output_dir / f"learning_curve_{env_id}.png",
        dpi=dpi,
        bbox_inches="tight",
    )
    plt.close(fig)


def plot_summary_bars(runs, output_dir, dpi):
    envs = sorted({run["summary"]["env"] for run in runs})
    algorithms = sorted({run["summary"]["algo"] for run in runs})
    metrics = [
        ("final_return", "Final evaluation return"),
        ("auc", "Normalized AUC"),
        ("train_wall_seconds", "Training wall time (hours)"),
    ]
    grouped = defaultdict(list)
    for run in runs:
        grouped[(run["summary"]["env"], run["summary"]["algo"])].append(
            run["summary"]
        )

    fig, axes = plt.subplots(1, 3, figsize=(13.2, 4.2))
    width = 0.34
    x = np.arange(len(envs), dtype=float)
    for ax, (metric, title) in zip(axes, metrics):
        for index, algo in enumerate(algorithms):
            means = []
            stds = []
            for env_id in envs:
                values = [run[metric] for run in grouped[(env_id, algo)]]
                if not values:
                    means.append(np.nan)
                    stds.append(0.0)
                    continue
                if metric == "train_wall_seconds":
                    values = [value / 3600.0 for value in values]
                means.append(np.mean(values))
                stds.append(np.std(values, ddof=1) if len(values) > 1 else 0.0)
            offsets = x + (index - (len(algorithms) - 1) / 2) * width
            ax.bar(
                offsets,
                means,
                width,
                yerr=stds,
                capsize=3,
                color=ALGO_COLORS[algo],
                alpha=0.86,
                label=ALGO_LABELS[algo],
            )
        ax.set_xticks(x, envs)
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.25)
    axes[0].legend(frameon=False)
    fig.tight_layout()
    fig.savefig(
        output_dir / "summary_metrics.png",
        dpi=dpi,
        bbox_inches="tight",
    )
    plt.close(fig)


def plot_return_vs_wallclock(runs, env_id, output_dir, dpi):
    env_runs = [run for run in runs if run["summary"]["env"] == env_id]
    if not env_runs:
        return

    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    algo_runs = defaultdict(list)
    for run in env_runs:
        algo_runs[run["summary"]["algo"]].append(run)

    for algo, runs_for_algo in sorted(algo_runs.items()):
        wall_points = defaultdict(list)
        for run in runs_for_algo:
            for record in run["records"]:
                wall_points[float(record["train_wall_seconds"])].append(
                    float(record["episode_return"])
                )
        seconds = np.asarray(sorted(wall_points), dtype=float)
        mean = np.asarray([np.mean(wall_points[value]) for value in seconds])
        ax.plot(
            seconds / 3600.0,
            mean,
            color=ALGO_COLORS[algo],
            linewidth=2.2,
            label=ALGO_LABELS[algo],
        )

    ax.set_title(f"{env_id}: return versus training wall time")
    ax.set_xlabel("Training wall time (hours)")
    ax.set_ylabel("Evaluation episode return")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(
        output_dir / f"return_vs_wallclock_{env_id}.png",
        dpi=dpi,
        bbox_inches="tight",
    )
    plt.close(fig)


def main() -> None:
    args = parse_args()
    runs = load_runs(args.run_root)
    for root in args.reference_root:
        runs.extend(load_runs(root, args.reference_algos))
    if not runs:
        raise SystemExit(f"No completed runs with evaluations under {args.run_root}")

    output_dir = args.output_dir or (args.run_root / "figures")
    output_dir.mkdir(parents=True, exist_ok=True)

    envs = sorted({run["summary"]["env"] for run in runs})
    for env_id in envs:
        plot_learning_curves(runs, env_id, output_dir, args.dpi)
        plot_return_vs_wallclock(runs, env_id, output_dir, args.dpi)
    plot_summary_bars(runs, output_dir, args.dpi)
    print(f"Wrote figures to {output_dir}")


if __name__ == "__main__":
    main()
